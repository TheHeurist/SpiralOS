"""Tests for SpiralLLM-Math Optimal Transport Reasoner."""

import pytest
import numpy as np

from holor_calculus import (
    SpiralLLMMath, MathematicalProblem,
    OptimalTransportReasoner,
    ChiralObject, Chirality,
    ChiralMeasure, create_uniform_measure, create_weighted_measure,
    WassersteinDistance
)


class TestOptimalTransportReasoner:
    """Test optimal transport reasoner functionality."""

    def test_initialization(self):
        """Test reasoner initialization."""
        engine = SpiralLLMMath()
        reasoner = OptimalTransportReasoner(engine)
        
        assert reasoner.spiral_engine == engine
        assert 'optimal_transport' in engine.reasoners
        assert 'wasserstein' in engine.reasoners
        assert 'barycenter' in engine.reasoners
        assert 'displacement_interpolation' in engine.reasoners

    def test_wasserstein_distance_computation(self):
        """Test Wasserstein distance computation."""
        engine = SpiralLLMMath()
        reasoner = OptimalTransportReasoner(engine)
        
        source = create_uniform_measure([
            ChiralObject(np.array([0.0]), Chirality.LEFT),
            ChiralObject(np.array([1.0]), Chirality.LEFT),
        ])
        target = create_uniform_measure([
            ChiralObject(np.array([0.0]), Chirality.LEFT),
            ChiralObject(np.array([2.0]), Chirality.LEFT),
        ])
        
        problem = MathematicalProblem(
            problem_type='wasserstein',
            description='Compute Wasserstein distance',
            input_data={
                'source': source,
                'target': target,
                'p': 2.0,
                'chirality_penalty': 1.0
            }
        )
        
        result = reasoner.solve_wasserstein(problem)
        
        assert 'wasserstein_distance' in result
        assert 'coupling' in result
        assert 'transport_cost' in result
        assert result['wasserstein_distance'] >= 0

    def test_barycenter_computation(self):
        """Test Wasserstein barycenter computation."""
        engine = SpiralLLMMath()
        reasoner = OptimalTransportReasoner(engine)
        
        measures = [
            create_uniform_measure([ChiralObject(np.array([0.0]), Chirality.LEFT)]),
            create_uniform_measure([ChiralObject(np.array([2.0]), Chirality.RIGHT)]),
        ]
        
        problem = MathematicalProblem(
            problem_type='barycenter',
            description='Compute barycenter',
            input_data={
                'measures': measures,
                'weights': None,
                'n_support': 2,
                'p': 2.0
            }
        )
        
        result = reasoner.solve_barycenter(problem)
        
        assert 'barycenter' in result
        assert isinstance(result['barycenter'], ChiralMeasure)
        assert 'barycenter_location' in result
        assert 'mean_chirality' in result

    def test_displacement_interpolation(self):
        """Test displacement interpolation."""
        engine = SpiralLLMMath()
        reasoner = OptimalTransportReasoner(engine)
        
        source = create_uniform_measure([ChiralObject(np.array([0.0]), Chirality.LEFT)])
        target = create_uniform_measure([ChiralObject(np.array([1.0]), Chirality.RIGHT)])
        
        problem = MathematicalProblem(
            problem_type='displacement_interpolation',
            description='Interpolate measures',
            input_data={
                'source': source,
                'target': target,
                't': 0.5,
                'n_points': 5
            }
        )
        
        result = reasoner.solve_displacement_interpolation(problem)
        
        assert 'interpolated_measure' in result
        assert 't' in result
        assert result['t'] == 0.5
        assert 'geodesic' in result

    def test_chirality_effect_analysis(self):
        """Test chirality effect analysis."""
        engine = SpiralLLMMath()
        reasoner = OptimalTransportReasoner(engine)
        
        source = create_uniform_measure([ChiralObject(np.zeros(2), Chirality.LEFT)])
        target = create_uniform_measure([ChiralObject(np.ones(2), Chirality.RIGHT)])
        
        analysis = reasoner._analyze_chirality_effect(source, target, penalty=5.0)
        
        assert 'n_chirality_mismatches' in analysis
        assert 'mismatch_rate' in analysis
        assert 'expected_penalty_contribution' in analysis
        assert analysis['n_chirality_mismatches'] > 0

    def test_optimal_transport_verification(self):
        """Test optimal transport solution verification."""
        engine = SpiralLLMMath()
        reasoner = OptimalTransportReasoner(engine)
        
        source = create_uniform_measure([ChiralObject(np.zeros(2), Chirality.LEFT)])
        target = create_uniform_measure([ChiralObject(np.ones(2), Chirality.RIGHT)])
        
        wasserstein = WassersteinDistance(p=2.0)
        coupling = wasserstein.compute_optimal_coupling(source, target)
        
        problem = MathematicalProblem(
            problem_type='wasserstein',
            description='Test',
            input_data={'source': source, 'target': target}
        )
        
        result = {
            'wasserstein_distance': 1.0,
            'coupling': coupling,
            't': 0.5
        }
        
        verification = reasoner.verify_optimal_transport(problem, result)
        
        assert 'checks' in verification
        assert 'all_passed' in verification


class TestOptimalTransportExplanations:
    """Test explanation generation."""

    def test_wasserstein_explanation(self):
        """Test Wasserstein distance explanation."""
        reasoner = OptimalTransportReasoner()
        
        source = create_uniform_measure([ChiralObject(np.zeros(2), Chirality.LEFT)])
        target = create_uniform_measure([ChiralObject(np.ones(2), Chirality.RIGHT)])
        
        explanation = reasoner._explain_wasserstein_distance(1.0, 2.0, source, target)
        
        assert isinstance(explanation, str)
        assert 'Wasserstein' in explanation
        assert 'distance' in explanation

    def test_barycenter_explanation(self):
        """Test barycenter explanation."""
        reasoner = OptimalTransportReasoner()
        
        measures = [
            create_uniform_measure([ChiralObject(np.zeros(2), Chirality.LEFT)]),
            create_uniform_measure([ChiralObject(np.ones(2), Chirality.RIGHT)]),
        ]
        barycenter = create_uniform_measure([ChiralObject(np.array([0.5, 0.5]), Chirality.NEUTRAL)])
        
        explanation = reasoner._explain_barycenter(barycenter, measures, None)
        
        assert isinstance(explanation, str)
        assert 'barycenter' in explanation.lower()

    def test_displacement_interpolation_explanation(self):
        """Test displacement interpolation explanation."""
        reasoner = OptimalTransportReasoner()
        
        source = create_uniform_measure([ChiralObject(np.zeros(2), Chirality.LEFT)])
        target = create_uniform_measure([ChiralObject(np.ones(2), Chirality.RIGHT)])
        interpolated = create_uniform_measure([ChiralObject(np.array([0.5, 0.5]), Chirality.NEUTRAL)])
        
        explanation = reasoner._explain_displacement_interpolation(0.5, source, target, interpolated)
        
        assert isinstance(explanation, str)
        assert 't=' in explanation


class TestIntegratedOptimalTransportReasoning:
    """Integration tests for optimal transport reasoning."""

    def test_full_wasserstein_workflow(self):
        """Test complete Wasserstein distance workflow."""
        from holor_calculus import SpiralProblemSolver
        
        solver = SpiralProblemSolver()
        
        source = create_uniform_measure([
            ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT),
            ChiralObject(np.array([1.0, 0.0]), Chirality.LEFT),
        ])
        target = create_uniform_measure([
            ChiralObject(np.array([0.5, 0.5]), Chirality.RIGHT),
            ChiralObject(np.array([1.5, 0.5]), Chirality.RIGHT),
        ])
        
        solution = solver.solve_wasserstein_problem(source, target, p=2.0)
        
        assert solution.result is not None
        assert 'wasserstein_distance' in solution.result
        assert len(solution.reasoning_chain) >= 0

    def test_barycenter_workflow(self):
        """Test barycenter computation workflow."""
        from holor_calculus import SpiralProblemSolver
        
        solver = SpiralProblemSolver()
        
        measures = [
            create_uniform_measure([ChiralObject(np.array([0.0]), Chirality.LEFT)]),
            create_uniform_measure([ChiralObject(np.array([1.0]), Chirality.RIGHT)]),
        ]
        
        solution = solver.solve_barycenter_problem(measures, n_support=2)
        
        assert solution.result is not None
        assert 'barycenter' in solution.result

    def test_displacement_interpolation_workflow(self):
        """Test displacement interpolation workflow."""
        from holor_calculus import SpiralProblemSolver
        
        solver = SpiralProblemSolver()
        
        source = create_uniform_measure([ChiralObject(np.array([0.0]), Chirality.LEFT)])
        target = create_uniform_measure([ChiralObject(np.array([1.0]), Chirality.RIGHT)])
        
        solution = solver.solve_displacement_interpolation_problem(source, target, t=0.5)
        
        assert solution.result is not None
        assert 'interpolated_measure' in solution.result

    def test_chirality_penalty_effect(self):
        """Test effect of chirality penalty on distance."""
        from holor_calculus import SpiralProblemSolver
        
        solver = SpiralProblemSolver()
        
        source = create_uniform_measure([ChiralObject(np.zeros(2), Chirality.LEFT)])
        target = create_uniform_measure([ChiralObject(np.zeros(2), Chirality.RIGHT)])
        
        # With low penalty
        sol1 = solver.solve_wasserstein_problem(source, target, chirality_penalty=0.1)
        
        # With high penalty
        sol2 = solver.solve_wasserstein_problem(source, target, chirality_penalty=10.0)
        
        # Higher penalty should give higher distance
        assert sol2.result['wasserstein_distance'] > sol1.result['wasserstein_distance']

    def test_geodesic_computation(self):
        """Test Wasserstein geodesic computation."""
        from holor_calculus import compute_wasserstein_geodesic
        
        source = create_uniform_measure([ChiralObject(np.array([0.0]), Chirality.LEFT)])
        target = create_uniform_measure([ChiralObject(np.array([1.0]), Chirality.RIGHT)])
        
        geodesic = compute_wasserstein_geodesic(source, target, n_points=5)
        
        assert len(geodesic) == 5
        assert all(isinstance(m, ChiralMeasure) for m in geodesic)
