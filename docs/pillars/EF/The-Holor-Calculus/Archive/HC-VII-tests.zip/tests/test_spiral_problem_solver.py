"""Tests for SpiralLLM-Math Problem Solver."""

import pytest
import numpy as np

from holor_calculus import (
    SpiralProblemSolver, MathematicalProblem, Solution,
    ChiralObject, Chirality,
    ChiralPath, FisherMetric
)


class TestSpiralProblemSolver:
    """Test high-level problem solver interface."""

    def test_initialization(self):
        """Test solver initialization."""
        solver = SpiralProblemSolver()
        assert solver.engine is not None
        assert solver.homotopy_reasoner is not None
        assert solver.info_geo_reasoner is not None

    def test_solve_homotopy_problem(self):
        """Test solving homotopy problem."""
        solver = SpiralProblemSolver()
        
        p0 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        p1 = ChiralObject(np.array([1.0, 1.0]), Chirality.RIGHT)
        path1 = ChiralPath(p0, p1)
        path2 = ChiralPath(p0, p1)
        
        solution = solver.solve_homotopy_problem(path1, path2, 'create')
        
        assert isinstance(solution, Solution)
        assert solution.result is not None

    def test_solve_divergence_problem(self):
        """Test solving divergence problem."""
        solver = SpiralProblemSolver()
        
        obj1 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        obj2 = ChiralObject(np.array([0.5, 0.5]), Chirality.LEFT)
        
        solution = solver.solve_divergence_problem(obj1, obj2, 'kl')
        
        assert isinstance(solution, Solution)
        assert 'value' in solution.result
        assert solution.result['value'] >= 0

    def test_solve_fisher_metric_problem(self):
        """Test solving Fisher metric problem."""
        solver = SpiralProblemSolver()
        
        solution = solver.solve_fisher_metric_problem('gaussian', 2, 'compute')
        
        assert isinstance(solution, Solution)
        assert 'metric' in solution.result

    def test_solve_geometric_statistics_problem(self):
        """Test solving geometric statistics problem."""
        solver = SpiralProblemSolver()
        
        objects = [
            ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT),
            ChiralObject(np.array([1.0, 0.0]), Chirality.LEFT),
            ChiralObject(np.array([0.0, 1.0]), Chirality.LEFT)
        ]
        metric = FisherMetric.gaussian(2)
        
        solution = solver.solve_geometric_statistics_problem(
            objects, metric, 'frechet_mean'
        )
        
        assert isinstance(solution, Solution)
        assert 'mean' in solution.result

    def test_explain_solution(self):
        """Test solution explanation."""
        solver = SpiralProblemSolver()
        
        obj1 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        obj2 = ChiralObject(np.array([0.1, 0.1]), Chirality.LEFT)
        
        solution = solver.solve_divergence_problem(obj1, obj2)
        explanation = solver.explain_solution(solution, detailed=False)
        
        assert isinstance(explanation, str)
        assert 'Problem:' in explanation
        assert 'Result:' in explanation

    def test_detailed_explanation(self):
        """Test detailed solution explanation."""
        solver = SpiralProblemSolver()
        
        obj1 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        obj2 = ChiralObject(np.array([0.1, 0.1]), Chirality.LEFT)
        
        solution = solver.solve_divergence_problem(obj1, obj2)
        explanation = solver.explain_solution(solution, detailed=True)
        
        assert isinstance(explanation, str)
        assert 'Step' in explanation

    def test_get_statistics(self):
        """Test statistics retrieval."""
        solver = SpiralProblemSolver()
        
        obj1 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        obj2 = ChiralObject(np.array([0.1, 0.1]), Chirality.LEFT)
        
        solver.solve_divergence_problem(obj1, obj2)
        solver.solve_divergence_problem(obj1, obj2, 'hellinger')
        
        stats = solver.get_statistics()
        assert stats['total_problems'] >= 2

    def test_get_history(self):
        """Test history retrieval."""
        solver = SpiralProblemSolver()
        
        obj1 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        obj2 = ChiralObject(np.array([0.1, 0.1]), Chirality.LEFT)
        
        solver.solve_divergence_problem(obj1, obj2)
        history = solver.get_history()
        
        assert len(history) >= 1
        assert all(isinstance(sol, Solution) for sol in history)

    def test_interactive_explore_homotopy(self):
        """Test interactive exploration of homotopy."""
        solver = SpiralProblemSolver()
        
        exploration = solver.interactive_explore('homotopy')
        
        assert 'insights' in exploration
        assert 'examples' in exploration
        assert 'available_operations' in exploration
        assert len(exploration['insights']) > 0

    def test_interactive_explore_divergence(self):
        """Test interactive exploration of divergence."""
        solver = SpiralProblemSolver()
        
        exploration = solver.interactive_explore('divergence')
        
        assert 'insights' in exploration
        assert len(exploration['insights']) > 0
        assert 'kl' in exploration['available_operations']

    def test_batch_solve(self):
        """Test batch problem solving."""
        solver = SpiralProblemSolver()
        
        obj1 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        obj2 = ChiralObject(np.array([0.1, 0.1]), Chirality.LEFT)
        
        problems = [
            MathematicalProblem(
                'divergence',
                'KL divergence',
                {'object1': obj1, 'object2': obj2, 'type': 'kl'}
            ),
            MathematicalProblem(
                'divergence',
                'Hellinger distance',
                {'object1': obj1, 'object2': obj2, 'type': 'hellinger'}
            )
        ]
        
        solutions = solver.batch_solve(problems)
        
        assert len(solutions) == 2
        assert all(isinstance(sol, Solution) for sol in solutions)

    def test_create_problem_from_dict(self):
        """Test problem creation from dictionary."""
        solver = SpiralProblemSolver()
        
        data = {
            'problem_type': 'test',
            'description': 'Test problem',
            'input_data': {'x': 1, 'y': 2},
            'constraints': ['x > 0'],
            'expected_properties': ['positive']
        }
        
        problem = solver.create_problem_from_dict(data)
        
        assert isinstance(problem, MathematicalProblem)
        assert problem.problem_type == 'test'
        assert problem.input_data['x'] == 1
