"""Tests for SpiralLLM-Math Verification System."""

import pytest
import numpy as np

from holor_calculus import (
    SpiralLLMMath, MathematicalProblem, Solution,
    SpiralVerifier, QualityAssessor, VerificationResult,
    ChiralObject, Chirality,
    ChiralPath, ChiralHomotopy, FisherMetric
)


class TestSpiralVerifier:
    """Test verification system functionality."""

    def test_initialization(self):
        """Test verifier initialization."""
        verifier = SpiralVerifier()
        assert verifier.tolerance == 1e-9
        assert len(verifier.custom_checks) == 0

    def test_register_check(self):
        """Test custom check registration."""
        verifier = SpiralVerifier()
        
        def custom_check(problem, result):
            return True, "OK"
        
        verifier.register_check('test_check', custom_check)
        assert 'test_check' in verifier.custom_checks

    def test_verify_simple_solution(self):
        """Test verifying a simple solution."""
        engine = SpiralLLMMath()
        problem = MathematicalProblem('test', 'Test', {'x': 1})
        solution = engine.solve(problem)
        
        verifier = SpiralVerifier()
        result = verifier.verify_solution(solution)
        
        assert isinstance(result, VerificationResult)
        assert len(result.checks_performed) > 0

    def test_homotopy_verification(self):
        """Test homotopy-specific verification."""
        from holor_calculus import HomotopyReasoner
        
        engine = SpiralLLMMath()
        reasoner = HomotopyReasoner(engine)
        
        p0 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        p1 = ChiralObject(np.array([1.0, 1.0]), Chirality.RIGHT)
        path1 = ChiralPath(p0, p1)
        path2 = ChiralPath(p0, p1)
        
        problem = MathematicalProblem(
            'homotopy',
            'Test homotopy',
            {'path1': path1, 'path2': path2, 'operation': 'create'}
        )
        
        solution = engine.solve(problem)
        
        verifier = SpiralVerifier()
        result = verifier.verify_solution(solution)
        
        assert 'homotopy_exists' in result.checks_performed or 'no_errors' in result.checks_performed

    def test_divergence_verification(self):
        """Test divergence verification."""
        from holor_calculus import InfoGeometryReasoner
        
        engine = SpiralLLMMath()
        reasoner = InfoGeometryReasoner(engine)
        
        obj1 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        obj2 = ChiralObject(np.array([0.5, 0.5]), Chirality.LEFT)
        
        problem = MathematicalProblem(
            'divergence',
            'Test divergence',
            {'object1': obj1, 'object2': obj2, 'type': 'kl'}
        )
        
        solution = engine.solve(problem)
        
        verifier = SpiralVerifier()
        result = verifier.verify_solution(solution)
        
        # Should check for non-negativity
        assert any('divergence' in check.lower() or 'non_negative' in check.lower() 
                  for check in result.checks_performed) or 'no_errors' in result.checks_performed

    def test_verification_report(self):
        """Test verification report generation."""
        engine = SpiralLLMMath()
        problem = MathematicalProblem('test', 'Test', {})
        solution = engine.solve(problem)
        
        verifier = SpiralVerifier()
        result = verifier.verify_solution(solution)
        report = result.get_report()
        
        assert isinstance(report, str)
        assert 'VERIFICATION REPORT' in report
        assert 'Status:' in report

    def test_custom_check_execution(self):
        """Test custom check execution."""
        verifier = SpiralVerifier()
        
        def always_pass(problem, result):
            return True, "Always passes"
        
        def always_fail(problem, result):
            return False, "Always fails"
        
        verifier.register_check('pass_check', always_pass)
        verifier.register_check('fail_check', always_fail)
        
        engine = SpiralLLMMath()
        problem = MathematicalProblem('test', 'Test', {})
        solution = engine.solve(problem)
        
        result = verifier.verify_solution(solution)
        
        assert 'pass_check' in result.checks_passed
        assert 'fail_check' in result.checks_failed

    def test_property_verification(self):
        """Test property verification."""
        verifier = SpiralVerifier()
        
        obj = ChiralObject(np.array([1.0, 2.0]), Chirality.LEFT)
        
        passed, msg = verifier.verify_property(obj, 'chirality', Chirality.LEFT)
        assert passed == True
        
        passed, msg = verifier.verify_property(obj, 'chirality', Chirality.RIGHT)
        assert passed == False

    def test_chirality_consistency(self):
        """Test chirality consistency verification."""
        verifier = SpiralVerifier()
        
        obj = ChiralObject(np.array([1.0, 2.0]), Chirality.LEFT)
        passed, msg = verifier.verify_chirality_consistency(obj)
        
        assert passed == True
        assert 'consistent' in msg.lower()

    def test_path_continuity(self):
        """Test path continuity verification."""
        verifier = SpiralVerifier()
        
        p0 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        p1 = ChiralObject(np.array([1.0, 1.0]), Chirality.RIGHT)
        path = ChiralPath(p0, p1)
        
        passed, msg = verifier.verify_path_continuity(path, num_samples=50)
        
        assert passed == True
        assert 'continuous' in msg.lower()

    def test_numerical_stability_check(self):
        """Test numerical stability checking."""
        verifier = SpiralVerifier()
        
        # Stable result
        stable_result = {'value': 1.5, 'data': np.array([1.0, 2.0])}
        assert verifier._check_numerical_stability(stable_result) == True
        
        # Unstable result with NaN
        unstable_result = {'value': np.nan}
        assert verifier._check_numerical_stability(unstable_result) == False
        
        # Unstable result with Inf
        unstable_result2 = {'value': np.inf}
        assert verifier._check_numerical_stability(unstable_result2) == False


class TestQualityAssessor:
    """Test quality assessment functionality."""

    def test_initialization(self):
        """Test assessor initialization."""
        assessor = QualityAssessor()
        assert assessor is not None

    def test_assess_solution(self):
        """Test solution quality assessment."""
        engine = SpiralLLMMath()
        problem = MathematicalProblem('test', 'Test', {})
        solution = engine.solve(problem)
        
        verifier = SpiralVerifier()
        verification = verifier.verify_solution(solution)
        
        assessor = QualityAssessor()
        assessment = assessor.assess_solution(solution, verification)
        
        assert 'quality_score' in assessment
        assert 'grade' in assessment
        assert 'recommendations' in assessment

    def test_quality_score_calculation(self):
        """Test quality score calculation."""
        from holor_calculus.spiral_llm_math import ReasoningStep
        from holor_calculus import SpiralStage
        
        problem = MathematicalProblem('test', 'Test', {})
        solution = Solution(
            problem=problem,
            reasoning_chain=[
                ReasoningStep(SpiralStage.UNDERSTAND, 'desc', {}, {})
            ],
            result='test',
            verification_status=True,
            confidence=0.9
        )
        
        verification = VerificationResult(
            passed=True,
            checks_performed=['check1', 'check2'],
            checks_passed=['check1', 'check2'],
            checks_failed=[],
            warnings=[],
            details={},
            confidence=0.95
        )
        
        assessor = QualityAssessor()
        assessment = assessor.assess_solution(solution, verification)
        
        assert 0.0 <= assessment['quality_score'] <= 1.0
        assert assessment['grade'] in ['A', 'B', 'C', 'D', 'F']

    def test_grade_assignment(self):
        """Test grade assignment."""
        assessor = QualityAssessor()
        
        assert assessor._score_to_grade(0.95) == 'A'
        assert assessor._score_to_grade(0.85) == 'B'
        assert assessor._score_to_grade(0.75) == 'C'
        assert assessor._score_to_grade(0.65) == 'D'
        assert assessor._score_to_grade(0.50) == 'F'

    def test_confidence_assessment(self):
        """Test confidence assessment."""
        from holor_calculus.spiral_llm_math import ReasoningStep
        from holor_calculus import SpiralStage
        
        problem = MathematicalProblem('test', 'Test', {})
        solution = Solution(
            problem=problem,
            reasoning_chain=[ReasoningStep(SpiralStage.UNDERSTAND, 'desc', {}, {})],
            result='test',
            verification_status=True,
            confidence=0.9
        )
        
        verification = VerificationResult(
            passed=True,
            checks_performed=[],
            checks_passed=[],
            checks_failed=[],
            warnings=[],
            details={},
            confidence=0.9
        )
        
        assessor = QualityAssessor()
        assessment = assessor.assess_solution(solution, verification)
        
        assert assessment['confidence_assessment'] in [
            'Very High', 'High', 'Moderate', 'Low', 'Very Low'
        ]

    def test_recommendations_generation(self):
        """Test recommendations generation."""
        from holor_calculus.spiral_llm_math import ReasoningStep
        from holor_calculus import SpiralStage
        
        problem = MathematicalProblem('test', 'Test', {})
        
        # Low confidence solution
        solution = Solution(
            problem=problem,
            reasoning_chain=[ReasoningStep(SpiralStage.UNDERSTAND, 'desc', {}, {})],
            result='test',
            verification_status=False,
            confidence=0.5
        )
        
        verification = VerificationResult(
            passed=False,
            checks_performed=['check1'],
            checks_passed=[],
            checks_failed=['check1'],
            warnings=['Warning message'],
            details={},
            confidence=0.5
        )
        
        assessor = QualityAssessor()
        assessment = assessor.assess_solution(solution, verification)
        
        assert len(assessment['recommendations']) > 0


class TestIntegratedVerification:
    """Test integrated verification workflows."""

    def test_full_workflow(self):
        """Test complete verification workflow."""
        from holor_calculus import InfoGeometryReasoner
        
        # Solve a problem
        engine = SpiralLLMMath()
        reasoner = InfoGeometryReasoner(engine)
        
        obj1 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        obj2 = ChiralObject(np.array([0.5, 0.5]), Chirality.LEFT)
        
        problem = MathematicalProblem(
            'divergence',
            'Compute divergence',
            {'object1': obj1, 'object2': obj2, 'type': 'kl'}
        )
        
        solution = engine.solve(problem)
        
        # Verify solution
        verifier = SpiralVerifier()
        verification = verifier.verify_solution(solution)
        
        # Assess quality
        assessor = QualityAssessor()
        assessment = assessor.assess_solution(solution, verification)
        
        # Generate report
        report = verification.get_report()
        
        assert isinstance(solution, Solution)
        assert isinstance(verification, VerificationResult)
        assert isinstance(assessment, dict)
        assert isinstance(report, str)
