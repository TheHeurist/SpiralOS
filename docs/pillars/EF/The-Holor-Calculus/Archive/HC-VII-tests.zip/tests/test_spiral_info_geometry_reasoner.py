"""Tests for SpiralLLM-Math Information Geometry Reasoner."""

import pytest
import numpy as np

from holor_calculus import (
    SpiralLLMMath, MathematicalProblem,
    InfoGeometryReasoner,
    ChiralObject, Chirality,
    FisherMetric, ChiralDivergence, GeometricStatistics
)


class TestInfoGeometryReasoner:
    """Test information geometry reasoner functionality."""

    def test_initialization(self):
        """Test reasoner initialization."""
        engine = SpiralLLMMath()
        reasoner = InfoGeometryReasoner(engine)
        
        assert reasoner.spiral_engine == engine
        assert 'fisher_metric' in engine.reasoners
        assert 'divergence' in engine.reasoners

    def test_fisher_metric_computation(self):
        """Test Fisher metric computation."""
        engine = SpiralLLMMath()
        reasoner = InfoGeometryReasoner(engine)
        
        problem = MathematicalProblem(
            problem_type='fisher_metric',
            description='Compute Fisher metric',
            input_data={
                'distribution': 'gaussian',
                'dim': 2,
                'operation': 'compute'
            }
        )
        
        result = reasoner.solve_fisher_metric(problem)
        assert 'metric' in result
        assert isinstance(result['metric'], FisherMetric)

    def test_kl_divergence(self):
        """Test KL divergence computation."""
        engine = SpiralLLMMath()
        reasoner = InfoGeometryReasoner(engine)
        
        obj1 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        obj2 = ChiralObject(np.array([0.1, 0.1]), Chirality.LEFT)
        
        problem = MathematicalProblem(
            problem_type='divergence',
            description='Compute KL divergence',
            input_data={
                'object1': obj1,
                'object2': obj2,
                'type': 'kl'
            }
        )
        
        result = reasoner.solve_divergence(problem)
        assert 'value' in result
        assert result['value'] >= 0  # KL divergence is non-negative

    def test_hellinger_distance(self):
        """Test Hellinger distance computation."""
        engine = SpiralLLMMath()
        reasoner = InfoGeometryReasoner(engine)
        
        obj1 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        obj2 = ChiralObject(np.array([1.0, 1.0]), Chirality.LEFT)
        
        problem = MathematicalProblem(
            problem_type='divergence',
            description='Compute Hellinger distance',
            input_data={
                'object1': obj1,
                'object2': obj2,
                'type': 'hellinger'
            }
        )
        
        result = reasoner.solve_divergence(problem)
        assert 'value' in result
        assert result['symmetric'] == True

    def test_alpha_divergence(self):
        """Test alpha divergence computation."""
        engine = SpiralLLMMath()
        reasoner = InfoGeometryReasoner(engine)
        
        obj1 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        obj2 = ChiralObject(np.array([0.5, 0.5]), Chirality.LEFT)
        
        problem = MathematicalProblem(
            problem_type='divergence',
            description='Compute alpha divergence',
            input_data={
                'object1': obj1,
                'object2': obj2,
                'type': 'alpha',
                'alpha': 0.5
            }
        )
        
        result = reasoner.solve_divergence(problem)
        assert 'value' in result
        assert 'divergence_type' in result

    def test_frechet_mean(self):
        """Test Fréchet mean computation."""
        engine = SpiralLLMMath()
        reasoner = InfoGeometryReasoner(engine)
        
        objects = [
            ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT),
            ChiralObject(np.array([1.0, 0.0]), Chirality.LEFT),
            ChiralObject(np.array([0.0, 1.0]), Chirality.LEFT)
        ]
        metric = FisherMetric.gaussian(2)
        
        problem = MathematicalProblem(
            problem_type='geometric_statistics',
            description='Compute Fréchet mean',
            input_data={
                'objects': objects,
                'metric': metric,
                'operation': 'frechet_mean'
            }
        )
        
        result = reasoner.solve_geometric_statistics(problem)
        assert 'mean' in result
        assert isinstance(result['mean'], ChiralObject)

    def test_geometric_variance(self):
        """Test geometric variance computation."""
        engine = SpiralLLMMath()
        reasoner = InfoGeometryReasoner(engine)
        
        objects = [
            ChiralObject(np.array([0.0, 0.0]), Chirality.NEUTRAL),
            ChiralObject(np.array([1.0, 1.0]), Chirality.NEUTRAL)
        ]
        metric = FisherMetric.gaussian(2)
        
        problem = MathematicalProblem(
            problem_type='geometric_statistics',
            description='Compute geometric variance',
            input_data={
                'objects': objects,
                'metric': metric,
                'operation': 'variance'
            }
        )
        
        result = reasoner.solve_geometric_statistics(problem)
        assert 'variance' in result
        assert result['variance'] >= 0

    def test_geodesic_interpolation(self):
        """Test geodesic interpolation."""
        engine = SpiralLLMMath()
        reasoner = InfoGeometryReasoner(engine)
        
        obj1 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        obj2 = ChiralObject(np.array([1.0, 1.0]), Chirality.RIGHT)
        metric = FisherMetric.gaussian(2)
        
        problem = MathematicalProblem(
            problem_type='geometric_statistics',
            description='Geodesic interpolation',
            input_data={
                'object1': obj1,
                'object2': obj2,
                'metric': metric,
                'operation': 'interpolate',
                't': 0.5
            }
        )
        
        result = reasoner.solve_geometric_statistics(problem)
        assert 'interpolated' in result
        assert isinstance(result['interpolated'], ChiralObject)

    def test_exponential_family(self):
        """Test exponential family analysis."""
        engine = SpiralLLMMath()
        reasoner = InfoGeometryReasoner(engine)
        
        problem = MathematicalProblem(
            problem_type='exponential_family',
            description='Gaussian exponential family',
            input_data={
                'family_type': 'gaussian',
                'mean': 0.0,
                'variance': 1.0,
                'params': np.array([0.0, 0.0])
            }
        )
        
        result = reasoner.solve_exponential_family(problem)
        assert 'family' in result
        assert 'fisher_metric' in result

    def test_manifold_reasoning(self):
        """Test statistical manifold reasoning."""
        reasoner = InfoGeometryReasoner()
        
        metric = FisherMetric.gaussian(2)
        points = [
            np.array([0.0, 0.0]),
            np.array([1.0, 0.0]),
            np.array([0.0, 1.0])
        ]
        
        analysis = reasoner.reason_about_manifold(metric, points)
        
        assert 'distance_matrix' in analysis
        assert 'scalar_curvature' in analysis
        assert 'average_curvature' in analysis

    def test_divergence_explanation(self):
        """Test divergence explanation generation."""
        reasoner = InfoGeometryReasoner()
        
        result = {
            'divergence_type': 'kl',
            'value': 0.5,
            'symmetric': False
        }
        
        explanation = reasoner.explain_divergence(result)
        
        assert isinstance(explanation, str)
        assert 'KL' in explanation or 'kl' in explanation.lower()
        assert '0.5' in explanation

    def test_chiral_effects_analysis(self):
        """Test chirality effects analysis."""
        reasoner = InfoGeometryReasoner()
        
        obj1 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        obj2 = ChiralObject(np.array([0.1, 0.1]), Chirality.RIGHT)
        
        analysis = reasoner.analyze_chiral_effects(obj1, obj2)
        
        assert 'kl_divergence' in analysis
        assert 'same_chirality' in analysis
        assert analysis['same_chirality'] == False
        assert 'chirality_penalty' in analysis

    def test_verification(self):
        """Test divergence verification."""
        engine = SpiralLLMMath()
        reasoner = InfoGeometryReasoner(engine)
        
        obj1 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        obj2 = ChiralObject(np.array([1.0, 1.0]), Chirality.LEFT)
        
        problem = MathematicalProblem(
            problem_type='divergence',
            description='Test',
            input_data={'object1': obj1, 'object2': obj2, 'type': 'kl'}
        )
        
        result = {'value': 0.5, 'divergence_type': 'kl'}
        verification = reasoner.verify_divergence(problem, result)
        
        assert verification['status'] == True

    def test_negative_divergence_detection(self):
        """Test detection of invalid negative divergence."""
        engine = SpiralLLMMath()
        reasoner = InfoGeometryReasoner(engine)
        
        problem = MathematicalProblem(
            problem_type='divergence',
            description='Test',
            input_data={}
        )
        
        result = {'value': -0.5}  # Invalid!
        verification = reasoner.verify_divergence(problem, result)
        
        assert verification['status'] == False
        assert 'negative' in verification['message'].lower()

    def test_integrated_solve(self):
        """Test integrated solving through engine."""
        engine = SpiralLLMMath()
        reasoner = InfoGeometryReasoner(engine)
        
        obj1 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        obj2 = ChiralObject(np.array([0.5, 0.5]), Chirality.LEFT)
        
        problem = MathematicalProblem(
            problem_type='divergence',
            description='Integrated divergence test',
            input_data={
                'object1': obj1,
                'object2': obj2,
                'type': 'kl'
            }
        )
        
        solution = engine.solve(problem)
        
        assert solution.result is not None
        assert 'value' in solution.result
