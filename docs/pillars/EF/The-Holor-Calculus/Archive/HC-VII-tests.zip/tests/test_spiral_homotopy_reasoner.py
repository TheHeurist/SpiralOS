"""Tests for SpiralLLM-Math Homotopy Reasoner."""

import pytest
import numpy as np

from holor_calculus import (
    SpiralLLMMath, MathematicalProblem,
    HomotopyReasoner,
    ChiralObject, Chirality,
    ChiralPath, ChiralHomotopy, ProofDeformation, FundamentalGroup
)


class TestHomotopyReasoner:
    """Test homotopy reasoner functionality."""

    def test_initialization(self):
        """Test reasoner initialization."""
        engine = SpiralLLMMath()
        reasoner = HomotopyReasoner(engine)
        
        assert reasoner.spiral_engine == engine
        assert 'homotopy' in engine.reasoners
        assert 'path_equivalence' in engine.reasoners

    def test_create_homotopy(self):
        """Test homotopy creation."""
        engine = SpiralLLMMath()
        reasoner = HomotopyReasoner(engine)
        
        p0 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        p1 = ChiralObject(np.array([1.0, 1.0]), Chirality.RIGHT)
        path1 = ChiralPath(p0, p1)
        path2 = ChiralPath(p0, p1)
        
        problem = MathematicalProblem(
            problem_type='homotopy',
            description='Create homotopy',
            input_data={
                'path1': path1,
                'path2': path2,
                'operation': 'create'
            }
        )
        
        result = reasoner.solve_homotopy(problem)
        assert 'homotopy' in result
        assert isinstance(result['homotopy'], ChiralHomotopy)

    def test_path_equivalence(self):
        """Test path equivalence checking."""
        engine = SpiralLLMMath()
        reasoner = HomotopyReasoner(engine)
        
        p0 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        p1 = ChiralObject(np.array([1.0, 1.0]), Chirality.LEFT)
        path1 = ChiralPath(p0, p1)
        path2 = ChiralPath(p0, p1)
        
        problem = MathematicalProblem(
            problem_type='path_equivalence',
            description='Check path equivalence',
            input_data={'path1': path1, 'path2': path2}
        )
        
        result = reasoner.solve_path_equivalence(problem)
        assert result['equivalent'] == True
        assert result['endpoints_match'] == True

    def test_path_non_equivalence(self):
        """Test detection of non-equivalent paths."""
        engine = SpiralLLMMath()
        reasoner = HomotopyReasoner(engine)
        
        p0 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        p1 = ChiralObject(np.array([1.0, 1.0]), Chirality.LEFT)
        p2 = ChiralObject(np.array([2.0, 2.0]), Chirality.LEFT)
        path1 = ChiralPath(p0, p1)
        path2 = ChiralPath(p0, p2)
        
        problem = MathematicalProblem(
            problem_type='path_equivalence',
            description='Check non-equivalent paths',
            input_data={'path1': path1, 'path2': path2}
        )
        
        result = reasoner.solve_path_equivalence(problem)
        assert result['equivalent'] == False
        assert result['endpoints_match'] == False

    def test_fundamental_group(self):
        """Test fundamental group computation."""
        engine = SpiralLLMMath()
        reasoner = HomotopyReasoner(engine)
        
        basepoint = ChiralObject(np.array([0.0, 0.0]), Chirality.NEUTRAL)
        loop1 = ChiralPath(basepoint, basepoint)
        loop2 = ChiralPath(basepoint, basepoint)
        
        problem = MathematicalProblem(
            problem_type='fundamental_group',
            description='Compute fundamental group',
            input_data={
                'basepoint': basepoint,
                'loops': [loop1, loop2]
            }
        )
        
        result = reasoner.solve_fundamental_group(problem)
        assert 'fundamental_group' in result
        assert isinstance(result['fundamental_group'], FundamentalGroup)
        assert result['num_classes'] >= 0

    def test_winding_number(self):
        """Test winding number computation."""
        engine = SpiralLLMMath()
        reasoner = HomotopyReasoner(engine)
        
        # Create a loop (start = end)
        p0 = ChiralObject(np.array([1.0, 0.0]), Chirality.NEUTRAL)
        path = ChiralPath(p0, p0)
        
        problem = MathematicalProblem(
            problem_type='homotopy',
            description='Compute winding number',
            input_data={
                'path': path,
                'operation': 'compute_winding'
            }
        )
        
        result = reasoner.solve_homotopy(problem)
        assert 'winding_number' in result
        assert isinstance(result['winding_number'], (int, float))
        assert result['is_loop'] == True

    def test_deformation_reasoning(self):
        """Test reasoning about proof deformation."""
        reasoner = HomotopyReasoner()
        
        p0 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        p1 = ChiralObject(np.array([1.0, 1.0]), Chirality.RIGHT)
        deformation = ProofDeformation(initial_proof=[p0, p1])
        
        t_values = [0.0, 0.25, 0.5, 0.75, 1.0]
        analysis = reasoner.reason_about_deformation(deformation, t_values)
        
        assert 'samples' in analysis
        assert 'chiralities' in analysis
        assert 'transitions' in analysis
        assert len(analysis['samples']) == 5

    def test_homotopy_explanation(self):
        """Test natural language homotopy explanation."""
        reasoner = HomotopyReasoner()
        
        p0 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        p1 = ChiralObject(np.array([1.0, 1.0]), Chirality.LEFT)
        path1 = ChiralPath(p0, p1)
        path2 = ChiralPath(p0, p1)
        homotopy = ChiralHomotopy(path1, path2)
        
        explanation = reasoner.explain_homotopy(homotopy)
        
        assert isinstance(explanation, str)
        assert 'Homotopy' in explanation
        assert 'deformation' in explanation.lower()

    def test_verification(self):
        """Test homotopy verification."""
        engine = SpiralLLMMath()
        reasoner = HomotopyReasoner(engine)
        
        p0 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        p1 = ChiralObject(np.array([1.0, 1.0]), Chirality.LEFT)
        path = ChiralPath(p0, p1)
        
        problem = MathematicalProblem(
            problem_type='homotopy',
            description='Test',
            input_data={'operation': 'create', 'path1': path, 'path2': path}
        )
        
        result = {'homotopy': ChiralHomotopy(path, path), 'chirality_class': 'test'}
        verification = reasoner.verify_homotopy(problem, result)
        
        assert verification['status'] == True

    def test_integrated_solve(self):
        """Test integrated solving through engine."""
        engine = SpiralLLMMath()
        reasoner = HomotopyReasoner(engine)
        
        p0 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        p1 = ChiralObject(np.array([1.0, 1.0]), Chirality.RIGHT)
        path1 = ChiralPath(p0, p1)
        path2 = ChiralPath(p0, p1)
        
        problem = MathematicalProblem(
            problem_type='homotopy',
            description='Integrated homotopy test',
            input_data={
                'path1': path1,
                'path2': path2,
                'operation': 'create'
            }
        )
        
        solution = engine.solve(problem)
        
        assert solution.result is not None
        assert 'homotopy' in solution.result
