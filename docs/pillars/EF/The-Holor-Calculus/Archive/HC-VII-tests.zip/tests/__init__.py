"""Tests for Holor Calculus VII."""
