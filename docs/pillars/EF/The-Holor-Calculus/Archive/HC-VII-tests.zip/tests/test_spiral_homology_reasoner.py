"""Tests for SpiralLLM-Math Homology Reasoner."""

import pytest
import numpy as np

from holor_calculus import (
    SpiralLLMMath, MathematicalProblem,
    HomologyReasoner,
    ChiralObject, Chirality,
    ChiralSimplex, ChiralChain, ChiralChainComplex,
    ChiralSimplicialComplex, create_standard_simplex
)


class TestHomologyReasoner:
    """Test homology reasoner functionality."""

    def test_initialization(self):
        """Test reasoner initialization."""
        engine = SpiralLLMMath()
        reasoner = HomologyReasoner(engine)
        
        assert reasoner.spiral_engine == engine
        assert 'homology' in engine.reasoners
        assert 'chain_boundary' in engine.reasoners
        assert 'betti_numbers' in engine.reasoners
        assert 'euler_characteristic' in engine.reasoners

    def test_chain_boundary_problem(self):
        """Test chain boundary computation."""
        engine = SpiralLLMMath()
        reasoner = HomologyReasoner(engine)
        
        # Create a 2-chain
        simplex = ChiralSimplex((0, 1, 2))
        chain = ChiralChain({simplex: 1.0})
        
        problem = MathematicalProblem(
            problem_type='chain_boundary',
            description='Compute boundary',
            input_data={'chain': chain}
        )
        
        result = reasoner.solve_chain_boundary(problem)
        
        assert 'boundary' in result
        assert 'chain_dimension' in result
        assert 'boundary_dimension' in result
        assert 'boundary_property_verified' in result
        assert result['boundary_property_verified'] == True

    def test_betti_numbers_computation(self):
        """Test Betti number computation."""
        engine = SpiralLLMMath()
        reasoner = HomologyReasoner(engine)
        
        # Create triangle complex
        complex_obj = create_standard_simplex(2, Chirality.NEUTRAL)
        
        problem = MathematicalProblem(
            problem_type='betti_numbers',
            description='Compute Betti numbers',
            input_data={'complex': complex_obj}
        )
        
        result = reasoner.solve_betti_numbers(problem)
        
        assert 'betti_numbers' in result
        assert 'euler_characteristic' in result
        assert 'topology_type' in result
        assert isinstance(result['betti_numbers'], list)
        assert len(result['betti_numbers']) > 0

    def test_euler_characteristic_computation(self):
        """Test Euler characteristic computation."""
        engine = SpiralLLMMath()
        reasoner = HomologyReasoner(engine)
        
        complex_obj = create_standard_simplex(2, Chirality.NEUTRAL)
        
        problem = MathematicalProblem(
            problem_type='euler_characteristic',
            description='Compute Euler characteristic',
            input_data={'complex': complex_obj}
        )
        
        result = reasoner.solve_euler_characteristic(problem)
        
        assert 'euler_characteristic' in result
        assert 'f_vector' in result
        assert 'betti_numbers' in result
        assert result['euler_characteristic'] == 1  # Triangle is contractible

    def test_boundary_squared_zero_verification(self):
        """Test verification of ∂∂ = 0."""
        engine = SpiralLLMMath()
        reasoner = HomologyReasoner(engine)
        
        # Create 2-chain
        simplex = ChiralSimplex((0, 1, 2))
        chain = ChiralChain({simplex: 1.0})
        
        problem = MathematicalProblem(
            problem_type='homology',
            description='Verify boundary property',
            input_data={
                'chain': chain,
                'operation': 'verify_boundary_property'
            }
        )
        
        result = reasoner._verify_boundary_squared_zero(problem)
        
        assert 'verified' in result
        assert result['verified'] == True
        assert 'fundamental_property' in result

    def test_topology_classification(self):
        """Test topological type classification."""
        engine = SpiralLLMMath()
        reasoner = HomologyReasoner(engine)
        
        # Test different topologies
        betti_contractible = [1, 0, 0]
        betti_circle = [1, 1]
        betti_disconnected = [3, 0]
        
        type1 = reasoner._classify_topology(betti_contractible)
        assert 'contractible' in type1 or 'simply-connected' in type1
        
        type2 = reasoner._classify_topology(betti_circle)
        assert 'loop' in type2
        
        type3 = reasoner._classify_topology(betti_disconnected)
        assert '3' in type3

    def test_simplicial_complex_analysis(self):
        """Test comprehensive complex analysis."""
        engine = SpiralLLMMath()
        reasoner = HomologyReasoner(engine)
        
        vertices = [ChiralObject(np.zeros(2), Chirality.NEUTRAL) for _ in range(3)]
        complex_obj = ChiralSimplicialComplex(vertices)
        complex_obj.add_simplex([0, 1, 2])
        
        problem = MathematicalProblem(
            problem_type='homology',
            description='Analyze complex',
            input_data={
                'complex': complex_obj,
                'operation': 'analyze_complex'
            }
        )
        
        result = reasoner._analyze_simplicial_complex(problem)
        
        assert 'dimension' in result
        assert 'f_vector' in result
        assert 'euler_characteristic' in result
        assert 'betti_numbers' in result
        assert 'chirality_distribution' in result

    def test_homology_verification(self):
        """Test homology solution verification."""
        engine = SpiralLLMMath()
        reasoner = HomologyReasoner(engine)
        
        complex_obj = create_standard_simplex(2, Chirality.NEUTRAL)
        
        problem = MathematicalProblem(
            problem_type='betti_numbers',
            description='Test',
            input_data={'complex': complex_obj}
        )
        
        # Create result dict
        result = {
            'betti_numbers': [1, 0, 0],
            'euler_characteristic': 1,
            'euler_from_betti': 1,
            'boundary_property_verified': True
        }
        
        verification = reasoner.verify_homology(problem, result)
        
        assert 'checks' in verification
        assert 'all_passed' in verification
        assert verification['all_passed'] == True


class TestHomologyExplanations:
    """Test explanation generation."""

    def test_boundary_explanation(self):
        """Test boundary computation explanation."""
        reasoner = HomologyReasoner()
        
        simplex = ChiralSimplex((0, 1, 2))
        chain = ChiralChain({simplex: 1.0})
        boundary = chain.boundary()
        
        explanation = reasoner._explain_boundary_computation(chain, boundary)
        
        assert isinstance(explanation, str)
        assert len(explanation) > 0

    def test_betti_explanation(self):
        """Test Betti numbers explanation."""
        reasoner = HomologyReasoner()
        
        betti = [1, 1, 0]
        topology = "has_one_loop"
        
        explanation = reasoner._explain_betti_numbers(betti, topology)
        
        assert 'β_0' in explanation
        assert 'β_1' in explanation
        assert 'connected' in explanation.lower()

    def test_euler_explanation(self):
        """Test Euler characteristic explanation."""
        reasoner = HomologyReasoner()
        
        euler = 1
        f_vec = [3, 3, 1]
        betti = [1, 0, 0]
        
        explanation = reasoner._explain_euler_characteristic(euler, f_vec, betti)
        
        assert 'χ' in explanation
        assert str(euler) in explanation


class TestIntegratedHomologyReasoning:
    """Integration tests for homology reasoning."""

    def test_full_homology_workflow(self):
        """Test complete homology problem-solving workflow."""
        from holor_calculus import SpiralProblemSolver
        
        solver = SpiralProblemSolver()
        
        # Create simplicial complex
        complex_obj = create_standard_simplex(2, Chirality.NEUTRAL)
        
        # Solve Betti numbers problem
        solution = solver.solve_betti_numbers_problem(complex_obj)
        
        assert solution.result is not None
        assert 'betti_numbers' in solution.result
        assert len(solution.reasoning_chain) >= 0

    def test_euler_characteristic_workflow(self):
        """Test Euler characteristic computation workflow."""
        from holor_calculus import SpiralProblemSolver
        
        solver = SpiralProblemSolver()
        complex_obj = create_standard_simplex(2, Chirality.NEUTRAL)
        
        solution = solver.solve_euler_characteristic_problem(complex_obj)
        
        assert solution.result is not None
        assert 'euler_characteristic' in solution.result
