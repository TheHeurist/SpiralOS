"""§5 - Tests for Homotopy of Chiral Proofs."""

import pytest
import numpy as np
from holor_calculus.chiral_base import ChiralObject, Chirality, ChiralSpace
from holor_calculus.homotopy import (
    ChiralPath, ChiralHomotopy, HigherHomotopy, ProofDeformation,
    FundamentalGroup, construct_geodesic_homotopy, compute_winding_number
)


class TestChiralPath:
    def test_path_creation(self):
        start = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        end = ChiralObject(np.array([1.0, 1.0]), Chirality.RIGHT)
        path = ChiralPath(start, end)
        
        assert path.start.distance(start) < 1e-10
        assert path.end.distance(end) < 1e-10
    
    def test_path_evaluation(self):
        start = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        end = ChiralObject(np.array([2.0, 2.0]), Chirality.LEFT)
        path = ChiralPath(start, end)
        
        mid = path(0.5)
        assert np.allclose(mid.data, [1.0, 1.0])
    
    def test_path_endpoints(self):
        start = ChiralObject(np.array([1.0, 2.0]), Chirality.RIGHT)
        end = ChiralObject(np.array([3.0, 4.0]), Chirality.RIGHT)
        path = ChiralPath(start, end)
        
        assert np.allclose(path(0.0).data, start.data)
        assert np.allclose(path(1.0).data, end.data)
    
    def test_path_length(self):
        start = ChiralObject(np.array([0.0, 0.0]), Chirality.NEUTRAL)
        end = ChiralObject(np.array([3.0, 4.0]), Chirality.NEUTRAL)
        path = ChiralPath(start, end)
        
        # Linear path length should be ~5
        length = path.length()
        assert abs(length - 5.0) < 0.1
    
    def test_path_reverse(self):
        start = ChiralObject(np.array([0.0]), Chirality.LEFT)
        end = ChiralObject(np.array([1.0]), Chirality.LEFT)
        path = ChiralPath(start, end)
        
        rev = path.reverse()
        assert np.allclose(rev(0.0).data, end.data)
        assert np.allclose(rev(1.0).data, start.data)
    
    def test_path_composition(self):
        p0 = ChiralObject(np.array([0.0]), Chirality.NEUTRAL)
        p1 = ChiralObject(np.array([1.0]), Chirality.NEUTRAL)
        p2 = ChiralObject(np.array([2.0]), Chirality.NEUTRAL)
        
        path1 = ChiralPath(p0, p1)
        path2 = ChiralPath(p1, p2)
        
        composed = path1.compose(path2)
        assert np.allclose(composed(0.0).data, p0.data)
        assert np.allclose(composed(1.0).data, p2.data)
    
    def test_is_loop(self):
        p = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
        loop = ChiralPath(p, p)
        assert loop.is_loop()
        
        p2 = ChiralObject(np.array([1.0, 0.0]), Chirality.LEFT)
        not_loop = ChiralPath(p, p2)
        assert not not_loop.is_loop()
    
    def test_chirality_preserved(self):
        left = ChiralObject(np.array([0.0]), Chirality.LEFT)
        left2 = ChiralObject(np.array([1.0]), Chirality.LEFT)
        right = ChiralObject(np.array([1.0]), Chirality.RIGHT)
        
        path_preserved = ChiralPath(left, left2)
        assert path_preserved.chirality_preserved()
        
        path_not_preserved = ChiralPath(left, right)
        assert not path_not_preserved.chirality_preserved()


class TestChiralHomotopy:
    def test_homotopy_creation(self):
        start = ChiralObject(np.array([0.0, 0.0]), Chirality.NEUTRAL)
        end = ChiralObject(np.array([1.0, 0.0]), Chirality.NEUTRAL)
        
        path0 = ChiralPath(start, end)
        path1 = ChiralPath(start, end, 
                          interpolation=lambda t: ChiralObject(
                              np.array([t, 0.5*np.sin(np.pi*t)]), Chirality.NEUTRAL))
        
        h = ChiralHomotopy(path0, path1)
        assert h.path0 is path0
        assert h.path1 is path1
    
    def test_homotopy_endpoints_check(self):
        p0 = ChiralObject(np.array([0.0]), Chirality.NEUTRAL)
        p1 = ChiralObject(np.array([1.0]), Chirality.NEUTRAL)
        p2 = ChiralObject(np.array([2.0]), Chirality.NEUTRAL)
        
        path1 = ChiralPath(p0, p1)
        path2 = ChiralPath(p0, p2)  # Different endpoint
        
        with pytest.raises(ValueError):
            ChiralHomotopy(path1, path2)
    
    def test_homotopy_evaluation(self):
        start = ChiralObject(np.array([0.0]), Chirality.NEUTRAL)
        end = ChiralObject(np.array([1.0]), Chirality.NEUTRAL)
        
        path0 = ChiralPath(start, end)
        path1 = ChiralPath(start, end)
        
        h = ChiralHomotopy(path0, path1)
        
        # At boundaries
        assert np.allclose(h(0, 0).data, start.data)
        assert np.allclose(h(1, 1).data, end.data)
    
    def test_intermediate_path(self):
        start = ChiralObject(np.array([0.0, 0.0]), Chirality.NEUTRAL)
        end = ChiralObject(np.array([1.0, 0.0]), Chirality.NEUTRAL)
        
        path0 = ChiralPath(start, end)
        path1 = ChiralPath(start, end)
        
        h = ChiralHomotopy(path0, path1)
        mid_path = h.path_at(0.5)
        
        assert np.allclose(mid_path.start.data, start.data)
        assert np.allclose(mid_path.end.data, end.data)
    
    def test_identity_homotopy(self):
        start = ChiralObject(np.array([0.0]), Chirality.LEFT)
        end = ChiralObject(np.array([1.0]), Chirality.LEFT)
        path = ChiralPath(start, end)
        
        h = ChiralHomotopy(path, path)
        assert h.is_identity()
    
    def test_chirality_class(self):
        start_l = ChiralObject(np.array([0.0]), Chirality.LEFT)
        end_l = ChiralObject(np.array([1.0]), Chirality.LEFT)
        start_r = ChiralObject(np.array([0.0]), Chirality.RIGHT)
        end_r = ChiralObject(np.array([1.0]), Chirality.RIGHT)
        
        path_preserved = ChiralPath(start_l, end_l)
        h = ChiralHomotopy(path_preserved, path_preserved)
        assert h.chirality_class() == "chiral_preserving"


class TestHigherHomotopy:
    def test_higher_homotopy_level1(self):
        space = ChiralSpace(dimension=2)
        
        def path_map(t: float) -> ChiralObject:
            return ChiralObject(np.array([t, t**2]), Chirality.NEUTRAL)
        
        hh = HigherHomotopy(level=1, base_space=space, map_function=path_map)
        
        p = hh(0.5)
        assert np.allclose(p.data, [0.5, 0.25])
    
    def test_higher_homotopy_level2(self):
        space = ChiralSpace(dimension=2)
        
        def homotopy_map(s: float, t: float) -> ChiralObject:
            return ChiralObject(np.array([s*t, (1-s)*t]), Chirality.NEUTRAL)
        
        hh = HigherHomotopy(level=2, base_space=space, map_function=homotopy_map)
        
        p = hh(0.5, 1.0)
        assert np.allclose(p.data, [0.5, 0.5])
    
    def test_boundary(self):
        space = ChiralSpace(dimension=1)
        
        def homotopy_map(s: float, t: float) -> ChiralObject:
            return ChiralObject(np.array([s + t]), Chirality.NEUTRAL)
        
        hh = HigherHomotopy(level=2, base_space=space, map_function=homotopy_map)
        
        # Fix s=0
        boundary = hh.boundary(0, 0.0)
        assert boundary.level == 1
        assert np.allclose(boundary(0.5).data, [0.5])  # 0 + 0.5
    
    def test_wrong_params(self):
        space = ChiralSpace(dimension=1)
        hh = HigherHomotopy(level=2, base_space=space, 
                           map_function=lambda s, t: ChiralObject(np.array([s+t]), Chirality.NEUTRAL))
        
        with pytest.raises(ValueError):
            hh(0.5)  # Only 1 param instead of 2


class TestProofDeformation:
    def test_proof_deformation_creation(self):
        steps = [
            ChiralObject(np.array([1.0, 0.0]), Chirality.LEFT),
            ChiralObject(np.array([0.0, 1.0]), Chirality.LEFT),
            ChiralObject(np.array([1.0, 1.0]), Chirality.LEFT),
        ]
        pd = ProofDeformation(steps)
        assert pd.step_count() == 3
    
    def test_deform(self):
        steps = [
            ChiralObject(np.array([1.0]), Chirality.NEUTRAL),
            ChiralObject(np.array([2.0]), Chirality.NEUTRAL),
        ]
        pd = ProofDeformation(steps)
        
        deformed = pd.deform(0.0)
        assert len(deformed) == 2
        assert np.allclose(deformed[0].data, [1.0])
    
    def test_path_to(self):
        steps = [
            ChiralObject(np.array([1.0, 2.0]), Chirality.RIGHT),
        ]
        pd = ProofDeformation(steps)
        
        path = pd.path_to(1.0)
        assert path.start is not None
        assert path.end is not None
    
    def test_is_valid(self):
        steps = [
            ChiralObject(np.array([1.0]), Chirality.LEFT),
            ChiralObject(np.array([2.0]), Chirality.LEFT),
            ChiralObject(np.array([3.0]), Chirality.LEFT),
        ]
        pd = ProofDeformation(steps)
        assert pd.is_valid()
    
    def test_homotopy_equivalence(self):
        steps1 = [ChiralObject(np.array([1.0]), Chirality.NEUTRAL)]
        steps2 = [ChiralObject(np.array([2.0]), Chirality.NEUTRAL)]
        
        pd1 = ProofDeformation(steps1)
        pd2 = ProofDeformation(steps2)
        
        h = pd1.homotopy_equivalence(pd2)
        assert h is not None  # Same step count, should find equivalence


class TestFundamentalGroup:
    def test_fundamental_group_creation(self):
        base = ChiralObject(np.array([0.0, 0.0]), Chirality.NEUTRAL)
        fg = FundamentalGroup(base)
        assert fg.base_point is base
        assert len(fg.loops) == 0
    
    def test_add_loop(self):
        base = ChiralObject(np.array([0.0, 0.0]), Chirality.NEUTRAL)
        fg = FundamentalGroup(base)
        
        # Create a circular loop
        def circle(t: float) -> ChiralObject:
            angle = 2 * np.pi * t
            return ChiralObject(np.array([np.cos(angle) - 1, np.sin(angle)]), Chirality.NEUTRAL)
        
        loop = ChiralPath(base, base, interpolation=circle)
        fg.add_loop(loop)
        assert len(fg.loops) == 1
    
    def test_trivial_loop(self):
        base = ChiralObject(np.array([1.0, 1.0]), Chirality.LEFT)
        fg = FundamentalGroup(base)
        
        trivial = fg.trivial_loop()
        assert trivial.is_loop()
        assert trivial.length() < 0.01  # Constant loop has ~0 length
    
    def test_inverse_loop(self):
        base = ChiralObject(np.array([0.0]), Chirality.NEUTRAL)
        fg = FundamentalGroup(base)
        
        def forward(t: float) -> ChiralObject:
            return ChiralObject(np.array([np.sin(2*np.pi*t)]), Chirality.NEUTRAL)
        
        loop = ChiralPath(base, base, interpolation=forward)
        inv = fg.inverse_loop(loop)
        
        # Inverse at t should be original at 1-t
        assert np.allclose(inv(0.25).data, loop(0.75).data)
    
    def test_are_homotopic(self):
        base = ChiralObject(np.array([0.0, 0.0]), Chirality.NEUTRAL)
        fg = FundamentalGroup(base)
        
        trivial1 = fg.trivial_loop()
        trivial2 = fg.trivial_loop()
        
        assert fg.are_homotopic(trivial1, trivial2)


class TestUtilityFunctions:
    def test_geodesic_homotopy(self):
        space = ChiralSpace(dimension=3)
        p0 = ChiralObject(np.array([0.0, 0.0, 0.0]), Chirality.LEFT)
        p1 = ChiralObject(np.array([1.0, 1.0, 1.0]), Chirality.LEFT)
        
        path = construct_geodesic_homotopy(space, p0, p1)
        
        assert np.allclose(path(0.0).data, p0.data)
        assert np.allclose(path(1.0).data, p1.data)
    
    def test_winding_number_zero(self):
        center = ChiralObject(np.array([0.0, 0.0]), Chirality.NEUTRAL)
        
        # Trivial loop (constant)
        trivial = ChiralPath(center, center, interpolation=lambda t: center)
        wn = compute_winding_number(trivial)
        assert wn == 0
    
    def test_winding_number_one(self):
        center = ChiralObject(np.array([1.0, 0.0]), Chirality.NEUTRAL)
        
        # Circle around origin
        def circle(t: float) -> ChiralObject:
            angle = 2 * np.pi * t
            return ChiralObject(np.array([np.cos(angle), np.sin(angle)]), Chirality.NEUTRAL)
        
        loop = ChiralPath(center, center, interpolation=circle)
        wn = compute_winding_number(loop)
        assert wn == 1
    
    def test_winding_number_negative(self):
        center = ChiralObject(np.array([1.0, 0.0]), Chirality.NEUTRAL)
        
        # Clockwise circle
        def clockwise_circle(t: float) -> ChiralObject:
            angle = -2 * np.pi * t
            return ChiralObject(np.array([np.cos(angle), np.sin(angle)]), Chirality.NEUTRAL)
        
        loop = ChiralPath(center, center, interpolation=clockwise_circle)
        wn = compute_winding_number(loop)
        assert wn == -1
