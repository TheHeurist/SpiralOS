"""§6 - Tests for Chiral Information Geometry."""

import pytest
import numpy as np
from holor_calculus.chiral_base import ChiralObject, Chirality
from holor_calculus.info_geometry import (
    ChiralDistribution, FisherMetric, ChiralDivergence, GeometricStatistics,
    ChiralExponentialFamily, create_gaussian_exponential_family
)


class TestChiralDistribution:
    def test_distribution_creation(self):
        dist = ChiralDistribution(np.array([0.0, 1.0]), Chirality.LEFT)
        assert dist.dimension == 2
        assert dist.chirality == Chirality.LEFT
    
    def test_density(self):
        dist = ChiralDistribution(np.array([0.0]), Chirality.NEUTRAL)
        # At the mean, density should be maximal
        d0 = dist.density(np.array([0.0]))
        d1 = dist.density(np.array([1.0]))
        assert d0 > d1
    
    def test_sample(self):
        dist = ChiralDistribution(np.array([5.0]), Chirality.RIGHT)
        samples = dist.sample(100)
        assert samples.shape == (100, 1)
        # Mean should be close to parameter
        assert abs(np.mean(samples) - 5.0) < 1.0


class TestFisherMetric:
    def test_gaussian_metric(self):
        metric = FisherMetric.gaussian(3)
        assert metric.dimension == 3
        assert metric._metric_matrix.shape == (3, 3)
        assert np.allclose(metric._metric_matrix, np.eye(3))
    
    def test_metric_tensor(self):
        metric = FisherMetric(dimension=2)
        g = metric.metric_tensor()
        assert g.shape == (2, 2)
        assert np.allclose(g, np.eye(2))
    
    def test_inner_product(self):
        metric = FisherMetric.gaussian(2)
        v1 = np.array([1.0, 0.0])
        v2 = np.array([0.0, 1.0])
        
        # Orthogonal vectors
        assert abs(metric.inner_product(v1, v2)) < 1e-10
        # Same vector
        assert abs(metric.inner_product(v1, v1) - 1.0) < 1e-10
    
    def test_norm(self):
        metric = FisherMetric.gaussian(3)
        v = np.array([3.0, 4.0, 0.0])
        assert abs(metric.norm(v) - 5.0) < 1e-10
    
    def test_geodesic_distance(self):
        metric = FisherMetric.gaussian(2)
        p1 = np.array([0.0, 0.0])
        p2 = np.array([3.0, 4.0])
        
        dist = metric.geodesic_distance(p1, p2)
        assert abs(dist - 5.0) < 1e-10
    
    def test_volume_element(self):
        metric = FisherMetric.gaussian(3)
        vol = metric.volume_element()
        assert abs(vol - 1.0) < 1e-10  # Identity matrix has det=1
    
    def test_from_distribution(self):
        dist = ChiralDistribution(np.array([0.0, 1.0]), Chirality.LEFT)
        metric = FisherMetric.from_distribution(dist)
        
        assert metric.dimension == 2
        assert metric.chirality == Chirality.LEFT
        # Should be positive definite
        eigvals = np.linalg.eigvalsh(metric._metric_matrix)
        assert all(eigvals > 0)
    
    def test_christoffel_symbols(self):
        metric = FisherMetric.gaussian(2)
        gamma = metric.christoffel_symbols(np.array([0.0, 0.0]))
        # For flat metric, should be zero
        assert np.allclose(gamma, 0)
    
    def test_scalar_curvature(self):
        metric = FisherMetric.gaussian(2)
        R = metric.scalar_curvature()
        assert abs(R) < 1e-10  # Flat


class TestChiralDivergence:
    def test_kl_divergence_same(self):
        p = ChiralDistribution(np.array([0.0]), Chirality.NEUTRAL)
        kl = ChiralDivergence.kl_divergence(p, p)
        assert kl >= 0
        assert kl < 0.5  # Should be near 0 for same dist
    
    def test_kl_divergence_different(self):
        p = ChiralDistribution(np.array([0.0]), Chirality.NEUTRAL)
        q = ChiralDistribution(np.array([5.0]), Chirality.NEUTRAL)
        kl = ChiralDivergence.kl_divergence(p, q)
        assert kl > 0
    
    def test_kl_chiral_penalty(self):
        p = ChiralDistribution(np.array([0.0]), Chirality.LEFT)
        q_same = ChiralDistribution(np.array([1.0]), Chirality.LEFT)
        q_diff = ChiralDistribution(np.array([1.0]), Chirality.RIGHT)
        
        kl_same = ChiralDivergence.kl_divergence(p, q_same)
        kl_diff = ChiralDivergence.kl_divergence(p, q_diff)
        
        # Different chirality should have penalty
        assert kl_diff >= kl_same
    
    def test_symmetric_kl(self):
        p = ChiralDistribution(np.array([0.0]), Chirality.NEUTRAL)
        q = ChiralDistribution(np.array([1.0]), Chirality.NEUTRAL)
        
        sym = ChiralDivergence.symmetric_kl(p, q)
        assert sym >= 0
    
    def test_alpha_divergence_limits(self):
        p = ChiralDistribution(np.array([0.0]), Chirality.NEUTRAL)
        q = ChiralDistribution(np.array([1.0]), Chirality.NEUTRAL)
        
        # alpha=1 should be close to KL(p||q)
        d1 = ChiralDivergence.alpha_divergence(p, q, alpha=1.0)
        kl = ChiralDivergence.kl_divergence(p, q)
        assert abs(d1 - kl) < 0.5
        
        # alpha=0 should be close to KL(q||p)
        d0 = ChiralDivergence.alpha_divergence(p, q, alpha=0.0)
        kl_rev = ChiralDivergence.kl_divergence(q, p)
        assert abs(d0 - kl_rev) < 0.5
    
    def test_hellinger_distance(self):
        p = ChiralDistribution(np.array([0.0]), Chirality.NEUTRAL)
        q = ChiralDistribution(np.array([0.0]), Chirality.NEUTRAL)
        
        h = ChiralDivergence.hellinger_distance(p, q)
        assert h >= 0
        assert h < 0.5  # Same distribution
    
    def test_fisher_rao_distance(self):
        p = ChiralDistribution(np.array([0.0, 0.0]), Chirality.LEFT)
        q = ChiralDistribution(np.array([3.0, 4.0]), Chirality.LEFT)
        
        d = ChiralDivergence.fisher_rao_distance(p, q)
        assert abs(d - 5.0) < 1e-10


class TestGeometricStatistics:
    def test_frechet_mean(self):
        dists = [
            ChiralDistribution(np.array([0.0]), Chirality.LEFT),
            ChiralDistribution(np.array([2.0]), Chirality.LEFT),
            ChiralDistribution(np.array([4.0]), Chirality.LEFT),
        ]
        
        mean = GeometricStatistics.frechet_mean(dists)
        assert abs(mean.parameters[0] - 2.0) < 0.5
        assert mean.chirality == Chirality.LEFT
    
    def test_frechet_mean_empty(self):
        with pytest.raises(ValueError):
            GeometricStatistics.frechet_mean([])
    
    def test_geometric_variance(self):
        dists = [
            ChiralDistribution(np.array([0.0]), Chirality.NEUTRAL),
            ChiralDistribution(np.array([1.0]), Chirality.NEUTRAL),
            ChiralDistribution(np.array([2.0]), Chirality.NEUTRAL),
        ]
        
        var = GeometricStatistics.geometric_variance(dists)
        assert var >= 0
    
    def test_geodesic_interpolation(self):
        p = ChiralDistribution(np.array([0.0, 0.0]), Chirality.LEFT)
        q = ChiralDistribution(np.array([2.0, 2.0]), Chirality.RIGHT)
        
        # Endpoints
        assert np.allclose(GeometricStatistics.geodesic_interpolation(p, q, 0.0).parameters, p.parameters)
        assert np.allclose(GeometricStatistics.geodesic_interpolation(p, q, 1.0).parameters, q.parameters)
        
        # Midpoint
        mid = GeometricStatistics.geodesic_interpolation(p, q, 0.5)
        assert np.allclose(mid.parameters, [1.0, 1.0])
        assert mid.chirality == Chirality.NEUTRAL
    
    def test_exponential_map(self):
        base = ChiralDistribution(np.array([0.0, 0.0]), Chirality.LEFT)
        tangent = np.array([1.0, 2.0])
        
        result = GeometricStatistics.exponential_map(base, tangent)
        assert np.allclose(result.parameters, [1.0, 2.0])
    
    def test_logarithmic_map(self):
        base = ChiralDistribution(np.array([0.0, 0.0]), Chirality.LEFT)
        point = ChiralDistribution(np.array([3.0, 4.0]), Chirality.LEFT)
        
        log = GeometricStatistics.logarithmic_map(base, point)
        assert np.allclose(log, [3.0, 4.0])
    
    def test_parallel_transport(self):
        metric = FisherMetric.gaussian(2)
        vector = np.array([1.0, 0.0])
        start = np.array([0.0, 0.0])
        end = np.array([1.0, 1.0])
        
        transported = GeometricStatistics.parallel_transport(vector, start, end, metric)
        # For flat metric, should be unchanged
        assert np.allclose(transported, vector)
    
    def test_natural_gradient(self):
        dist = ChiralDistribution(np.array([0.0, 0.0]), Chirality.NEUTRAL)
        euclidean_grad = np.array([1.0, 2.0])
        
        nat_grad = GeometricStatistics.natural_gradient(dist, euclidean_grad)
        # For identity Fisher metric, should equal Euclidean gradient
        assert np.allclose(nat_grad, euclidean_grad)


class TestChiralExponentialFamily:
    def test_gaussian_exponential_family(self):
        gauss = create_gaussian_exponential_family(mean=0.0, variance=1.0)
        
        assert len(gauss.natural_parameters) == 2
        assert gauss.chirality == Chirality.NEUTRAL
    
    def test_log_density(self):
        gauss = create_gaussian_exponential_family(mean=0.0, variance=1.0)
        
        # Log density at mean should be higher than away from mean
        ld0 = gauss.log_density(np.array([0.0]))
        ld1 = gauss.log_density(np.array([3.0]))
        assert ld0 > ld1
    
    def test_density(self):
        gauss = create_gaussian_exponential_family(mean=0.0, variance=1.0)
        d = gauss.density(np.array([0.0]))
        assert d > 0
    
    def test_to_distribution(self):
        gauss = create_gaussian_exponential_family(mean=1.0, variance=2.0, chirality=Chirality.RIGHT)
        dist = gauss.to_distribution()
        
        assert dist.chirality == Chirality.RIGHT
        assert dist.dimension == 2
    
    def test_expected_sufficient_stats(self):
        gauss = create_gaussian_exponential_family(mean=0.0, variance=1.0)
        E_T = gauss.expected_sufficient_stats()
        assert len(E_T) == 2
    
    def test_fisher_metric_from_exp_family(self):
        gauss = create_gaussian_exponential_family(mean=0.0, variance=1.0)
        metric = gauss.fisher_metric()
        
        assert metric.dimension == 2
        # Should be positive definite
        eigvals = np.linalg.eigvalsh(metric._metric_matrix)
        assert all(eigvals > 0)


class TestChiralityBehavior:
    def test_chirality_affects_divergence(self):
        left = ChiralDistribution(np.array([0.0]), Chirality.LEFT)
        right = ChiralDistribution(np.array([0.0]), Chirality.RIGHT)
        neutral = ChiralDistribution(np.array([0.0]), Chirality.NEUTRAL)
        
        # Same params, different chirality should increase divergence
        kl_lr = ChiralDivergence.kl_divergence(left, right)
        kl_ll = ChiralDivergence.kl_divergence(left, left)
        assert kl_lr >= kl_ll
    
    def test_frechet_mean_chirality_vote(self):
        dists = [
            ChiralDistribution(np.array([0.0]), Chirality.LEFT),
            ChiralDistribution(np.array([1.0]), Chirality.LEFT),
            ChiralDistribution(np.array([2.0]), Chirality.RIGHT),
        ]
        
        mean = GeometricStatistics.frechet_mean(dists)
        # Majority is LEFT
        assert mean.chirality == Chirality.LEFT
    
    def test_interpolation_chirality_transition(self):
        p = ChiralDistribution(np.array([0.0]), Chirality.LEFT)
        q = ChiralDistribution(np.array([1.0]), Chirality.RIGHT)
        
        interp_0 = GeometricStatistics.geodesic_interpolation(p, q, 0.0)
        interp_mid = GeometricStatistics.geodesic_interpolation(p, q, 0.5)
        interp_1 = GeometricStatistics.geodesic_interpolation(p, q, 1.0)
        
        assert interp_0.chirality == Chirality.LEFT
        assert interp_mid.chirality == Chirality.NEUTRAL
        assert interp_1.chirality == Chirality.RIGHT
