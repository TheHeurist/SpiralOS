"""Tests for chiral base structures."""

import pytest
import numpy as np
from holor_calculus.chiral_base import ChiralObject, Chirality, ChiralSpace


class TestChirality:
    def test_chirality_values(self):
        assert Chirality.LEFT.value == -1
        assert Chirality.NEUTRAL.value == 0
        assert Chirality.RIGHT.value == 1
    
    def test_chirality_flip(self):
        assert Chirality.LEFT.flip() == Chirality.RIGHT
        assert Chirality.RIGHT.flip() == Chirality.LEFT
        assert Chirality.NEUTRAL.flip() == Chirality.NEUTRAL
    
    def test_chirality_multiplication(self):
        assert Chirality.LEFT * Chirality.LEFT == Chirality.RIGHT
        assert Chirality.RIGHT * Chirality.RIGHT == Chirality.RIGHT
        assert Chirality.LEFT * Chirality.RIGHT == Chirality.LEFT
        assert Chirality.NEUTRAL * Chirality.LEFT == Chirality.NEUTRAL


class TestChiralObject:
    def test_creation(self):
        obj = ChiralObject(np.array([1.0, 2.0, 3.0]), Chirality.LEFT)
        assert obj.dimension == 3
        assert obj.chirality == Chirality.LEFT
    
    def test_from_list(self):
        obj = ChiralObject([1.0, 2.0])
        assert obj.dimension == 2
        assert obj.chirality == Chirality.NEUTRAL
    
    def test_norm(self):
        obj = ChiralObject(np.array([3.0, 4.0]))
        assert abs(obj.norm() - 5.0) < 1e-10
    
    def test_flip_chirality(self):
        obj = ChiralObject(np.array([1.0]), Chirality.LEFT)
        flipped = obj.flip_chirality()
        assert flipped.chirality == Chirality.RIGHT
        assert np.allclose(flipped.data, obj.data)
    
    def test_addition(self):
        a = ChiralObject(np.array([1.0, 2.0]), Chirality.LEFT)
        b = ChiralObject(np.array([3.0, 4.0]), Chirality.LEFT)
        c = a + b
        assert np.allclose(c.data, [4.0, 6.0])
        assert c.chirality == Chirality.LEFT
    
    def test_addition_different_chirality(self):
        a = ChiralObject(np.array([1.0]), Chirality.LEFT)
        b = ChiralObject(np.array([2.0]), Chirality.RIGHT)
        c = a + b
        assert c.chirality == Chirality.NEUTRAL
    
    def test_subtraction(self):
        a = ChiralObject(np.array([5.0, 6.0]), Chirality.RIGHT)
        b = ChiralObject(np.array([1.0, 2.0]), Chirality.RIGHT)
        c = a - b
        assert np.allclose(c.data, [4.0, 4.0])
    
    def test_inner_product(self):
        a = ChiralObject(np.array([1.0, 0.0]), Chirality.LEFT)
        b = ChiralObject(np.array([0.0, 1.0]), Chirality.LEFT)
        assert abs(a.inner_product(b)) < 1e-10  # Orthogonal
        
        c = ChiralObject(np.array([2.0, 0.0]), Chirality.LEFT)
        assert abs(a.inner_product(c) - 2.0) < 1e-10
    
    def test_inner_product_chirality_factor(self):
        a = ChiralObject(np.array([1.0]), Chirality.LEFT)
        b = ChiralObject(np.array([2.0]), Chirality.RIGHT)
        # Different chirality reduces inner product
        assert abs(a.inner_product(b) - 1.0) < 1e-10  # 2 * 0.5
    
    def test_distance(self):
        a = ChiralObject(np.array([0.0, 0.0]), Chirality.NEUTRAL)
        b = ChiralObject(np.array([3.0, 4.0]), Chirality.NEUTRAL)
        assert abs(a.distance(b) - 5.0) < 1e-10
    
    def test_distance_chirality_penalty(self):
        a = ChiralObject(np.array([0.0]), Chirality.LEFT)
        b_same = ChiralObject(np.array([1.0]), Chirality.LEFT)
        b_diff = ChiralObject(np.array([1.0]), Chirality.RIGHT)
        
        d_same = a.distance(b_same)
        d_diff = a.distance(b_diff)
        assert d_diff > d_same  # Penalty for different chirality


class TestChiralSpace:
    def test_creation(self):
        space = ChiralSpace(dimension=3, chirality=Chirality.RIGHT)
        assert space.dimension == 3
        assert space.chirality == Chirality.RIGHT
    
    def test_zero(self):
        space = ChiralSpace(dimension=4, chirality=Chirality.LEFT)
        zero = space.zero()
        assert np.allclose(zero.data, np.zeros(4))
        assert zero.chirality == Chirality.LEFT
    
    def test_random(self):
        space = ChiralSpace(dimension=5, chirality=Chirality.NEUTRAL)
        rand = space.random()
        assert rand.dimension == 5
        assert rand.chirality == Chirality.NEUTRAL
