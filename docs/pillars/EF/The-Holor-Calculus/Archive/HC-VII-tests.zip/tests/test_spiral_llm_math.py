"""Tests for SpiralLLM-Math core engine."""

import pytest
import numpy as np

from holor_calculus import (
    SpiralLLMMath, MathematicalProblem, Solution,
    ReasoningMode, SpiralStage,
    ChiralObject, Chirality
)


class TestSpiralLLMMath:
    """Test SpiralLLM-Math core functionality."""

    def test_initialization(self):
        """Test engine initialization."""
        engine = SpiralLLMMath()
        assert engine.mode == ReasoningMode.HYBRID
        assert len(engine.reasoners) == 0
        assert len(engine.verifiers) == 0

    def test_register_reasoner(self):
        """Test reasoner registration."""
        engine = SpiralLLMMath()
        
        def dummy_reasoner(problem):
            return {'result': 'test'}
        
        engine.register_reasoner('test_type', dummy_reasoner)
        assert 'test_type' in engine.reasoners

    def test_register_verifier(self):
        """Test verifier registration."""
        engine = SpiralLLMMath()
        
        def dummy_verifier(problem, result):
            return {'status': True, 'message': 'OK'}
        
        engine.register_verifier('test_type', dummy_verifier)
        assert 'test_type' in engine.verifiers

    def test_solve_simple_problem(self):
        """Test solving a simple problem."""
        engine = SpiralLLMMath()
        
        problem = MathematicalProblem(
            problem_type='default',
            description='Test problem',
            input_data={'value': 42}
        )
        
        solution = engine.solve(problem)
        
        assert isinstance(solution, Solution)
        assert solution.problem == problem
        assert len(solution.reasoning_chain) > 0

    def test_reasoning_stages(self):
        """Test that all spiral stages are executed."""
        engine = SpiralLLMMath()
        
        problem = MathematicalProblem(
            problem_type='test',
            description='Test problem',
            input_data={}
        )
        
        solution = engine.solve(problem, max_iterations=1)
        
        stages = [step.stage for step in solution.reasoning_chain]
        assert SpiralStage.UNDERSTAND in stages
        assert SpiralStage.PLAN in stages
        assert SpiralStage.EXECUTE in stages
        assert SpiralStage.VERIFY in stages

    def test_custom_reasoner(self):
        """Test custom reasoner execution."""
        engine = SpiralLLMMath()
        
        def custom_reasoner(problem):
            return {'computed': problem.input_data['x'] * 2}
        
        engine.register_reasoner('multiply', custom_reasoner)
        
        problem = MathematicalProblem(
            problem_type='multiply',
            description='Multiply by 2',
            input_data={'x': 21}
        )
        
        solution = engine.solve(problem)
        assert solution.result['computed'] == 42

    def test_custom_verifier(self):
        """Test custom verifier execution."""
        engine = SpiralLLMMath()
        
        def custom_verifier(problem, result):
            expected = problem.input_data.get('expected')
            if result.get('value') == expected:
                return {'status': True, 'message': 'Correct!'}
            return {'status': False, 'message': 'Incorrect'}
        
        engine.register_verifier('check', custom_verifier)
        
        def custom_reasoner(problem):
            return {'value': problem.input_data['x'] + 1}
        
        engine.register_reasoner('check', custom_reasoner)
        
        problem = MathematicalProblem(
            problem_type='check',
            description='Add 1',
            input_data={'x': 41, 'expected': 42}
        )
        
        solution = engine.solve(problem)
        # Find verify step
        verify_steps = [s for s in solution.reasoning_chain if s.stage == SpiralStage.VERIFY]
        assert len(verify_steps) > 0
        assert verify_steps[0].is_verified()

    def test_history_tracking(self):
        """Test problem history tracking."""
        engine = SpiralLLMMath()
        
        problem1 = MathematicalProblem('type1', 'Problem 1', {})
        problem2 = MathematicalProblem('type2', 'Problem 2', {})
        
        engine.solve(problem1)
        engine.solve(problem2)
        
        history = engine.get_history()
        assert len(history) == 2

    def test_statistics(self):
        """Test statistics generation."""
        engine = SpiralLLMMath()
        
        for i in range(5):
            problem = MathematicalProblem('test', f'Problem {i}', {})
            engine.solve(problem)
        
        stats = engine.get_statistics()
        assert stats['total_problems'] == 5
        assert 'average_confidence' in stats
        assert 'average_reasoning_steps' in stats

    def test_iterative_refinement(self):
        """Test iterative refinement with multiple iterations."""
        engine = SpiralLLMMath()
        
        problem = MathematicalProblem(
            problem_type='test',
            description='Test refinement',
            input_data={}
        )
        
        solution = engine.solve(problem, max_iterations=3)
        
        # Should have multiple execute-verify cycles
        execute_steps = [s for s in solution.reasoning_chain if s.stage == SpiralStage.EXECUTE]
        assert len(execute_steps) > 0


class TestReasoningMode:
    """Test reasoning mode enumeration."""

    def test_all_modes(self):
        """Test all reasoning modes."""
        modes = [ReasoningMode.ANALYTICAL, ReasoningMode.COMPUTATIONAL,
                ReasoningMode.GEOMETRIC, ReasoningMode.HYBRID]
        
        for mode in modes:
            engine = SpiralLLMMath(mode)
            assert engine.mode == mode


class TestMathematicalProblem:
    """Test MathematicalProblem class."""

    def test_creation(self):
        """Test problem creation."""
        problem = MathematicalProblem(
            problem_type='test',
            description='Test problem',
            input_data={'x': 1, 'y': 2},
            constraints=['x > 0', 'y > 0'],
            expected_properties=['positive_result']
        )
        
        assert problem.problem_type == 'test'
        assert problem.description == 'Test problem'
        assert problem.input_data['x'] == 1
        assert len(problem.constraints) == 2
        assert len(problem.expected_properties) == 1


class TestSolution:
    """Test Solution class."""

    def test_reasoning_trace(self):
        """Test reasoning trace generation."""
        from holor_calculus.spiral_llm_math import ReasoningStep
        
        problem = MathematicalProblem('test', 'Test', {})
        step1 = ReasoningStep(
            stage=SpiralStage.UNDERSTAND,
            description='Understanding',
            input_data={},
            output_data={}
        )
        step2 = ReasoningStep(
            stage=SpiralStage.EXECUTE,
            description='Executing',
            input_data={},
            output_data={},
            verification={'status': True}
        )
        
        solution = Solution(
            problem=problem,
            reasoning_chain=[step1, step2],
            result='answer',
            verification_status=True,
            confidence=0.95
        )
        
        trace = solution.get_reasoning_trace()
        assert 'Test' in trace
        assert 'Understanding' in trace
        assert 'Executing' in trace
        assert '95' in trace  # Could be 95% or 95.00%
