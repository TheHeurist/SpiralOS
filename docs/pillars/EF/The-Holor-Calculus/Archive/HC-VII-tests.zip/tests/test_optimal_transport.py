"""
Tests for §8 - Chiral Optimal Transport

Tests cover:
- Chiral measure properties
- Coupling validation
- Wasserstein distance computation
- Barycenter computation
- Displacement interpolation
- Optimal transport maps
"""

import pytest
import numpy as np
from holor_calculus import (
    ChiralObject, Chirality,
    ChiralMeasure, ChiralCoupling, WassersteinDistance,
    ChiralBarycenter, DisplacementInterpolation, OptimalTransportMap,
    create_uniform_measure, create_weighted_measure, compute_wasserstein_geodesic
)


class TestChiralMeasure:
    """Test ChiralMeasure properties"""
    
    def test_measure_creation(self):
        """Test creating valid measure"""
        support = [
            ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT),
            ChiralObject(np.array([1.0, 0.0]), Chirality.RIGHT),
        ]
        weights = np.array([0.6, 0.4])
        
        measure = ChiralMeasure(support, weights)
        assert measure.n_support == 2
    
    def test_weights_must_sum_to_one(self):
        """Test that weights must sum to 1"""
        support = [ChiralObject(np.zeros(2), Chirality.NEUTRAL)]
        weights = np.array([0.5])  # Doesn't sum to 1
        
        with pytest.raises(ValueError, match="sum to 1"):
            ChiralMeasure(support, weights)
    
    def test_weights_must_be_nonnegative(self):
        """Test that weights must be non-negative"""
        support = [
            ChiralObject(np.zeros(2), Chirality.LEFT),
            ChiralObject(np.ones(2), Chirality.RIGHT),
        ]
        weights = np.array([1.5, -0.5])
        
        with pytest.raises(ValueError, match="non-negative"):
            ChiralMeasure(support, weights)
    
    def test_support_weights_length_match(self):
        """Test that support and weights have same length"""
        support = [ChiralObject(np.zeros(2), Chirality.NEUTRAL)]
        weights = np.array([0.5, 0.5])
        
        with pytest.raises(ValueError, match="same length"):
            ChiralMeasure(support, weights)
    
    def test_mean_chirality_left(self):
        """Test mean chirality for LEFT-dominated measure"""
        support = [
            ChiralObject(np.zeros(2), Chirality.LEFT),
            ChiralObject(np.zeros(2), Chirality.LEFT),
            ChiralObject(np.zeros(2), Chirality.RIGHT),
        ]
        weights = np.array([0.4, 0.4, 0.2])
        
        measure = ChiralMeasure(support, weights)
        assert measure.mean_chirality() == Chirality.LEFT
    
    def test_mean_chirality_neutral(self):
        """Test mean chirality for balanced measure"""
        support = [
            ChiralObject(np.zeros(2), Chirality.LEFT),
            ChiralObject(np.zeros(2), Chirality.RIGHT),
        ]
        weights = np.array([0.5, 0.5])
        
        measure = ChiralMeasure(support, weights)
        assert measure.mean_chirality() == Chirality.NEUTRAL
    
    def test_barycenter_location(self):
        """Test Euclidean barycenter computation"""
        support = [
            ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT),
            ChiralObject(np.array([2.0, 0.0]), Chirality.RIGHT),
        ]
        weights = np.array([0.5, 0.5])
        
        measure = ChiralMeasure(support, weights)
        barycenter = measure.barycenter_location()
        
        assert np.allclose(barycenter, np.array([1.0, 0.0]))
    
    def test_push_forward(self):
        """Test push-forward of measure"""
        support = [ChiralObject(np.array([0.0]), Chirality.LEFT)]
        weights = np.array([1.0])
        measure = ChiralMeasure(support, weights)
        
        # Define map: x -> 2*x
        def double_map(obj):
            return ChiralObject(2 * obj.data, obj.chirality)
        
        pushed = measure.push_forward(double_map)
        assert np.allclose(pushed.support[0].data, np.array([0.0]))


class TestChiralCoupling:
    """Test ChiralCoupling validation"""
    
    def test_coupling_creation(self):
        """Test creating valid coupling"""
        source = create_uniform_measure([
            ChiralObject(np.array([0.0]), Chirality.LEFT),
            ChiralObject(np.array([1.0]), Chirality.RIGHT),
        ])
        target = create_uniform_measure([
            ChiralObject(np.array([0.5]), Chirality.NEUTRAL),
            ChiralObject(np.array([1.5]), Chirality.NEUTRAL),
        ])
        
        # Valid coupling
        plan = np.array([[0.5, 0.0], [0.0, 0.5]])
        coupling = ChiralCoupling(source, target, plan)
        
        assert coupling.plan.shape == (2, 2)
    
    def test_coupling_marginal_constraints(self):
        """Test that coupling satisfies marginal constraints"""
        source = create_uniform_measure([
            ChiralObject(np.zeros(2), Chirality.LEFT),
            ChiralObject(np.ones(2), Chirality.RIGHT),
        ])
        target = create_uniform_measure([
            ChiralObject(np.array([0.5, 0.5]), Chirality.NEUTRAL),
        ])
        
        # Invalid coupling (wrong marginals)
        plan = np.array([[0.3], [0.3]])  # Doesn't match source weights
        
        with pytest.raises(ValueError, match="marginal"):
            ChiralCoupling(source, target, plan)
    
    def test_coupling_shape_mismatch(self):
        """Test error on shape mismatch"""
        source = create_uniform_measure([ChiralObject(np.zeros(2), Chirality.LEFT)])
        target = create_uniform_measure([ChiralObject(np.zeros(2), Chirality.RIGHT)])
        
        plan = np.array([[0.5, 0.5]])  # Wrong shape
        
        with pytest.raises(ValueError, match="shape"):
            ChiralCoupling(source, target, plan)
    
    def test_transport_cost(self):
        """Test transport cost computation"""
        source = create_uniform_measure([
            ChiralObject(np.array([0.0]), Chirality.LEFT),
            ChiralObject(np.array([1.0]), Chirality.LEFT),
        ])
        target = create_uniform_measure([
            ChiralObject(np.array([0.0]), Chirality.LEFT),
            ChiralObject(np.array([1.0]), Chirality.LEFT),
        ])
        
        # Identity coupling
        plan = np.array([[0.5, 0.0], [0.0, 0.5]])
        coupling = ChiralCoupling(source, target, plan)
        
        # Zero cost for identity
        cost_matrix = np.zeros((2, 2))
        cost = coupling.transport_cost(cost_matrix)
        assert cost == 0.0
    
    def test_is_deterministic_true(self):
        """Test deterministic coupling detection"""
        source = create_uniform_measure([
            ChiralObject(np.zeros(2), Chirality.LEFT),
            ChiralObject(np.ones(2), Chirality.RIGHT),
        ])
        target = create_uniform_measure([
            ChiralObject(np.zeros(2), Chirality.LEFT),
            ChiralObject(np.ones(2), Chirality.RIGHT),
        ])
        
        # Deterministic (permutation) coupling
        plan = np.array([[0.5, 0.0], [0.0, 0.5]])
        coupling = ChiralCoupling(source, target, plan)
        
        assert coupling.is_deterministic()
    
    def test_is_deterministic_false(self):
        """Test non-deterministic coupling"""
        source = create_uniform_measure([
            ChiralObject(np.zeros(2), Chirality.LEFT),
        ])
        target = create_uniform_measure([
            ChiralObject(np.zeros(2), Chirality.LEFT),
            ChiralObject(np.ones(2), Chirality.RIGHT),
        ])
        
        # Split mass
        plan = np.array([[0.5, 0.5]])
        coupling = ChiralCoupling(source, target, plan)
        
        assert not coupling.is_deterministic()


class TestWassersteinDistance:
    """Test Wasserstein distance computation"""
    
    def test_wasserstein_initialization(self):
        """Test Wasserstein distance initialization"""
        w = WassersteinDistance(p=2.0, chirality_penalty=1.5)
        assert w.p == 2.0
        assert w.chirality_penalty == 1.5
    
    def test_cost_matrix_no_chirality_penalty(self):
        """Test cost matrix without chirality mismatch"""
        w = WassersteinDistance(p=2.0, chirality_penalty=1.0)
        
        source = create_uniform_measure([
            ChiralObject(np.array([0.0]), Chirality.LEFT),
            ChiralObject(np.array([1.0]), Chirality.LEFT),
        ])
        target = create_uniform_measure([
            ChiralObject(np.array([0.0]), Chirality.LEFT),
            ChiralObject(np.array([1.0]), Chirality.LEFT),
        ])
        
        cost = w.compute_cost_matrix(source, target)
        
        # No chirality penalty, so cost is just distance^p
        assert cost.shape == (2, 2)
        assert cost[0, 0] < cost[0, 1]  # Closer points have lower cost
    
    def test_cost_matrix_with_chirality_penalty(self):
        """Test cost matrix with chirality mismatch"""
        w = WassersteinDistance(p=1.0, chirality_penalty=10.0)
        
        source = create_uniform_measure([
            ChiralObject(np.array([0.0]), Chirality.LEFT),
        ])
        target = create_uniform_measure([
            ChiralObject(np.array([0.0]), Chirality.RIGHT),  # Different chirality
        ])
        
        cost = w.compute_cost_matrix(source, target)
        
        # Should include chirality penalty
        assert cost[0, 0] >= 10.0
    
    def test_distance_zero_for_identical(self):
        """Test that distance is zero for identical measures"""
        w = WassersteinDistance(p=2.0)
        
        measure = create_uniform_measure([
            ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT),
            ChiralObject(np.array([1.0, 1.0]), Chirality.RIGHT),
        ])
        
        dist = w.distance(measure, measure)
        assert dist < 1e-6  # Should be approximately zero
    
    def test_distance_positive_for_different(self):
        """Test that distance is positive for different measures"""
        w = WassersteinDistance(p=2.0)
        
        measure1 = create_uniform_measure([
            ChiralObject(np.array([0.0]), Chirality.LEFT),
        ])
        measure2 = create_uniform_measure([
            ChiralObject(np.array([1.0]), Chirality.LEFT),
        ])
        
        dist = w.distance(measure1, measure2)
        assert dist > 0
    
    def test_distance_callable(self):
        """Test that WassersteinDistance is callable"""
        w = WassersteinDistance(p=1.0)
        
        m1 = create_uniform_measure([ChiralObject(np.array([0.0]), Chirality.LEFT)])
        m2 = create_uniform_measure([ChiralObject(np.array([1.0]), Chirality.LEFT)])
        
        dist = w(m1, m2)
        assert isinstance(dist, float)
        assert dist > 0
    
    def test_optimal_coupling_equal_weights(self):
        """Test optimal coupling for measures with equal weights"""
        w = WassersteinDistance(p=2.0)
        
        source = create_uniform_measure([
            ChiralObject(np.array([0.0]), Chirality.LEFT),
            ChiralObject(np.array([1.0]), Chirality.LEFT),
        ])
        target = create_uniform_measure([
            ChiralObject(np.array([0.0]), Chirality.LEFT),
            ChiralObject(np.array([2.0]), Chirality.LEFT),
        ])
        
        coupling = w.compute_optimal_coupling(source, target)
        
        assert isinstance(coupling, ChiralCoupling)
        assert coupling.plan.shape == (2, 2)
    
    def test_sinkhorn_coupling(self):
        """Test Sinkhorn algorithm for unequal weights"""
        w = WassersteinDistance(p=2.0)
        
        source = create_weighted_measure(
            [ChiralObject(np.array([0.0]), Chirality.LEFT)],
            np.array([1.0])
        )
        target = create_weighted_measure(
            [
                ChiralObject(np.array([0.5]), Chirality.LEFT),
                ChiralObject(np.array([1.5]), Chirality.LEFT),
            ],
            np.array([0.6, 0.4])
        )
        
        cost_matrix = w.compute_cost_matrix(source, target)
        plan = w._sinkhorn_coupling(source, target, cost_matrix)
        
        assert plan.shape == (1, 2)
        assert np.allclose(plan.sum(), 1.0)


class TestChiralBarycenter:
    """Test Wasserstein barycenter computation"""
    
    def test_barycenter_initialization(self):
        """Test barycenter initialization"""
        measures = [
            create_uniform_measure([ChiralObject(np.array([0.0]), Chirality.LEFT)]),
            create_uniform_measure([ChiralObject(np.array([1.0]), Chirality.RIGHT)]),
        ]
        
        barycenter = ChiralBarycenter(measures)
        assert len(barycenter.measures) == 2
        assert np.allclose(barycenter.weights, np.array([0.5, 0.5]))
    
    def test_barycenter_custom_weights(self):
        """Test barycenter with custom weights"""
        measures = [
            create_uniform_measure([ChiralObject(np.zeros(2), Chirality.LEFT)]),
            create_uniform_measure([ChiralObject(np.ones(2), Chirality.RIGHT)]),
        ]
        weights = np.array([0.7, 0.3])
        
        barycenter = ChiralBarycenter(measures, weights)
        assert np.allclose(barycenter.weights, weights)
    
    def test_barycenter_weights_must_sum_to_one(self):
        """Test that barycentric weights must sum to 1"""
        measures = [
            create_uniform_measure([ChiralObject(np.zeros(2), Chirality.LEFT)]),
        ]
        weights = np.array([0.5])
        
        with pytest.raises(ValueError, match="sum to 1"):
            ChiralBarycenter(measures, weights)
    
    def test_compute_support_barycenter(self):
        """Test support barycenter computation"""
        measures = [
            create_uniform_measure([ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)]),
            create_uniform_measure([ChiralObject(np.array([2.0, 2.0]), Chirality.RIGHT)]),
        ]
        
        barycenter = ChiralBarycenter(measures)
        support_points = barycenter.compute_support_barycenter(n_support=2)
        
        assert len(support_points) == 2
        assert all(isinstance(p, np.ndarray) for p in support_points)
    
    def test_compute_barycenter_measure(self):
        """Test full barycenter measure computation"""
        measures = [
            create_uniform_measure([ChiralObject(np.array([0.0]), Chirality.LEFT)]),
            create_uniform_measure([ChiralObject(np.array([1.0]), Chirality.RIGHT)]),
        ]
        
        barycenter = ChiralBarycenter(measures, p=2.0)
        result = barycenter.compute_barycenter(n_support=2)
        
        assert isinstance(result, ChiralMeasure)
        assert result.n_support == 2


class TestDisplacementInterpolation:
    """Test displacement interpolation"""
    
    def test_interpolation_initialization(self):
        """Test displacement interpolation initialization"""
        source = create_uniform_measure([ChiralObject(np.array([0.0]), Chirality.LEFT)])
        target = create_uniform_measure([ChiralObject(np.array([1.0]), Chirality.RIGHT)])
        
        interp = DisplacementInterpolation(source, target)
        assert interp.source == source
        assert interp.target == target
        assert isinstance(interp.coupling, ChiralCoupling)
    
    def test_interpolate_at_endpoints(self):
        """Test that interpolation matches endpoints"""
        source = create_uniform_measure([
            ChiralObject(np.array([0.0]), Chirality.LEFT),
        ])
        target = create_uniform_measure([
            ChiralObject(np.array([1.0]), Chirality.RIGHT),
        ])
        
        interp = DisplacementInterpolation(source, target)
        
        # At t=0, should be close to source
        m0 = interp.interpolate(0.0)
        assert np.allclose(m0.support[0].data, source.support[0].data)
        
        # At t=1, should be close to target
        m1 = interp.interpolate(1.0)
        assert np.allclose(m1.support[0].data, target.support[0].data)
    
    def test_interpolate_midpoint(self):
        """Test interpolation at midpoint"""
        source = create_uniform_measure([ChiralObject(np.array([0.0]), Chirality.LEFT)])
        target = create_uniform_measure([ChiralObject(np.array([2.0]), Chirality.LEFT)])
        
        interp = DisplacementInterpolation(source, target)
        m_half = interp.interpolate(0.5)
        
        # Should be approximately at midpoint
        assert m_half.support[0].data[0] > 0.0
        assert m_half.support[0].data[0] < 2.0
    
    def test_interpolate_invalid_t(self):
        """Test error for invalid interpolation parameter"""
        source = create_uniform_measure([ChiralObject(np.zeros(2), Chirality.LEFT)])
        target = create_uniform_measure([ChiralObject(np.ones(2), Chirality.RIGHT)])
        
        interp = DisplacementInterpolation(source, target)
        
        with pytest.raises(ValueError, match="must be in"):
            interp.interpolate(-0.1)
        
        with pytest.raises(ValueError, match="must be in"):
            interp.interpolate(1.5)
    
    def test_interpolation_callable(self):
        """Test that DisplacementInterpolation is callable"""
        source = create_uniform_measure([ChiralObject(np.zeros(2), Chirality.LEFT)])
        target = create_uniform_measure([ChiralObject(np.ones(2), Chirality.RIGHT)])
        
        interp = DisplacementInterpolation(source, target)
        m = interp(0.5)
        
        assert isinstance(m, ChiralMeasure)
    
    def test_chirality_transition(self):
        """Test chirality transition during interpolation"""
        source = create_uniform_measure([ChiralObject(np.zeros(2), Chirality.LEFT)])
        target = create_uniform_measure([ChiralObject(np.ones(2), Chirality.RIGHT)])
        
        interp = DisplacementInterpolation(source, target)
        
        # Before midpoint, should be LEFT
        m_before = interp(0.3)
        assert m_before.support[0].chirality == Chirality.LEFT
        
        # After midpoint, should be RIGHT
        m_after = interp(0.7)
        assert m_after.support[0].chirality == Chirality.RIGHT


class TestOptimalTransportMap:
    """Test optimal transport (Monge) map"""
    
    def test_map_requires_deterministic_coupling(self):
        """Test that map requires deterministic coupling"""
        source = create_uniform_measure([ChiralObject(np.zeros(2), Chirality.LEFT)])
        target = create_uniform_measure([
            ChiralObject(np.zeros(2), Chirality.LEFT),
            ChiralObject(np.ones(2), Chirality.RIGHT),
        ])
        
        # Non-deterministic coupling
        plan = np.array([[0.5, 0.5]])
        coupling = ChiralCoupling(source, target, plan)
        
        with pytest.raises(ValueError, match="deterministic"):
            OptimalTransportMap(coupling)
    
    def test_map_creation(self):
        """Test creating transport map"""
        source = create_uniform_measure([
            ChiralObject(np.array([0.0]), Chirality.LEFT),
            ChiralObject(np.array([1.0]), Chirality.RIGHT),
        ])
        target = create_uniform_measure([
            ChiralObject(np.array([0.0]), Chirality.LEFT),
            ChiralObject(np.array([1.0]), Chirality.RIGHT),
        ])
        
        # Identity coupling
        plan = np.array([[0.5, 0.0], [0.0, 0.5]])
        coupling = ChiralCoupling(source, target, plan)
        
        transport_map = OptimalTransportMap(coupling)
        assert len(transport_map.map_indices) == 2
    
    def test_map_application(self):
        """Test applying transport map"""
        source = create_uniform_measure([
            ChiralObject(np.array([0.0]), Chirality.LEFT),
            ChiralObject(np.array([1.0]), Chirality.RIGHT),
        ])
        target = create_uniform_measure([
            ChiralObject(np.array([10.0]), Chirality.LEFT),
            ChiralObject(np.array([11.0]), Chirality.RIGHT),
        ])
        
        # Map first to first, second to second
        plan = np.array([[0.5, 0.0], [0.0, 0.5]])
        coupling = ChiralCoupling(source, target, plan)
        
        transport_map = OptimalTransportMap(coupling)
        
        # Apply to source object
        obj = source.support[0]
        mapped = transport_map(obj)
        
        assert isinstance(mapped, ChiralObject)


class TestHelperFunctions:
    """Test helper functions"""
    
    def test_create_uniform_measure(self):
        """Test creating uniform measure"""
        objects = [
            ChiralObject(np.zeros(2), Chirality.LEFT),
            ChiralObject(np.ones(2), Chirality.RIGHT),
        ]
        
        measure = create_uniform_measure(objects)
        assert measure.n_support == 2
        assert np.allclose(measure.weights, np.array([0.5, 0.5]))
    
    def test_create_weighted_measure(self):
        """Test creating weighted measure"""
        objects = [
            ChiralObject(np.zeros(2), Chirality.LEFT),
            ChiralObject(np.ones(2), Chirality.RIGHT),
        ]
        weights = np.array([0.3, 0.7])
        
        measure = create_weighted_measure(objects, weights)
        assert np.allclose(measure.weights, weights)
    
    def test_compute_wasserstein_geodesic(self):
        """Test computing Wasserstein geodesic"""
        source = create_uniform_measure([ChiralObject(np.array([0.0]), Chirality.LEFT)])
        target = create_uniform_measure([ChiralObject(np.array([1.0]), Chirality.RIGHT)])
        
        geodesic = compute_wasserstein_geodesic(source, target, n_points=5)
        
        assert len(geodesic) == 5
        assert all(isinstance(m, ChiralMeasure) for m in geodesic)
        
        # First should be source, last should be target
        assert np.allclose(geodesic[0].support[0].data, source.support[0].data)
        assert np.allclose(geodesic[-1].support[0].data, target.support[0].data)


class TestIntegration:
    """Integration tests combining multiple features"""
    
    def test_full_optimal_transport_workflow(self):
        """Test complete optimal transport workflow"""
        # Create measures
        source = create_uniform_measure([
            ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT),
            ChiralObject(np.array([1.0, 0.0]), Chirality.LEFT),
        ])
        target = create_uniform_measure([
            ChiralObject(np.array([0.5, 0.5]), Chirality.RIGHT),
            ChiralObject(np.array([1.5, 0.5]), Chirality.RIGHT),
        ])
        
        # Compute Wasserstein distance
        w = WassersteinDistance(p=2.0, chirality_penalty=0.5)
        dist = w.distance(source, target)
        
        # Get optimal coupling
        coupling = w.compute_optimal_coupling(source, target)
        
        # Compute interpolation
        interp = DisplacementInterpolation(source, target, coupling)
        m_mid = interp(0.5)
        
        # Verify results
        assert dist > 0
        assert isinstance(coupling, ChiralCoupling)
        assert isinstance(m_mid, ChiralMeasure)
    
    def test_barycenter_of_multiple_measures(self):
        """Test computing barycenter of multiple measures"""
        measures = [
            create_uniform_measure([ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)]),
            create_uniform_measure([ChiralObject(np.array([1.0, 0.0]), Chirality.RIGHT)]),
            create_uniform_measure([ChiralObject(np.array([0.5, 1.0]), Chirality.NEUTRAL)]),
        ]
        
        barycenter = ChiralBarycenter(measures)
        result = barycenter.compute_barycenter(n_support=3)
        
        assert isinstance(result, ChiralMeasure)
        assert result.n_support == 3
    
    def test_geodesic_preserves_total_mass(self):
        """Test that geodesic preserves total mass"""
        source = create_uniform_measure([
            ChiralObject(np.array([0.0]), Chirality.LEFT),
            ChiralObject(np.array([1.0]), Chirality.LEFT),
        ])
        target = create_uniform_measure([
            ChiralObject(np.array([2.0]), Chirality.RIGHT),
            ChiralObject(np.array([3.0]), Chirality.RIGHT),
        ])
        
        geodesic = compute_wasserstein_geodesic(source, target, n_points=10)
        
        # All measures along geodesic should have total mass 1
        for measure in geodesic:
            assert np.isclose(measure.weights.sum(), 1.0)
    
    def test_chirality_penalty_increases_distance(self):
        """Test that chirality penalty increases Wasserstein distance"""
        source = create_uniform_measure([ChiralObject(np.array([0.0]), Chirality.LEFT)])
        target = create_uniform_measure([ChiralObject(np.array([0.0]), Chirality.RIGHT)])
        
        # Without penalty
        w_no_penalty = WassersteinDistance(p=2.0, chirality_penalty=0.0)
        dist_no_penalty = w_no_penalty.distance(source, target)
        
        # With penalty
        w_with_penalty = WassersteinDistance(p=2.0, chirality_penalty=5.0)
        dist_with_penalty = w_with_penalty.distance(source, target)
        
        # Distance should be larger with penalty
        assert dist_with_penalty > dist_no_penalty
