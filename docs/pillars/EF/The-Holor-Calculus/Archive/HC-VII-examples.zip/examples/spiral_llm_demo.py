"""SpiralLLM-Math Integration Demo

Demonstrates the full SpiralLLM-Math reasoning system for Third Cycle.
"""

import numpy as np
from holor_calculus import (
    # Core mathematics
    ChiralObject, Chirality,
    ChiralPath, FisherMetric,
    # SpiralLLM-Math
    SpiralProblemSolver, SpiralVerifier, QualityAssessor,
    MathematicalProblem, ReasoningMode
)


def demo_homotopy_reasoning():
    """Demo: Homotopy path equivalence with SpiralLLM-Math."""
    print("="*70)
    print("DEMO 1: Homotopy Path Equivalence Reasoning")
    print("="*70)
    
    # Create solver
    solver = SpiralProblemSolver(mode=ReasoningMode.GEOMETRIC)
    
    # Define two paths from LEFT to RIGHT chirality
    p0 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
    p1 = ChiralObject(np.array([1.0, 1.0]), Chirality.RIGHT)
    
    path1 = ChiralPath(p0, p1)
    path2 = ChiralPath(p0, p1)  # Same endpoints
    
    # Solve with SpiralLLM-Math
    solution = solver.solve_homotopy_problem(path1, path2, 'create')
    
    # Explain solution
    print("\n" + solver.explain_solution(solution, detailed=False))
    
    # Verify solution
    verifier = SpiralVerifier()
    verification = verifier.verify_solution(solution)
    
    print(f"\n✓ Verification Status: {'PASSED' if verification.passed else 'FAILED'}")
    print(f"✓ Confidence: {verification.confidence:.2%}")
    print(f"✓ Checks: {len(verification.checks_passed)}/{len(verification.checks_performed)}")


def demo_divergence_reasoning():
    """Demo: KL divergence computation with chirality effects."""
    print("\n" + "="*70)
    print("DEMO 2: Information Divergence with Chirality Analysis")
    print("="*70)
    
    # Create solver
    solver = SpiralProblemSolver(mode=ReasoningMode.HYBRID)
    
    # Two LEFT-chiral distributions (similar)
    obj1_left = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
    obj2_left = ChiralObject(np.array([0.1, 0.1]), Chirality.LEFT)
    
    # One LEFT, one RIGHT (different chirality)
    obj1_right = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
    obj2_right = ChiralObject(np.array([0.1, 0.1]), Chirality.RIGHT)
    
    # Compare same chirality
    print("\nCase 1: Same Chirality (LEFT-LEFT)")
    solution1 = solver.solve_divergence_problem(obj1_left, obj2_left, 'kl')
    kl_same = solution1.result['value']
    print(f"  KL Divergence: {kl_same:.6f}")
    print(f"  Confidence: {solution1.confidence:.2%}")
    
    # Compare different chirality
    print("\nCase 2: Different Chirality (LEFT-RIGHT)")
    solution2 = solver.solve_divergence_problem(obj1_right, obj2_right, 'kl')
    kl_diff = solution2.result['value']
    print(f"  KL Divergence: {kl_diff:.6f}")
    print(f"  Confidence: {solution2.confidence:.2%}")
    
    print(f"\n✓ Chirality Penalty: {(kl_diff / kl_same - 1) * 100:.1f}% increase")


def demo_quality_assessment():
    """Demo: Solution quality assessment."""
    print("\n" + "="*70)
    print("DEMO 3: Quality Assessment of Solutions")
    print("="*70)
    
    # Create solver and assessor
    solver = SpiralProblemSolver()
    verifier = SpiralVerifier()
    assessor = QualityAssessor()
    
    # Solve a problem
    metric = FisherMetric.gaussian(2)
    problem = MathematicalProblem(
        problem_type='fisher_metric',
        description='Compute Fisher metric for Gaussian',
        input_data={'distribution': 'gaussian', 'dim': 2, 'operation': 'compute'}
    )
    
    solution = solver.engine.solve(problem)
    
    # Verify and assess
    verification = verifier.verify_solution(solution)
    assessment = assessor.assess_solution(solution, verification)
    
    print(f"\n✓ Quality Score: {assessment['quality_score']:.2%}")
    print(f"✓ Grade: {assessment['grade']}")
    print(f"✓ Confidence: {assessment['confidence_assessment']}")
    print(f"✓ Verification: {'Passed' if assessment['verification_passed'] else 'Failed'}")
    
    print("\nRecommendations:")
    for rec in assessment['recommendations']:
        print(f"  • {rec}")


def demo_interactive_exploration():
    """Demo: Interactive problem type exploration."""
    print("\n" + "="*70)
    print("DEMO 4: Interactive Problem Exploration")
    print("="*70)
    
    solver = SpiralProblemSolver()
    
    # Explore homotopy
    print("\nExploring: Homotopy Theory")
    exploration = solver.interactive_explore('homotopy')
    
    print("\n💡 Key Insights:")
    for insight in exploration['insights'][:3]:
        print(f"  • {insight}")
    
    print(f"\n🔧 Available Operations: {', '.join(exploration['available_operations'])}")
    
    # Explore divergence
    print("\n\nExploring: Divergence Measures")
    exploration = solver.interactive_explore('divergence')
    
    print("\n💡 Key Insights:")
    for insight in exploration['insights'][:3]:
        print(f"  • {insight}")
    
    print(f"\n🔧 Available Operations: {', '.join(exploration['available_operations'])}")


def demo_statistics():
    """Demo: Solver statistics and history."""
    print("\n" + "="*70)
    print("DEMO 5: Solver Statistics")
    print("="*70)
    
    solver = SpiralProblemSolver()
    
    # Solve multiple problems
    obj1 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
    obj2 = ChiralObject(np.array([0.5, 0.5]), Chirality.LEFT)
    
    for div_type in ['kl', 'hellinger', 'fisher_rao']:
        solver.solve_divergence_problem(obj1, obj2, div_type)
    
    # Get statistics
    stats = solver.get_statistics()
    
    print(f"\n✓ Total Problems Solved: {stats['total_problems']}")
    print(f"✓ Verified Solutions: {stats['verified_solutions']}")
    print(f"✓ Verification Rate: {stats['verification_rate']:.2%}")
    print(f"✓ Average Confidence: {stats['average_confidence']:.2%}")
    print(f"✓ Average Reasoning Steps: {stats['average_reasoning_steps']:.1f}")


if __name__ == "__main__":
    print("\n" + "="*70)
    print("  SpiralLLM-Math Integration Demo")
    print("  Holor Calculus VII - Third Cycle Complete (v0.4.0)")
    print("="*70)
    
    # Run all demos
    demo_homotopy_reasoning()
    demo_divergence_reasoning()
    demo_quality_assessment()
    demo_interactive_exploration()
    demo_statistics()
    
    print("\n" + "="*70)
    print("  All Demos Complete! 🎉")
    print("  Following Spiral Agile methodology in Spiral Time")
    print("="*70 + "\n")
