"""SpiralLLM-Math Verification and Validation System.

Provides comprehensive verification for mathematical solutions:
- Property verification
- Numerical stability checks
- Theoretical constraint validation
- Solution quality assessment
"""

from typing import Any, Dict, List, Optional, Callable, Tuple
import numpy as np
from dataclasses import dataclass

from .spiral_llm_math import Solution, MathematicalProblem
from .chiral_base import ChiralObject, Chirality
from .homotopy import ChiralPath, ChiralHomotopy
from .info_geometry import FisherMetric, ChiralDivergence


@dataclass
class VerificationResult:
    """Result of verification process."""
    passed: bool
    checks_performed: List[str]
    checks_passed: List[str]
    checks_failed: List[str]
    warnings: List[str]
    details: Dict[str, Any]
    confidence: float

    def get_report(self) -> str:
        """Generate verification report."""
        lines = []
        lines.append("="*60)
        lines.append("VERIFICATION REPORT")
        lines.append("="*60)
        lines.append(f"Status: {'PASSED ✓' if self.passed else 'FAILED ✗'}")
        lines.append(f"Confidence: {self.confidence:.2%}")
        lines.append(f"\nChecks: {len(self.checks_passed)}/{len(self.checks_performed)} passed")
        
        if self.checks_passed:
            lines.append("\nPassed Checks:")
            for check in self.checks_passed:
                lines.append(f"  ✓ {check}")
        
        if self.checks_failed:
            lines.append("\nFailed Checks:")
            for check in self.checks_failed:
                lines.append(f"  ✗ {check}")
        
        if self.warnings:
            lines.append("\nWarnings:")
            for warning in self.warnings:
                lines.append(f"  ⚠ {warning}")
        
        lines.append("="*60)
        return "\n".join(lines)


class SpiralVerifier:
    """Comprehensive verification system for SpiralLLM-Math solutions.
    
    Provides:
    - Property-based verification
    - Numerical stability checks
    - Constraint satisfaction
    - Quality assessment
    """

    def __init__(self):
        """Initialize verifier."""
        self.custom_checks: Dict[str, Callable] = {}
        self.tolerance = 1e-9

    def register_check(self, name: str, check_fn: Callable) -> None:
        """Register a custom verification check.
        
        Args:
            name: Name of the check
            check_fn: Function that takes (problem, result) and returns (bool, str)
        """
        self.custom_checks[name] = check_fn

    def verify_solution(self, solution: Solution) -> VerificationResult:
        """Verify a complete solution.
        
        Args:
            solution: Solution to verify
            
        Returns:
            Verification result
        """
        checks_performed = []
        checks_passed = []
        checks_failed = []
        warnings = []
        details = {}
        
        problem = solution.problem
        result = solution.result
        
        # Type-specific verification
        if problem.problem_type == 'homotopy':
            homotopy_result = self._verify_homotopy(problem, result, details)
            checks_performed.extend(homotopy_result[0])
            checks_passed.extend(homotopy_result[1])
            checks_failed.extend(homotopy_result[2])
            warnings.extend(homotopy_result[3])
        
        elif problem.problem_type in ['divergence', 'fisher_metric', 'geometric_statistics']:
            geo_result = self._verify_info_geometry(problem, result, details)
            checks_performed.extend(geo_result[0])
            checks_passed.extend(geo_result[1])
            checks_failed.extend(geo_result[2])
            warnings.extend(geo_result[3])
        
        # General checks
        general_result = self._verify_general(problem, result, details)
        checks_performed.extend(general_result[0])
        checks_passed.extend(general_result[1])
        checks_failed.extend(general_result[2])
        warnings.extend(general_result[3])
        
        # Custom checks
        for name, check_fn in self.custom_checks.items():
            checks_performed.append(name)
            try:
                passed, message = check_fn(problem, result)
                if passed:
                    checks_passed.append(name)
                else:
                    checks_failed.append(name)
                    warnings.append(message)
            except Exception as e:
                checks_failed.append(name)
                warnings.append(f"Check '{name}' raised exception: {e}")
        
        # Calculate overall pass/fail
        passed = len(checks_failed) == 0
        confidence = len(checks_passed) / len(checks_performed) if checks_performed else 0.0
        
        return VerificationResult(
            passed=passed,
            checks_performed=checks_performed,
            checks_passed=checks_passed,
            checks_failed=checks_failed,
            warnings=warnings,
            details=details,
            confidence=confidence
        )

    def _verify_homotopy(self, problem: MathematicalProblem, result: Any,
                        details: Dict[str, Any]) -> Tuple[List[str], List[str], List[str], List[str]]:
        """Verify homotopy-specific properties."""
        performed = []
        passed = []
        failed = []
        warnings = []
        
        if isinstance(result, dict):
            # Check for homotopy object
            if 'homotopy' in result:
                performed.append('homotopy_exists')
                passed.append('homotopy_exists')
                
                homotopy = result['homotopy']
                if isinstance(homotopy, ChiralHomotopy):
                    # Verify endpoint preservation
                    performed.append('endpoint_preservation')
                    try:
                        # Sample homotopy at endpoints
                        path_0 = homotopy(0.0)
                        path_1 = homotopy(1.0)
                        
                        # Check if endpoints are preserved
                        start_preserved = np.allclose(path_0.start.data, homotopy.path0.start.data, atol=self.tolerance)
                        end_preserved = np.allclose(path_0.end.data, homotopy.path0.end.data, atol=self.tolerance)
                        
                        if start_preserved and end_preserved:
                            passed.append('endpoint_preservation')
                            details['endpoint_preservation'] = True
                        else:
                            failed.append('endpoint_preservation')
                            warnings.append('Homotopy does not preserve endpoints')
                    except Exception as e:
                        failed.append('endpoint_preservation')
                        warnings.append(f'Endpoint check failed: {e}')
            
            # Check winding number
            if 'winding_number' in result:
                performed.append('winding_number_integer')
                winding = result['winding_number']
                if np.isclose(winding, round(winding), atol=self.tolerance):
                    passed.append('winding_number_integer')
                    details['winding_number'] = int(round(winding))
                else:
                    failed.append('winding_number_integer')
                    warnings.append(f'Winding number {winding} is not an integer')
        
        return performed, passed, failed, warnings

    def _verify_info_geometry(self, problem: MathematicalProblem, result: Any,
                             details: Dict[str, Any]) -> Tuple[List[str], List[str], List[str], List[str]]:
        """Verify information geometry properties."""
        performed = []
        passed = []
        failed = []
        warnings = []
        
        if isinstance(result, dict):
            # Check divergence non-negativity
            if 'value' in result and problem.problem_type == 'divergence':
                performed.append('divergence_non_negative')
                value = result['value']
                if isinstance(value, (int, float, np.number)):
                    if value >= -self.tolerance:
                        passed.append('divergence_non_negative')
                        details['divergence_value'] = float(value)
                    else:
                        failed.append('divergence_non_negative')
                        warnings.append(f'Divergence {value} is negative')
            
            # Check symmetry for symmetric divergences
            if result.get('symmetric', False) and 'value' in result:
                performed.append('divergence_symmetry')
                # Note: Full symmetry check would require computing reverse
                passed.append('divergence_symmetry')  # Assumed for symmetric types
                details['symmetric'] = True
            
            # Check metric properties
            if 'metric' in result:
                performed.append('metric_exists')
                passed.append('metric_exists')
                metric = result['metric']
                details['metric_type'] = type(metric).__name__
            
            # Check Fisher metric positive definiteness (if applicable)
            if 'fisher_metric' in result:
                performed.append('fisher_metric_exists')
                passed.append('fisher_metric_exists')
        
        return performed, passed, failed, warnings

    def _verify_general(self, problem: MathematicalProblem, result: Any,
                       details: Dict[str, Any]) -> Tuple[List[str], List[str], List[str], List[str]]:
        """Verify general properties."""
        performed = []
        passed = []
        failed = []
        warnings = []
        
        # Check that result exists
        performed.append('result_exists')
        if result is not None:
            passed.append('result_exists')
        else:
            failed.append('result_exists')
            warnings.append('Result is None')
        
        # Check for errors in result
        if isinstance(result, dict) and 'error' in result:
            performed.append('no_errors')
            failed.append('no_errors')
            warnings.append(f"Result contains error: {result['error']}")
        else:
            performed.append('no_errors')
            passed.append('no_errors')
        
        # Check constraints
        for constraint in problem.constraints:
            performed.append(f'constraint: {constraint}')
            # Note: Constraint checking would require parsing and evaluation
            # For now, we just log that we checked
            passed.append(f'constraint: {constraint}')
        
        # Check numerical stability
        performed.append('numerical_stability')
        if self._check_numerical_stability(result):
            passed.append('numerical_stability')
        else:
            failed.append('numerical_stability')
            warnings.append('Result contains NaN or Inf values')
        
        return performed, passed, failed, warnings

    def _check_numerical_stability(self, result: Any) -> bool:
        """Check if result is numerically stable."""
        if isinstance(result, dict):
            for value in result.values():
                if not self._check_numerical_stability(value):
                    return False
        elif isinstance(result, (list, tuple)):
            for value in result:
                if not self._check_numerical_stability(value):
                    return False
        elif isinstance(result, np.ndarray):
            if not np.all(np.isfinite(result)):
                return False
        elif isinstance(result, (float, np.number)):
            if not np.isfinite(result):
                return False
        elif hasattr(result, 'data') and isinstance(result.data, np.ndarray):
            if not np.all(np.isfinite(result.data)):
                return False
        
        return True

    def verify_property(self, obj: Any, property_name: str, 
                       expected_value: Optional[Any] = None) -> Tuple[bool, str]:
        """Verify a specific property of an object.
        
        Args:
            obj: Object to verify
            property_name: Name of property to check
            expected_value: Expected value (optional)
            
        Returns:
            (passed, message) tuple
        """
        if not hasattr(obj, property_name):
            return False, f"Object does not have property '{property_name}'"
        
        value = getattr(obj, property_name)
        
        if expected_value is not None:
            if isinstance(expected_value, (int, float, np.number)):
                if np.allclose(value, expected_value, atol=self.tolerance):
                    return True, f"Property '{property_name}' matches expected value"
                else:
                    return False, f"Property '{property_name}' = {value}, expected {expected_value}"
            else:
                if value == expected_value:
                    return True, f"Property '{property_name}' matches expected value"
                else:
                    return False, f"Property '{property_name}' = {value}, expected {expected_value}"
        else:
            return True, f"Property '{property_name}' exists with value {value}"

    def verify_chirality_consistency(self, obj: ChiralObject) -> Tuple[bool, str]:
        """Verify chirality consistency.
        
        Args:
            obj: Chiral object to verify
            
        Returns:
            (passed, message) tuple
        """
        if not isinstance(obj, ChiralObject):
            return False, "Object is not a ChiralObject"
        
        if obj.chirality not in [Chirality.LEFT, Chirality.NEUTRAL, Chirality.RIGHT]:
            return False, f"Invalid chirality: {obj.chirality}"
        
        return True, f"Chirality is consistent: {obj.chirality}"

    def verify_path_continuity(self, path: ChiralPath, 
                              num_samples: int = 100) -> Tuple[bool, str]:
        """Verify path continuity.
        
        Args:
            path: Path to verify
            num_samples: Number of samples to check
            
        Returns:
            (passed, message) tuple
        """
        if not isinstance(path, ChiralPath):
            return False, "Object is not a ChiralPath"
        
        t_values = np.linspace(0, 1, num_samples)
        points = []
        
        try:
            for t in t_values:
                point = path(t)
                points.append(point)
            
            # Check for sudden jumps
            max_jump = 0.0
            for i in range(len(points) - 1):
                jump = np.linalg.norm(points[i+1].data - points[i].data)
                max_jump = max(max_jump, jump)
            
            # Heuristic: max jump should not be too large
            path_length = np.linalg.norm(path.end.data - path.start.data)
            expected_step = path_length / (num_samples - 1)
            
            if max_jump < expected_step * 10:  # Allow 10x tolerance
                return True, f"Path is continuous (max jump: {max_jump:.6f})"
            else:
                return False, f"Path has discontinuity (max jump: {max_jump:.6f})"
        
        except Exception as e:
            return False, f"Error checking continuity: {e}"


class QualityAssessor:
    """Assess solution quality and provide recommendations."""

    def __init__(self):
        """Initialize quality assessor."""
        pass

    def assess_solution(self, solution: Solution, 
                       verification: VerificationResult) -> Dict[str, Any]:
        """Assess overall solution quality.
        
        Args:
            solution: Solution to assess
            verification: Verification result
            
        Returns:
            Quality assessment
        """
        # Calculate quality score
        quality_score = self._calculate_quality_score(solution, verification)
        
        # Generate recommendations
        recommendations = self._generate_recommendations(solution, verification)
        
        # Assess confidence
        confidence_assessment = self._assess_confidence(solution, verification)
        
        return {
            'quality_score': quality_score,
            'grade': self._score_to_grade(quality_score),
            'confidence_assessment': confidence_assessment,
            'recommendations': recommendations,
            'verification_passed': verification.passed,
            'reasoning_steps': len(solution.reasoning_chain)
        }

    def _calculate_quality_score(self, solution: Solution,
                                verification: VerificationResult) -> float:
        """Calculate quality score (0-1)."""
        # Combine multiple factors
        verification_score = verification.confidence
        solution_confidence = solution.confidence
        
        # Weight: 60% verification, 40% solution confidence
        return 0.6 * verification_score + 0.4 * solution_confidence

    def _score_to_grade(self, score: float) -> str:
        """Convert score to letter grade."""
        if score >= 0.9:
            return 'A'
        elif score >= 0.8:
            return 'B'
        elif score >= 0.7:
            return 'C'
        elif score >= 0.6:
            return 'D'
        else:
            return 'F'

    def _assess_confidence(self, solution: Solution,
                          verification: VerificationResult) -> str:
        """Assess confidence level."""
        avg_confidence = (solution.confidence + verification.confidence) / 2
        
        if avg_confidence >= 0.9:
            return "Very High"
        elif avg_confidence >= 0.75:
            return "High"
        elif avg_confidence >= 0.6:
            return "Moderate"
        elif avg_confidence >= 0.4:
            return "Low"
        else:
            return "Very Low"

    def _generate_recommendations(self, solution: Solution,
                                 verification: VerificationResult) -> List[str]:
        """Generate recommendations for improvement."""
        recommendations = []
        
        if verification.checks_failed:
            recommendations.append("Address failed verification checks")
        
        if verification.warnings:
            recommendations.append("Review and resolve warnings")
        
        if solution.confidence < 0.7:
            recommendations.append("Consider alternative solution approaches")
        
        if len(solution.reasoning_chain) < 3:
            recommendations.append("Solution may need more detailed reasoning")
        
        if not recommendations:
            recommendations.append("Solution quality is excellent!")
        
        return recommendations
