"""
§9 - Persistent Homology & Filtrations

Multi-scale topological data analysis on chiral spaces:
- Filtrations: nested sequences of simplicial complexes
- Persistence pairs: birth-death tracking of topological features
- Persistence diagrams: collections of persistence pairs
- Barcodes: visual representation of feature lifespans
- Bottleneck distance: stability of persistence
- Connection to optimal transport via Wasserstein distance on diagrams
"""

from typing import List, Dict, Optional, Tuple, Set
from dataclasses import dataclass, field
import numpy as np
from enum import Enum

from .chiral_base import ChiralObject, Chirality
from .homology import ChiralSimplicialComplex, ChiralSimplex, ChiralChainComplex


@dataclass
class PersistencePair:
    """
    A persistence pair (birth, death) tracking a topological feature.
    
    Represents a homological feature born at filtration value `birth`
    and dying at filtration value `death`.
    
    Parameters
    ----------
    dimension : int
        Homological dimension (0 for components, 1 for loops, 2 for voids)
    birth : float
        Filtration value where feature is born
    death : float
        Filtration value where feature dies (np.inf for essential features)
    chirality : Chirality
        Predominant chirality of the feature
    creator_simplex : Optional[ChiralSimplex]
        Simplex that creates this feature
    destroyer_simplex : Optional[ChiralSimplex]
        Simplex that destroys this feature
    """
    dimension: int
    birth: float
    death: float
    chirality: Chirality = Chirality.NEUTRAL
    creator_simplex: Optional[ChiralSimplex] = None
    destroyer_simplex: Optional[ChiralSimplex] = None
    
    @property
    def persistence(self) -> float:
        """Persistence (lifetime) of the feature"""
        return self.death - self.birth
    
    @property
    def is_essential(self) -> bool:
        """Check if feature is essential (never dies)"""
        return np.isinf(self.death)
    
    @property
    def midpoint(self) -> float:
        """Midpoint of the persistence interval"""
        if self.is_essential:
            return np.inf
        return (self.birth + self.death) / 2
    
    def __repr__(self) -> str:
        death_str = "∞" if self.is_essential else f"{self.death:.4f}"
        return f"PersistencePair(dim={self.dimension}, birth={self.birth:.4f}, death={death_str}, pers={self.persistence:.4f}, χ={self.chirality.name})"


@dataclass
class PersistenceDiagram:
    """
    Collection of persistence pairs forming a persistence diagram.
    
    A persistence diagram is a multiset of points (b, d) in the extended plane
    where b < d, representing topological features.
    
    Parameters
    ----------
    pairs : List[PersistencePair]
        List of persistence pairs
    """
    pairs: List[PersistencePair] = field(default_factory=list)
    
    def __post_init__(self):
        """Validate pairs"""
        for pair in self.pairs:
            if not pair.is_essential and pair.birth >= pair.death:
                raise ValueError(f"Invalid persistence pair: birth {pair.birth} >= death {pair.death}")
    
    def filter_by_dimension(self, dimension: int) -> 'PersistenceDiagram':
        """Filter diagram to specific homological dimension"""
        filtered_pairs = [p for p in self.pairs if p.dimension == dimension]
        return PersistenceDiagram(filtered_pairs)
    
    def filter_by_persistence(self, min_persistence: float) -> 'PersistenceDiagram':
        """Filter diagram to features with persistence >= min_persistence"""
        filtered_pairs = [p for p in self.pairs if p.persistence >= min_persistence]
        return PersistenceDiagram(filtered_pairs)
    
    def filter_by_chirality(self, chirality: Chirality) -> 'PersistenceDiagram':
        """Filter diagram to specific chirality"""
        filtered_pairs = [p for p in self.pairs if p.chirality == chirality]
        return PersistenceDiagram(filtered_pairs)
    
    def betti_numbers_at(self, filtration_value: float) -> Dict[int, int]:
        """
        Compute Betti numbers at a specific filtration value.
        
        β_k(t) = #{pairs in dimension k with birth ≤ t < death}
        """
        betti = {}
        for pair in self.pairs:
            if pair.birth <= filtration_value < pair.death:
                betti[pair.dimension] = betti.get(pair.dimension, 0) + 1
        return betti
    
    def essential_features(self) -> List[PersistencePair]:
        """Get essential features (those that never die)"""
        return [p for p in self.pairs if p.is_essential]
    
    def to_array(self, dimension: Optional[int] = None) -> np.ndarray:
        """
        Convert diagram to numpy array of (birth, death) coordinates.
        
        Parameters
        ----------
        dimension : Optional[int]
            If provided, only include pairs of this dimension
        
        Returns
        -------
        array : np.ndarray, shape (n_pairs, 2)
            Array of (birth, death) coordinates
        """
        pairs = self.pairs if dimension is None else self.filter_by_dimension(dimension).pairs
        if not pairs:
            return np.empty((0, 2))
        
        coords = np.array([[p.birth, p.death if not p.is_essential else np.inf] 
                          for p in pairs])
        return coords
    
    def __len__(self) -> int:
        return len(self.pairs)
    
    def __repr__(self) -> str:
        dim_counts = {}
        for pair in self.pairs:
            dim_counts[pair.dimension] = dim_counts.get(pair.dimension, 0) + 1
        dim_str = ", ".join(f"H_{k}: {count}" for k, count in sorted(dim_counts.items()))
        return f"PersistenceDiagram({len(self.pairs)} pairs: {dim_str})"


@dataclass
class PersistenceBarcode:
    """
    Barcode representation of persistence diagram.
    
    Each bar represents an interval [birth, death) for a topological feature.
    """
    diagram: PersistenceDiagram
    
    def get_bars(self, dimension: Optional[int] = None) -> List[Tuple[float, float, PersistencePair]]:
        """
        Get bars as list of (birth, death, pair) tuples.
        
        Parameters
        ----------
        dimension : Optional[int]
            If provided, only return bars for this dimension
        
        Returns
        -------
        bars : List[Tuple[float, float, PersistencePair]]
            List of (birth, death, pair) tuples
        """
        pairs = self.diagram.pairs if dimension is None else self.diagram.filter_by_dimension(dimension).pairs
        return [(p.birth, p.death, p) for p in pairs]
    
    def max_persistence(self, dimension: Optional[int] = None) -> float:
        """Get maximum persistence value (excluding essential features)"""
        pairs = self.diagram.pairs if dimension is None else self.diagram.filter_by_dimension(dimension).pairs
        finite_pers = [p.persistence for p in pairs if not p.is_essential]
        return max(finite_pers) if finite_pers else 0.0
    
    def max_death(self, dimension: Optional[int] = None) -> float:
        """Get maximum death value (excluding essential features)"""
        pairs = self.diagram.pairs if dimension is None else self.diagram.filter_by_dimension(dimension).pairs
        finite_deaths = [p.death for p in pairs if not p.is_essential]
        return max(finite_deaths) if finite_deaths else 0.0


class ChiralFiltration:
    """
    Filtration: nested sequence of simplicial complexes.
    
    A filtration is a sequence K_0 ⊆ K_1 ⊆ ... ⊆ K_n of simplicial complexes
    indexed by real values t_0 < t_1 < ... < t_n.
    
    Parameters
    ----------
    vertex_objects : List[ChiralObject]
        Chiral objects serving as vertices
    """
    
    def __init__(self, vertex_objects: List[ChiralObject]):
        self.vertex_objects = vertex_objects
        self.simplices: List[Tuple[float, ChiralSimplex]] = []  # (filtration_value, simplex)
        self._sorted = True
    
    def add_simplex(self, simplex: ChiralSimplex, filtration_value: float):
        """
        Add simplex at specified filtration value.
        
        Parameters
        ----------
        simplex : ChiralSimplex
            Simplex to add
        filtration_value : float
            Filtration value at which simplex enters
        """
        # Validate vertices
        for v in simplex.vertices:
            if v < 0 or v >= len(self.vertex_objects):
                raise ValueError(f"Invalid vertex index {v}")
        
        self.simplices.append((filtration_value, simplex))
        self._sorted = False
    
    def add_simplex_by_vertices(self, vertices: List[int], filtration_value: float):
        """Add simplex by vertex indices"""
        simplex = ChiralSimplex(tuple(vertices))
        self.add_simplex(simplex, filtration_value)
    
    def _ensure_sorted(self):
        """Ensure simplices are sorted by filtration value and dimension"""
        if not self._sorted:
            # Sort by filtration value, then dimension
            self.simplices.sort(key=lambda x: (x[0], x[1].dimension))
            self._sorted = True
    
    def get_complex_at(self, filtration_value: float) -> ChiralSimplicialComplex:
        """
        Get simplicial complex at specified filtration value.
        
        Returns complex containing all simplices with filtration value ≤ t.
        """
        self._ensure_sorted()
        
        complex_obj = ChiralSimplicialComplex(self.vertex_objects)
        for filt_val, simplex in self.simplices:
            if filt_val <= filtration_value:
                complex_obj.add_simplex(list(simplex.vertices))
        
        return complex_obj
    
    def get_filtration_values(self) -> List[float]:
        """Get sorted list of unique filtration values"""
        self._ensure_sorted()
        return sorted(set(filt_val for filt_val, _ in self.simplices))
    
    def compute_persistence(self, max_dimension: int = 2) -> PersistenceDiagram:
        """
        Compute persistence diagram using standard algorithm.
        
        This is a simplified implementation that computes persistence by
        tracking when homology classes are born and die.
        
        Parameters
        ----------
        max_dimension : int
            Maximum homological dimension to compute
        
        Returns
        -------
        diagram : PersistenceDiagram
            Computed persistence diagram
        """
        self._ensure_sorted()
        
        pairs = []
        filtration_values = self.get_filtration_values()
        
        # Track Betti numbers across filtration
        prev_betti = {k: 0 for k in range(max_dimension + 1)}
        birth_times = {k: [] for k in range(max_dimension + 1)}
        
        for filt_val in filtration_values:
            complex_obj = self.get_complex_at(filt_val)
            curr_betti_list = complex_obj.compute_betti_numbers()
            
            # Convert list to dict
            curr_betti = {k: curr_betti_list[k] if k < len(curr_betti_list) else 0 
                         for k in range(max_dimension + 1)}
            
            for dim in range(max_dimension + 1):
                delta = curr_betti[dim] - prev_betti[dim]
                
                # Features born
                if delta > 0:
                    for _ in range(delta):
                        birth_times[dim].append(filt_val)
                
                # Features died
                elif delta < 0:
                    for _ in range(-delta):
                        if birth_times[dim]:
                            birth = birth_times[dim].pop(0)
                            # Compute chirality of feature
                            chirality = self._compute_feature_chirality(dim, birth, filt_val)
                            pairs.append(PersistencePair(dim, birth, filt_val, chirality))
            
            prev_betti = curr_betti
        
        # Remaining features are essential
        for dim in range(max_dimension + 1):
            for birth in birth_times[dim]:
                chirality = self._compute_feature_chirality(dim, birth, np.inf)
                pairs.append(PersistencePair(dim, birth, np.inf, chirality))
        
        return PersistenceDiagram(pairs)
    
    def _compute_feature_chirality(self, dimension: int, birth: float, death: float) -> Chirality:
        """
        Compute predominant chirality of a persistent feature.
        
        Analyzes chirality of simplices involved in the feature's birth and death.
        """
        # Get simplices in the birth-death interval
        relevant_simplices = [
            simplex for filt_val, simplex in self.simplices
            if birth <= filt_val < death and simplex.dimension == dimension
        ]
        
        if not relevant_simplices:
            return Chirality.NEUTRAL
        
        # Count chiralities of vertices
        chirality_counts = {Chirality.LEFT: 0, Chirality.RIGHT: 0, Chirality.NEUTRAL: 0}
        for simplex in relevant_simplices:
            for v_idx in simplex.vertices:
                chirality_counts[self.vertex_objects[v_idx].chirality] += 1
        
        # Return predominant chirality
        max_count = max(chirality_counts.values())
        for chirality, count in chirality_counts.items():
            if count == max_count:
                return chirality
        
        return Chirality.NEUTRAL
    
    def __len__(self) -> int:
        return len(self.simplices)
    
    def __repr__(self) -> str:
        return f"ChiralFiltration({len(self.simplices)} simplices, {len(self.vertex_objects)} vertices)"


def bottleneck_distance(dgm1: PersistenceDiagram, dgm2: PersistenceDiagram,
                       dimension: Optional[int] = None) -> float:
    """
    Compute bottleneck distance between two persistence diagrams.
    
    The bottleneck distance is the infimum over all matchings of the maximum
    distance between matched points:
    
    d_B(D1, D2) = inf_γ sup_{x∈D1} d(x, γ(x))
    
    where γ ranges over all matchings (bijections) between D1 and D2
    (including the diagonal).
    
    This is a simplified implementation using a greedy matching.
    
    Parameters
    ----------
    dgm1, dgm2 : PersistenceDiagram
        Persistence diagrams to compare
    dimension : Optional[int]
        If provided, only compare pairs of this dimension
    
    Returns
    -------
    distance : float
        Bottleneck distance
    """
    # Filter to dimension if specified
    if dimension is not None:
        dgm1 = dgm1.filter_by_dimension(dimension)
        dgm2 = dgm2.filter_by_dimension(dimension)
    
    # Convert to arrays (excluding essential features for simplicity)
    pairs1 = [p for p in dgm1.pairs if not p.is_essential]
    pairs2 = [p for p in dgm2.pairs if not p.is_essential]
    
    if not pairs1 and not pairs2:
        return 0.0
    
    # Compute all pairwise distances
    n1, n2 = len(pairs1), len(pairs2)
    
    # Distance between points
    def point_distance(p1: PersistencePair, p2: PersistencePair) -> float:
        return max(abs(p1.birth - p2.birth), abs(p1.death - p2.death))
    
    # Distance to diagonal
    def diagonal_distance(p: PersistencePair) -> float:
        return p.persistence / 2
    
    # Greedy matching (not optimal, but simple and bounded)
    max_dist = 0.0
    used2 = set()
    
    for p1 in pairs1:
        # Find closest match in dgm2 or diagonal
        min_match_dist = diagonal_distance(p1)
        
        for i, p2 in enumerate(pairs2):
            if i not in used2:
                dist = point_distance(p1, p2)
                if dist < min_match_dist:
                    min_match_dist = dist
        
        max_dist = max(max_dist, min_match_dist)
    
    # Check unmatched points in dgm2
    for i, p2 in enumerate(pairs2):
        if i not in used2:
            max_dist = max(max_dist, diagonal_distance(p2))
    
    return max_dist


def wasserstein_distance_diagrams(dgm1: PersistenceDiagram, dgm2: PersistenceDiagram,
                                  p: float = 2.0, dimension: Optional[int] = None) -> float:
    """
    Compute p-Wasserstein distance between persistence diagrams.
    
    The p-Wasserstein distance is:
    
    W_p(D1, D2) = (inf_γ Σ d(x, γ(x))^p)^(1/p)
    
    This is a simplified implementation using L^∞ matching (bottleneck).
    For a full implementation, would need optimal transport on diagrams.
    
    Parameters
    ----------
    dgm1, dgm2 : PersistenceDiagram
        Persistence diagrams to compare
    p : float
        Wasserstein exponent
    dimension : Optional[int]
        If provided, only compare pairs of this dimension
    
    Returns
    -------
    distance : float
        p-Wasserstein distance
    """
    # For now, use bottleneck as upper bound
    # Full implementation would use Hungarian algorithm
    return bottleneck_distance(dgm1, dgm2, dimension)


def vietoris_rips_filtration(objects: List[ChiralObject], 
                             max_radius: float,
                             max_dimension: int = 2,
                             n_steps: int = 20) -> ChiralFiltration:
    """
    Construct Vietoris-Rips filtration from point cloud.
    
    The Vietoris-Rips complex at radius r contains all simplices whose
    vertices are pairwise within distance r.
    
    Parameters
    ----------
    objects : List[ChiralObject]
        Point cloud of chiral objects
    max_radius : float
        Maximum radius for filtration
    max_dimension : int
        Maximum simplex dimension
    n_steps : int
        Number of filtration steps
    
    Returns
    -------
    filtration : ChiralFiltration
        Vietoris-Rips filtration
    """
    n = len(objects)
    filtration = ChiralFiltration(objects)
    
    # Compute pairwise distances
    distances = np.zeros((n, n))
    for i in range(n):
        for j in range(i+1, n):
            dist = objects[i].distance(objects[j])
            distances[i, j] = dist
            distances[j, i] = dist
    
    # Add vertices at radius 0
    for i in range(n):
        filtration.add_simplex_by_vertices([i], 0.0)
    
    # Generate all possible simplices up to max_dimension
    def generate_simplices(vertices: List[int], dim: int):
        """Generate all dim-simplices from vertices"""
        from itertools import combinations
        return list(combinations(vertices, dim + 1))
    
    # For each potential simplex, find when it enters
    for dim in range(1, max_dimension + 1):
        for simplex_vertices in generate_simplices(list(range(n)), dim):
            # Simplex enters when all edges are present
            # Edge enters at distance between endpoints
            max_edge_dist = 0.0
            for i in range(len(simplex_vertices)):
                for j in range(i+1, len(simplex_vertices)):
                    max_edge_dist = max(max_edge_dist, 
                                       distances[simplex_vertices[i], simplex_vertices[j]])
            
            if max_edge_dist <= max_radius:
                filtration.add_simplex_by_vertices(list(simplex_vertices), max_edge_dist)
    
    return filtration


def stability_constant(filtration: ChiralFiltration, epsilon: float,
                       max_dimension: int = 2) -> float:
    """
    Estimate stability constant for persistence diagram.
    
    The stability theorem states that persistence diagrams are stable
    under perturbations of the filtration.
    
    This function estimates how the diagram changes under small perturbations.
    
    Parameters
    ----------
    filtration : ChiralFiltration
        Input filtration
    epsilon : float
        Perturbation magnitude
    max_dimension : int
        Maximum homological dimension
    
    Returns
    -------
    constant : float
        Estimated stability constant
    """
    # Compute original diagram
    dgm_original = filtration.compute_persistence(max_dimension)
    
    # Perturb filtration values slightly
    perturbed_filtration = ChiralFiltration(filtration.vertex_objects)
    for filt_val, simplex in filtration.simplices:
        # Add small random perturbation
        perturbed_val = filt_val + np.random.uniform(-epsilon, epsilon)
        perturbed_filtration.add_simplex(simplex, max(0, perturbed_val))
    
    # Compute perturbed diagram
    dgm_perturbed = perturbed_filtration.compute_persistence(max_dimension)
    
    # Compute bottleneck distance
    distance = bottleneck_distance(dgm_original, dgm_perturbed)
    
    # Stability constant is distance / epsilon
    return distance / epsilon if epsilon > 0 else 0.0
