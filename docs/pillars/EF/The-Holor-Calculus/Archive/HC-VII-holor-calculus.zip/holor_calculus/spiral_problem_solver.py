"""SpiralLLM-Math Problem Solver Interface.

High-level interface for solving mathematical problems using SpiralLLM-Math:
- Unified problem-solving API
- Automatic reasoner selection
- Interactive problem exploration
- Solution explanation and visualization
"""

from typing import Any, Dict, List, Optional, Union
import numpy as np

from .spiral_llm_math import (
    SpiralLLMMath, MathematicalProblem, Solution, ReasoningMode
)
from .spiral_homotopy_reasoner import HomotopyReasoner
from .spiral_info_geometry_reasoner import InfoGeometryReasoner
from .spiral_homology_reasoner import HomologyReasoner
from .spiral_optimal_transport_reasoner import OptimalTransportReasoner
from .spiral_persistent_homology_reasoner import PersistentHomologyReasoner
from .spiral_spectral_geometry_reasoner import SpectralGeometryReasoner
from .chiral_base import ChiralObject, Chirality
from .homotopy import ChiralPath
from .homology import ChiralChain, ChiralSimplicialComplex
from .optimal_transport import ChiralMeasure
from .persistent_homology import ChiralFiltration, PersistenceDiagram
from .spectral_geometry import ChiralGraphLaplacian


class SpiralProblemSolver:
    """High-level interface for solving mathematical problems.
    
    Provides:
    - Unified API for all problem types
    - Automatic reasoner selection
    - Solution explanation
    - Problem exploration tools
    """

    def __init__(self, mode: ReasoningMode = ReasoningMode.HYBRID):
        """Initialize problem solver.
        
        Args:
            mode: Reasoning mode to use
        """
        self.engine = SpiralLLMMath(mode)
        self.homotopy_reasoner = HomotopyReasoner(self.engine)
        self.info_geo_reasoner = InfoGeometryReasoner(self.engine)
        self.homology_reasoner = HomologyReasoner(self.engine)
        self.optimal_transport_reasoner = OptimalTransportReasoner(self.engine)
        self.persistent_homology_reasoner = PersistentHomologyReasoner(self.engine)
        self.spectral_geometry_reasoner = SpectralGeometryReasoner(self.engine)

    def solve_homotopy_problem(self, 
                              path1: ChiralPath,
                              path2: Optional[ChiralPath] = None,
                              operation: str = 'create') -> Solution:
        """Solve a homotopy problem.
        
        Args:
            path1: First path
            path2: Second path (optional, depending on operation)
            operation: Operation type ('create', 'compose', 'verify_equivalence', etc.)
            
        Returns:
            Solution with reasoning chain
        """
        input_data = {'path1': path1, 'operation': operation}
        if path2 is not None:
            input_data['path2'] = path2
        
        problem = MathematicalProblem(
            problem_type='homotopy',
            description=f'Homotopy problem: {operation}',
            input_data=input_data
        )
        
        return self.engine.solve(problem)

    def solve_divergence_problem(self,
                                obj1: ChiralObject,
                                obj2: ChiralObject,
                                divergence_type: str = 'kl') -> Solution:
        """Solve a divergence problem.
        
        Args:
            obj1: First chiral object
            obj2: Second chiral object
            divergence_type: Type of divergence ('kl', 'hellinger', 'fisher_rao', 'alpha')
            
        Returns:
            Solution with reasoning chain
        """
        problem = MathematicalProblem(
            problem_type='divergence',
            description=f'{divergence_type.upper()} divergence computation',
            input_data={
                'object1': obj1,
                'object2': obj2,
                'type': divergence_type
            }
        )
        
        return self.engine.solve(problem)

    def solve_fisher_metric_problem(self,
                                   distribution: str = 'gaussian',
                                   dim: int = 2,
                                   operation: str = 'compute') -> Solution:
        """Solve a Fisher metric problem.
        
        Args:
            distribution: Distribution type
            dim: Dimension
            operation: Operation type ('compute', 'geodesic', 'curvature')
            
        Returns:
            Solution with reasoning chain
        """
        problem = MathematicalProblem(
            problem_type='fisher_metric',
            description=f'Fisher metric problem: {operation}',
            input_data={
                'distribution': distribution,
                'dim': dim,
                'operation': operation
            }
        )
        
        return self.engine.solve(problem)

    def solve_geometric_statistics_problem(self,
                                          objects: List[ChiralObject],
                                          metric: Any,
                                          operation: str = 'frechet_mean') -> Solution:
        """Solve a geometric statistics problem.
        
        Args:
            objects: List of chiral objects
            metric: Fisher metric
            operation: Operation type ('frechet_mean', 'variance', 'interpolate')
            
        Returns:
            Solution with reasoning chain
        """
        problem = MathematicalProblem(
            problem_type='geometric_statistics',
            description=f'Geometric statistics: {operation}',
            input_data={
                'objects': objects,
                'metric': metric,
                'operation': operation
            }
        )
        
        return self.engine.solve(problem)

    def solve_homology_problem(self,
                              chain: Optional[ChiralChain] = None,
                              complex_obj: Optional[ChiralSimplicialComplex] = None,
                              operation: str = 'compute_boundary') -> Solution:
        """Solve a homology problem.
        
        Args:
            chain: Chiral chain (for boundary computations)
            complex_obj: Simplicial complex (for Betti numbers, Euler characteristic)
            operation: Operation type ('compute_boundary', 'verify_boundary_property', 
                      'compute_homology_groups', 'analyze_complex')
            
        Returns:
            Solution with reasoning chain
        """
        input_data = {'operation': operation}
        if chain is not None:
            input_data['chain'] = chain
        if complex_obj is not None:
            input_data['complex'] = complex_obj
        
        problem = MathematicalProblem(
            problem_type='homology',
            description=f'Homology problem: {operation}',
            input_data=input_data
        )
        
        return self.engine.solve(problem)

    def solve_betti_numbers_problem(self, complex_obj: ChiralSimplicialComplex) -> Solution:
        """Solve a Betti number computation problem.
        
        Args:
            complex_obj: Simplicial complex
            
        Returns:
            Solution with Betti numbers and analysis
        """
        problem = MathematicalProblem(
            problem_type='betti_numbers',
            description='Betti number computation',
            input_data={'complex': complex_obj}
        )
        
        return self.engine.solve(problem)

    def solve_euler_characteristic_problem(self, complex_obj: ChiralSimplicialComplex) -> Solution:
        """Solve an Euler characteristic problem.
        
        Args:
            complex_obj: Simplicial complex
            
        Returns:
            Solution with Euler characteristic analysis
        """
        problem = MathematicalProblem(
            problem_type='euler_characteristic',
            description='Euler characteristic computation',
            input_data={'complex': complex_obj}
        )
        
        return self.engine.solve(problem)

    def solve_wasserstein_problem(self,
                                 source: ChiralMeasure,
                                 target: ChiralMeasure,
                                 p: float = 2.0,
                                 chirality_penalty: float = 1.0) -> Solution:
        """Solve a Wasserstein distance problem.
        
        Args:
            source: Source measure
            target: Target measure
            p: Wasserstein distance order
            chirality_penalty: Penalty for chirality mismatch
            
        Returns:
            Solution with distance and coupling
        """
        problem = MathematicalProblem(
            problem_type='wasserstein',
            description=f'{p}-Wasserstein distance computation',
            input_data={
                'source': source,
                'target': target,
                'p': p,
                'chirality_penalty': chirality_penalty
            }
        )
        
        return self.engine.solve(problem)

    def solve_barycenter_problem(self,
                                measures: List[ChiralMeasure],
                                weights: Optional[np.ndarray] = None,
                                n_support: int = 5,
                                p: float = 2.0) -> Solution:
        """Solve a Wasserstein barycenter problem.
        
        Args:
            measures: List of measures
            weights: Barycentric weights (None for uniform)
            n_support: Number of support points for barycenter
            p: Wasserstein distance order
            
        Returns:
            Solution with barycenter
        """
        problem = MathematicalProblem(
            problem_type='barycenter',
            description='Wasserstein barycenter computation',
            input_data={
                'measures': measures,
                'weights': weights,
                'n_support': n_support,
                'p': p
            }
        )
        
        return self.engine.solve(problem)

    def solve_displacement_interpolation_problem(self,
                                                source: ChiralMeasure,
                                                target: ChiralMeasure,
                                                t: float = 0.5,
                                                n_points: int = 10) -> Solution:
        """Solve a displacement interpolation problem.
        
        Args:
            source: Source measure
            target: Target measure
            t: Interpolation parameter in [0,1]
            n_points: Number of points for geodesic
            
        Returns:
            Solution with interpolated measure
        """
        problem = MathematicalProblem(
            problem_type='displacement_interpolation',
            description=f'Displacement interpolation at t={t}',
            input_data={
                'source': source,
                'target': target,
                't': t,
                'n_points': n_points
            }
        )
        
        return self.engine.solve(problem)

    def explain_solution(self, solution: Solution, detailed: bool = True) -> str:
        """Generate explanation of a solution.
        
        Args:
            solution: Solution to explain
            detailed: Whether to include detailed reasoning trace
            
        Returns:
            Natural language explanation
        """
        if detailed:
            return solution.get_reasoning_trace()
        else:
            return f"""Problem: {solution.problem.description}
Result: {solution.result}
Verified: {'Yes' if solution.verification_status else 'No'}
Confidence: {solution.confidence:.2%}"""

    def compare_approaches(self, problem: MathematicalProblem,
                          modes: List[ReasoningMode]) -> Dict[str, Solution]:
        """Compare different reasoning approaches for a problem.
        
        Args:
            problem: Problem to solve
            modes: List of reasoning modes to try
            
        Returns:
            Dictionary mapping mode names to solutions
        """
        results = {}
        
        for mode in modes:
            engine = SpiralLLMMath(mode)
            # Register reasoners
            HomotopyReasoner(engine)
            InfoGeometryReasoner(engine)
            HomologyReasoner(engine)
            OptimalTransportReasoner(engine)
            
            solution = engine.solve(problem)
            results[mode.value] = solution
        
        return results

    def get_statistics(self) -> Dict[str, Any]:
        """Get solver statistics."""
        return self.engine.get_statistics()

    def get_history(self) -> List[Solution]:
        """Get problem-solving history."""
        return self.engine.get_history()

    def interactive_explore(self, problem_type: str) -> Dict[str, Any]:
        """Interactive exploration of a problem type.
        
        Args:
            problem_type: Type of problem to explore
            
        Returns:
            Exploration results with examples and insights
        """
        examples = []
        insights = []
        
        if problem_type == 'homotopy':
            insights.append("Homotopy theory studies continuous deformations")
            insights.append("Paths are equivalent if they can be continuously deformed into each other")
            insights.append("Chirality transitions occur at specific parameter values")
            
            # Generate example
            p0 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
            p1 = ChiralObject(np.array([1.0, 1.0]), Chirality.RIGHT)
            path = ChiralPath(p0, p1)
            examples.append({
                'description': 'Simple path from LEFT to RIGHT chirality',
                'path': path
            })
        
        elif problem_type == 'divergence':
            insights.append("Divergences measure dissimilarity between distributions")
            insights.append("KL divergence is asymmetric: D(P||Q) ≠ D(Q||P)")
            insights.append("Hellinger and Fisher-Rao are symmetric distances")
            insights.append("Chirality mismatches increase divergence values")
            
            # Generate example
            obj1 = ChiralObject(np.array([0.0, 0.0]), Chirality.LEFT)
            obj2 = ChiralObject(np.array([0.1, 0.1]), Chirality.LEFT)
            examples.append({
                'description': 'Two LEFT-chiral objects with small distance',
                'objects': (obj1, obj2)
            })
        
        elif problem_type == 'fisher_metric':
            insights.append("Fisher metric defines the Riemannian geometry of statistical manifolds")
            insights.append("Geodesic distance is the natural distance between distributions")
            insights.append("Curvature reveals geometric properties of the manifold")
        
        return {
            'problem_type': problem_type,
            'insights': insights,
            'examples': examples,
            'available_operations': self._get_operations(problem_type)
        }

    def _get_operations(self, problem_type: str) -> List[str]:
        """Get available operations for a problem type."""
        operations = {
            'homotopy': ['create', 'compose', 'verify_equivalence', 'compute_winding'],
            'divergence': ['kl', 'hellinger', 'fisher_rao', 'alpha'],
            'fisher_metric': ['compute', 'geodesic', 'curvature'],
            'geometric_statistics': ['frechet_mean', 'variance', 'interpolate']
        }
        return operations.get(problem_type, [])

    def batch_solve(self, problems: List[MathematicalProblem]) -> List[Solution]:
        """Solve multiple problems in batch.
        
        Args:
            problems: List of problems to solve
            
        Returns:
            List of solutions
        """
        return [self.engine.solve(problem) for problem in problems]

    def create_problem_from_dict(self, data: Dict[str, Any]) -> MathematicalProblem:
        """Create a problem from dictionary specification.
        
        Args:
            data: Dictionary with problem specification
            
        Returns:
            Mathematical problem
        """
        return MathematicalProblem(
            problem_type=data['problem_type'],
            description=data.get('description', ''),
            input_data=data.get('input_data', {}),
            constraints=data.get('constraints', []),
            expected_properties=data.get('expected_properties', []),
            metadata=data.get('metadata', {})
        )



    # §9: Persistent Homology methods

    def solve_persistence_problem(self,
                                 filtration: ChiralFiltration,
                                 max_dimension: int = 2,
                                 operation: str = 'compute_diagram') -> Solution:
        """Solve a persistence problem.
        
        Args:
            filtration: Chiral filtration
            max_dimension: Maximum homological dimension
            operation: Operation type
            
        Returns:
            Solution with persistence analysis
        """
        problem = MathematicalProblem(
            problem_type='persistence',
            description=f'Persistence problem: {operation}',
            input_data={
                'filtration': filtration,
                'max_dimension': max_dimension,
                'operation': operation
            }
        )
        
        return self.engine.solve(problem)

    def solve_persistence_diagram_problem(self,
                                        filtration: ChiralFiltration,
                                        max_dimension: int = 2) -> Solution:
        """Compute persistence diagram.
        
        Args:
            filtration: Chiral filtration
            max_dimension: Maximum homological dimension
            
        Returns:
            Solution with diagram analysis
        """
        problem = MathematicalProblem(
            problem_type='persistence_diagram',
            description='Compute and analyze persistence diagram',
            input_data={
                'filtration': filtration,
                'max_dimension': max_dimension
            }
        )
        
        return self.engine.solve(problem)

    def solve_bottleneck_problem(self,
                                dgm1: PersistenceDiagram,
                                dgm2: PersistenceDiagram,
                                dimension: Optional[int] = None) -> Solution:
        """Compute bottleneck distance between diagrams.
        
        Args:
            dgm1: First persistence diagram
            dgm2: Second persistence diagram
            dimension: Optional dimension filter
            
        Returns:
            Solution with distance analysis
        """
        problem = MathematicalProblem(
            problem_type='bottleneck',
            description='Compute bottleneck distance',
            input_data={
                'diagram1': dgm1,
                'diagram2': dgm2,
                'dimension': dimension
            }
        )
        
        return self.engine.solve(problem)

    # §10: Spectral Geometry methods

    def solve_spectral_problem(self,
                              objects: List[ChiralObject],
                              chirality_penalty: float = 1.0,
                              operation: str = 'compute_spectrum') -> Solution:
        """Solve a spectral geometry problem.
        
        Args:
            objects: List of chiral objects (graph vertices)
            chirality_penalty: Chirality penalty for edges
            operation: Operation type
            
        Returns:
            Solution with spectral analysis
        """
        problem = MathematicalProblem(
            problem_type='spectral',
            description=f'Spectral problem: {operation}',
            input_data={
                'objects': objects,
                'chirality_penalty': chirality_penalty,
                'operation': operation
            }
        )
        
        return self.engine.solve(problem)

    def solve_laplacian_spectrum_problem(self,
                                        objects: List[ChiralObject],
                                        chirality_penalty: float = 1.0,
                                        normalize: bool = True,
                                        k: Optional[int] = None) -> Solution:
        """Compute and analyze Laplacian spectrum.
        
        Args:
            objects: List of chiral objects
            chirality_penalty: Chirality penalty
            normalize: Use normalized Laplacian
            k: Number of eigenvalues (None = all)
            
        Returns:
            Solution with comprehensive spectrum analysis
        """
        problem = MathematicalProblem(
            problem_type='laplacian_spectrum',
            description='Compute and analyze Laplacian spectrum',
            input_data={
                'objects': objects,
                'chirality_penalty': chirality_penalty,
                'normalize': normalize,
                'k': k
            }
        )
        
        return self.engine.solve(problem)

    def solve_heat_kernel_problem(self,
                                 objects: List[ChiralObject],
                                 initial_distribution: Optional[np.ndarray] = None,
                                 time: float = 1.0,
                                 chirality_penalty: float = 1.0) -> Solution:
        """Solve heat kernel / diffusion problem.
        
        Args:
            objects: List of chiral objects
            initial_distribution: Initial distribution (None = point source at 0)
            time: Evolution time
            chirality_penalty: Chirality penalty
            
        Returns:
            Solution with diffusion analysis
        """
        problem = MathematicalProblem(
            problem_type='heat_kernel',
            description='Heat diffusion computation',
            input_data={
                'objects': objects,
                'initial_distribution': initial_distribution,
                'time': time,
                'chirality_penalty': chirality_penalty
            }
        )
        
        return self.engine.solve(problem)

    def solve_spectral_clustering_problem(self,
                                        objects: List[ChiralObject],
                                        n_clusters: int = 2,
                                        chirality_penalty: float = 1.0,
                                        use_fiedler: bool = True) -> Solution:
        """Perform spectral clustering.
        
        Args:
            objects: List of chiral objects
            n_clusters: Number of clusters
            chirality_penalty: Chirality penalty
            use_fiedler: Use Fiedler vector for binary clustering
            
        Returns:
            Solution with clustering results
        """
        problem = MathematicalProblem(
            problem_type='spectral_clustering',
            description=f'Spectral clustering into {n_clusters} clusters',
            input_data={
                'objects': objects,
                'n_clusters': n_clusters,
                'chirality_penalty': chirality_penalty,
                'use_fiedler': use_fiedler
            }
        )
        
        return self.engine.solve(problem)
