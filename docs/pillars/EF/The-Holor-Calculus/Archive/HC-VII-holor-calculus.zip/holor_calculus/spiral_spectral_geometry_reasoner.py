"""SpiralLLM-Math Spectral Geometry Reasoner for §10.

Specialized reasoning capabilities for spectral geometry:
- Laplacian spectrum computation and analysis
- Heat kernel and diffusion processes
- Spectral clustering with chirality
- Eigenvalue-based topological inference
- Graph energy and spectral invariants
"""

from typing import Any, Dict, List, Optional
import numpy as np

from .spiral_llm_math import MathematicalProblem, SpiralLLMMath, Solution, ReasoningStep
from .spectral_geometry import (
    LaplacianSpectrum, ChiralGraphLaplacian, HodgeDecomposition, ChiralDiffusion,
    compute_cheeger_constant, compute_graph_energy, compute_estrada_index, spectral_distance
)
from .chiral_base import ChiralObject, Chirality


class SpectralGeometryReasoner:
    """Specialized reasoner for spectral geometry problems.
    
    Provides reasoning capabilities for:
    - Laplacian eigenvalue analysis
    - Spectral clustering and graph partitioning
    - Heat diffusion and mixing times
    - Spectral distances and graph comparison
    - Topological inference from spectra
    """

    def __init__(self, spiral_engine: Optional[SpiralLLMMath] = None):
        """Initialize spectral geometry reasoner.
        
        Args:
            spiral_engine: SpiralLLM-Math engine to register with
        """
        self.spiral_engine = spiral_engine
        if spiral_engine:
            spiral_engine.register_reasoner('spectral', self.solve_spectral)
            spiral_engine.register_reasoner('laplacian_spectrum', self.solve_laplacian_spectrum)
            spiral_engine.register_reasoner('heat_kernel', self.solve_heat_kernel)
            spiral_engine.register_reasoner('spectral_clustering', self.solve_spectral_clustering)
            spiral_engine.register_verifier('spectral', self.verify_spectral)

    def solve_spectral(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Solve a general spectral geometry problem.
        
        Args:
            problem: Problem with spectral-related data
            
        Returns:
            Solution data
        """
        operation = problem.input_data.get('operation', 'compute')
        
        if operation == 'compute_spectrum':
            return self._compute_spectrum(problem)
        elif operation == 'analyze_connectivity':
            return self._analyze_connectivity(problem)
        elif operation == 'compute_diffusion':
            return self._compute_diffusion(problem)
        elif operation == 'compare_graphs':
            return self._compare_graphs(problem)
        else:
            return {'error': f'Unknown operation: {operation}'}

    def solve_laplacian_spectrum(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Compute and analyze Laplacian spectrum.
        
        Args:
            problem: Problem with graph/objects data
            
        Returns:
            Spectrum and comprehensive analysis
        """
        objects = problem.input_data.get('objects')
        chirality_penalty = problem.input_data.get('chirality_penalty', 1.0)
        normalize = problem.input_data.get('normalize', True)
        k = problem.input_data.get('k', None)
        
        if not isinstance(objects, list) or not objects:
            return {'error': 'Invalid objects provided'}
        
        # Build Laplacian
        laplacian = ChiralGraphLaplacian(objects, chirality_penalty, normalize)
        
        # Compute spectrum
        spectrum = laplacian.compute_spectrum(k)
        
        # Comprehensive analysis
        analysis = self._analyze_spectrum(spectrum, laplacian)
        
        # Topological inference
        topology = self._infer_topology(spectrum, laplacian)
        
        return {
            'spectrum': spectrum,
            'eigenvalues': spectrum.eigenvalues.tolist(),
            'n_eigenvalues': len(spectrum.eigenvalues),
            'spectral_gap': spectrum.spectral_gap,
            'algebraic_connectivity': spectrum.algebraic_connectivity,
            'n_components': spectrum.num_connected_components(),
            'fiedler_vector': spectrum.fiedler_vector().tolist(),
            'analysis': analysis,
            'topology': topology,
            'explanation': self._explain_spectrum(spectrum, analysis, topology)
        }

    def _analyze_spectrum(self, spectrum: LaplacianSpectrum, 
                         laplacian: ChiralGraphLaplacian) -> Dict[str, Any]:
        """Comprehensive spectrum analysis."""
        # Basic statistics
        eigenvalues = spectrum.eigenvalues
        
        analysis = {
            'min_eigenvalue': float(eigenvalues[0]),
            'max_eigenvalue': float(eigenvalues[-1]),
            'mean_eigenvalue': float(np.mean(eigenvalues)),
            'spectral_gap': spectrum.spectral_gap,
            'algebraic_connectivity': spectrum.algebraic_connectivity
        }
        
        # Graph invariants
        try:
            analysis['cheeger_constant'] = compute_cheeger_constant(laplacian)
            analysis['graph_energy'] = compute_graph_energy(laplacian)
            analysis['estrada_index'] = compute_estrada_index(laplacian)
        except:
            # May fail for small graphs
            pass
        
        # Multiplicity analysis
        eigenvalue_counts = {}
        for ev in eigenvalues:
            ev_rounded = round(float(ev), 6)
            eigenvalue_counts[ev_rounded] = eigenvalue_counts.get(ev_rounded, 0) + 1
        
        analysis['eigenvalue_multiplicities'] = {
            k: v for k, v in eigenvalue_counts.items() if v > 1
        }
        
        return analysis

    def _infer_topology(self, spectrum: LaplacianSpectrum,
                       laplacian: ChiralGraphLaplacian) -> Dict[str, Any]:
        """Infer topological properties from spectrum."""
        topology = {}
        
        # Connectivity
        n_components = spectrum.num_connected_components()
        topology['n_connected_components'] = n_components
        topology['is_connected'] = (n_components == 1)
        
        # Bipartiteness (check if largest eigenvalue ≈ 2)
        if laplacian.normalize:
            largest_ev = float(spectrum.eigenvalues[-1])
            topology['is_bipartite'] = abs(largest_ev - 2.0) < 0.01
        
        # Expansion properties
        gap = spectrum.spectral_gap
        if gap > 0.1:
            topology['expansion'] = 'good'
        elif gap > 0.01:
            topology['expansion'] = 'moderate'
        else:
            topology['expansion'] = 'poor'
        
        # Mixing properties
        alg_conn = spectrum.algebraic_connectivity
        if alg_conn > 0.5:
            topology['mixing'] = 'fast'
        elif alg_conn > 0.1:
            topology['mixing'] = 'moderate'
        else:
            topology['mixing'] = 'slow'
        
        return topology

    def _explain_spectrum(self, spectrum: LaplacianSpectrum,
                         analysis: Dict, topology: Dict) -> str:
        """Generate natural language explanation of spectrum."""
        parts = []
        
        parts.append(f"Laplacian spectrum contains {len(spectrum.eigenvalues)} eigenvalues.")
        
        # Connectivity
        n_comp = topology['n_connected_components']
        if n_comp == 1:
            parts.append("\nGraph is connected (single component).")
        else:
            parts.append(f"\nGraph has {n_comp} disconnected components.")
        
        # Spectral gap
        gap = spectrum.spectral_gap
        parts.append(f"\nSpectral gap: {gap:.6f}")
        if gap > 0.1:
            parts.append("  → Large gap indicates good connectivity and fast mixing.")
        elif gap < 0.01:
            parts.append("  → Small gap suggests weak connectivity or bottlenecks.")
        
        # Algebraic connectivity
        alg_conn = spectrum.algebraic_connectivity
        parts.append(f"Algebraic connectivity (Fiedler value): {alg_conn:.6f}")
        
        # Topology summary
        parts.append(f"\nTopological properties:")
        parts.append(f"  - Expansion: {topology.get('expansion', 'unknown')}")
        parts.append(f"  - Mixing: {topology.get('mixing', 'unknown')}")
        
        # Graph invariants
        if 'graph_energy' in analysis:
            parts.append(f"\nGraph energy: {analysis['graph_energy']:.4f}")
        if 'cheeger_constant' in analysis:
            parts.append(f"Cheeger constant: {analysis['cheeger_constant']:.4f}")
        
        return "\n".join(parts)

    def solve_heat_kernel(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Solve heat kernel/diffusion problem.
        
        Args:
            problem: Problem with diffusion data
            
        Returns:
            Diffusion results and analysis
        """
        objects = problem.input_data.get('objects')
        initial = problem.input_data.get('initial_distribution')
        time = problem.input_data.get('time', 1.0)
        chirality_penalty = problem.input_data.get('chirality_penalty', 1.0)
        
        if not isinstance(objects, list) or not objects:
            return {'error': 'Invalid objects provided'}
        
        n = len(objects)
        
        # Default initial distribution (point source at vertex 0)
        if initial is None:
            initial = np.zeros(n)
            initial[0] = 1.0
        
        # Create diffusion process
        diffusion = ChiralDiffusion(objects, base_diffusivity=1.0, 
                                   chirality_coupling=chirality_penalty)
        
        # Evolve distribution
        final = diffusion.evolve(initial, time, method='spectral')
        
        # Compute stationary distribution
        stationary = diffusion.stationary_distribution()
        
        # Estimate mixing time
        mixing_time = diffusion.mixing_time(tolerance=0.01)
        
        # Analyze evolution
        total_mass = final.sum()
        entropy = -np.sum(final * np.log(final + 1e-10))
        
        return {
            'initial_distribution': initial.tolist(),
            'final_distribution': final.tolist(),
            'time': time,
            'stationary_distribution': stationary.tolist(),
            'mixing_time': mixing_time,
            'total_mass': total_mass,
            'entropy': entropy,
            'mass_conserved': abs(total_mass - 1.0) < 1e-6,
            'explanation': self._explain_diffusion(time, mixing_time, entropy)
        }

    def _explain_diffusion(self, time: float, mixing_time: float, entropy: float) -> str:
        """Explain diffusion process."""
        parts = []
        
        parts.append(f"Heat diffusion at time t = {time:.4f}")
        
        if time < mixing_time:
            progress = time / mixing_time * 100
            parts.append(f"\nMixing progress: {progress:.1f}% (mixing time ≈ {mixing_time:.4f})")
            parts.append("Distribution is still evolving toward equilibrium.")
        else:
            parts.append(f"\nPast mixing time ({mixing_time:.4f}), near stationary distribution.")
        
        parts.append(f"\nEntropy: {entropy:.4f}")
        parts.append("Higher entropy indicates more spread-out distribution.")
        
        return "\n".join(parts)

    def solve_spectral_clustering(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Perform spectral clustering.
        
        Args:
            problem: Problem with objects and clustering parameters
            
        Returns:
            Cluster assignments and analysis
        """
        objects = problem.input_data.get('objects')
        n_clusters = problem.input_data.get('n_clusters', 2)
        chirality_penalty = problem.input_data.get('chirality_penalty', 1.0)
        use_fiedler = problem.input_data.get('use_fiedler', True)
        
        if not isinstance(objects, list) or not objects:
            return {'error': 'Invalid objects provided'}
        
        # Build Laplacian
        laplacian = ChiralGraphLaplacian(objects, chirality_penalty, normalize=True)
        
        # Perform clustering
        labels = laplacian.spectral_clustering(n_clusters, use_fiedler=(n_clusters==2 and use_fiedler))
        
        # Analyze clusters
        cluster_analysis = self._analyze_clusters(objects, labels)
        
        return {
            'labels': labels.tolist(),
            'n_clusters': n_clusters,
            'cluster_sizes': cluster_analysis['sizes'],
            'cluster_chirality': cluster_analysis['chirality_dist'],
            'within_cluster_distance': cluster_analysis['within_distance'],
            'between_cluster_distance': cluster_analysis['between_distance'],
            'silhouette_score': cluster_analysis['silhouette'],
            'explanation': self._explain_clustering(cluster_analysis)
        }

    def _analyze_clusters(self, objects: List[ChiralObject], labels: np.ndarray) -> Dict[str, Any]:
        """Analyze clustering quality."""
        n_clusters = len(set(labels))
        
        # Cluster sizes
        sizes = {}
        for label in labels:
            sizes[int(label)] = sizes.get(int(label), 0) + 1
        
        # Chirality distribution per cluster
        chirality_dist = {}
        for cluster_id in range(n_clusters):
            mask = labels == cluster_id
            cluster_objects = [obj for i, obj in enumerate(objects) if mask[i]]
            
            chir_counts = {}
            for obj in cluster_objects:
                chir_counts[obj.chirality] = chir_counts.get(obj.chirality, 0) + 1
            
            chirality_dist[cluster_id] = chir_counts
        
        # Distance statistics
        within_distances = []
        between_distances = []
        
        for i in range(len(objects)):
            for j in range(i+1, len(objects)):
                dist = objects[i].distance(objects[j])
                if labels[i] == labels[j]:
                    within_distances.append(dist)
                else:
                    between_distances.append(dist)
        
        within_dist = np.mean(within_distances) if within_distances else 0.0
        between_dist = np.mean(between_distances) if between_distances else 0.0
        
        # Silhouette score (simplified)
        silhouette = 0.0
        if within_dist > 0:
            silhouette = (between_dist - within_dist) / max(between_dist, within_dist)
        
        return {
            'sizes': sizes,
            'chirality_dist': {k: {c.name: v for c, v in cd.items()} 
                             for k, cd in chirality_dist.items()},
            'within_distance': within_dist,
            'between_distance': between_dist,
            'silhouette': silhouette
        }

    def _explain_clustering(self, analysis: Dict) -> str:
        """Explain clustering results."""
        parts = []
        
        parts.append("Spectral clustering results:")
        
        # Cluster sizes
        sizes = analysis['sizes']
        parts.append(f"\nCluster sizes: {sizes}")
        
        # Quality
        silhouette = analysis['silhouette']
        parts.append(f"\nSilhouette score: {silhouette:.4f}")
        
        if silhouette > 0.5:
            parts.append("  → Strong, well-separated clusters")
        elif silhouette > 0.25:
            parts.append("  → Moderate cluster separation")
        else:
            parts.append("  → Weak cluster separation")
        
        # Distances
        within = analysis['within_distance']
        between = analysis['between_distance']
        parts.append(f"\nWithin-cluster distance: {within:.4f}")
        parts.append(f"Between-cluster distance: {between:.4f}")
        
        return "\n".join(parts)

    def _compute_spectrum(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Compute spectrum."""
        return self.solve_laplacian_spectrum(problem)

    def _analyze_connectivity(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Analyze graph connectivity."""
        result = self.solve_laplacian_spectrum(problem)
        
        # Extract connectivity information
        return {
            'n_components': result.get('n_components', 0),
            'algebraic_connectivity': result.get('algebraic_connectivity', 0.0),
            'spectral_gap': result.get('spectral_gap', 0.0),
            'is_connected': result.get('n_components', 0) == 1,
            'topology': result.get('topology', {})
        }

    def _compute_diffusion(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Compute diffusion."""
        return self.solve_heat_kernel(problem)

    def _compare_graphs(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Compare two graphs spectrally."""
        objects1 = problem.input_data.get('objects1')
        objects2 = problem.input_data.get('objects2')
        chirality_penalty = problem.input_data.get('chirality_penalty', 1.0)
        k = problem.input_data.get('k', 10)
        
        if not objects1 or not objects2:
            return {'error': 'Invalid objects provided'}
        
        # Build Laplacians
        lap1 = ChiralGraphLaplacian(objects1, chirality_penalty)
        lap2 = ChiralGraphLaplacian(objects2, chirality_penalty)
        
        # Compute spectra
        spec1 = lap1.compute_spectrum(k)
        spec2 = lap2.compute_spectrum(k)
        
        # Compute spectral distance
        distance = spectral_distance(lap1, lap2, k)
        
        # Compare properties
        comparison = {
            'n_vertices': (len(objects1), len(objects2)),
            'spectral_gap': (spec1.spectral_gap, spec2.spectral_gap),
            'algebraic_connectivity': (spec1.algebraic_connectivity, spec2.algebraic_connectivity),
            'n_components': (spec1.num_connected_components(), spec2.num_connected_components()),
            'spectral_distance': distance
        }
        
        return {
            'comparison': comparison,
            'distance': distance,
            'are_similar': distance < 0.1,
            'explanation': self._explain_comparison(comparison, distance)
        }

    def _explain_comparison(self, comparison: Dict, distance: float) -> str:
        """Explain graph comparison."""
        parts = []
        
        parts.append(f"Spectral distance: {distance:.6f}")
        
        if distance < 0.01:
            parts.append("\nGraphs are spectrally very similar (near-isomorphic).")
        elif distance < 0.1:
            parts.append("\nGraphs are spectrally similar.")
        else:
            parts.append("\nGraphs show significant spectral differences.")
        
        n1, n2 = comparison['n_vertices']
        parts.append(f"\nVertex counts: {n1} vs {n2}")
        
        gap1, gap2 = comparison['spectral_gap']
        parts.append(f"Spectral gaps: {gap1:.6f} vs {gap2:.6f}")
        
        comp1, comp2 = comparison['n_components']
        parts.append(f"Connected components: {comp1} vs {comp2}")
        
        return "\n".join(parts)

    def verify_spectral(self, solution: Solution) -> Dict[str, Any]:
        """Verify spectral computation results.
        
        Args:
            solution: Solution to verify
            
        Returns:
            Verification results
        """
        result = solution.result
        
        checks = {
            'has_spectrum': 'spectrum' in result or 'eigenvalues' in result,
            'real_eigenvalues': False,
            'nonnegative_eigenvalues': False,
            'sorted_eigenvalues': False
        }
        
        if 'eigenvalues' in result:
            eigenvalues = np.array(result['eigenvalues'])
            
            # Check real
            checks['real_eigenvalues'] = np.all(np.isreal(eigenvalues))
            
            # Check non-negative (for Laplacian)
            checks['nonnegative_eigenvalues'] = np.all(eigenvalues >= -1e-10)
            
            # Check sorted
            checks['sorted_eigenvalues'] = np.all(eigenvalues[:-1] <= eigenvalues[1:])
        
        all_passed = all(checks.values())
        
        return {
            'valid': all_passed,
            'checks': checks,
            'message': 'Spectral verification passed' if all_passed else 'Spectral verification failed'
        }
