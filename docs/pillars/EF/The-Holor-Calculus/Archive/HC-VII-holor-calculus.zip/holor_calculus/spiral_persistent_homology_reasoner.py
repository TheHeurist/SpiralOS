"""SpiralLLM-Math Persistent Homology Reasoner for §9.

Specialized reasoning capabilities for persistent homology:
- Filtration analysis
- Persistence diagram computation
- Barcode visualization and analysis
- Bottleneck distance calculation
- Stability and topological data analysis
"""

from typing import Any, Dict, List, Optional
import numpy as np

from .spiral_llm_math import MathematicalProblem, SpiralLLMMath, Solution, ReasoningStep
from .persistent_homology import (
    PersistencePair, PersistenceDiagram, PersistenceBarcode, ChiralFiltration,
    bottleneck_distance, wasserstein_distance_diagrams, vietoris_rips_filtration,
    stability_constant
)
from .chiral_base import ChiralObject, Chirality


class PersistentHomologyReasoner:
    """Specialized reasoner for persistent homology problems.
    
    Provides reasoning capabilities for:
    - Persistence diagram computation
    - Barcode analysis and visualization
    - Topological feature tracking across scales
    - Diagram distances (bottleneck, Wasserstein)
    - Stability analysis under perturbations
    """

    def __init__(self, spiral_engine: Optional[SpiralLLMMath] = None):
        """Initialize persistent homology reasoner.
        
        Args:
            spiral_engine: SpiralLLM-Math engine to register with
        """
        self.spiral_engine = spiral_engine
        if spiral_engine:
            spiral_engine.register_reasoner('persistence', self.solve_persistence)
            spiral_engine.register_reasoner('persistence_diagram', self.solve_persistence_diagram)
            spiral_engine.register_reasoner('barcode', self.solve_barcode)
            spiral_engine.register_reasoner('bottleneck', self.solve_bottleneck)
            spiral_engine.register_verifier('persistence', self.verify_persistence)

    def solve_persistence(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Solve a general persistence problem.
        
        Args:
            problem: Problem with persistence-related data
            
        Returns:
            Solution data
        """
        operation = problem.input_data.get('operation', 'compute')
        
        if operation == 'compute_diagram':
            return self._compute_persistence_diagram(problem)
        elif operation == 'analyze_features':
            return self._analyze_persistent_features(problem)
        elif operation == 'compare_diagrams':
            return self._compare_diagrams(problem)
        elif operation == 'stability':
            return self._analyze_stability(problem)
        else:
            return {'error': f'Unknown operation: {operation}'}

    def solve_persistence_diagram(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Compute and analyze persistence diagram.
        
        Args:
            problem: Problem with filtration data
            
        Returns:
            Persistence diagram and analysis
        """
        filtration = problem.input_data.get('filtration')
        max_dimension = problem.input_data.get('max_dimension', 2)
        
        if not isinstance(filtration, ChiralFiltration):
            return {'error': 'Invalid filtration provided'}
        
        # Compute persistence diagram
        diagram = filtration.compute_persistence(max_dimension)
        
        # Analyze diagram
        analysis = self._analyze_diagram(diagram)
        
        # Extract features
        essential_features = diagram.essential_features()
        
        # Betti numbers over time
        filt_values = filtration.get_filtration_values()
        betti_evolution = {
            fv: diagram.betti_numbers_at(fv) 
            for fv in filt_values[:min(10, len(filt_values))]
        }
        
        return {
            'diagram': diagram,
            'n_pairs': len(diagram),
            'dimension_breakdown': analysis['dimension_counts'],
            'essential_features': essential_features,
            'n_essential': len(essential_features),
            'max_persistence': analysis['max_persistence'],
            'mean_persistence': analysis['mean_persistence'],
            'chirality_distribution': analysis['chirality_distribution'],
            'betti_evolution': betti_evolution,
            'explanation': self._explain_diagram(diagram, analysis)
        }

    def _analyze_diagram(self, diagram: PersistenceDiagram) -> Dict[str, Any]:
        """Analyze a persistence diagram comprehensively."""
        # Count by dimension
        dimension_counts = {}
        for pair in diagram.pairs:
            dimension_counts[pair.dimension] = dimension_counts.get(pair.dimension, 0) + 1
        
        # Persistence statistics (excluding essential features)
        finite_pairs = [p for p in diagram.pairs if not p.is_essential]
        if finite_pairs:
            persistences = [p.persistence for p in finite_pairs]
            max_pers = max(persistences)
            mean_pers = np.mean(persistences)
            median_pers = np.median(persistences)
        else:
            max_pers = mean_pers = median_pers = 0.0
        
        # Chirality distribution
        chirality_counts = {}
        for pair in diagram.pairs:
            chirality_counts[pair.chirality] = chirality_counts.get(pair.chirality, 0) + 1
        
        return {
            'dimension_counts': dimension_counts,
            'max_persistence': max_pers,
            'mean_persistence': mean_pers,
            'median_persistence': median_pers,
            'chirality_distribution': chirality_counts,
            'n_essential': len([p for p in diagram.pairs if p.is_essential])
        }

    def _explain_diagram(self, diagram: PersistenceDiagram, analysis: Dict) -> str:
        """Generate natural language explanation of persistence diagram."""
        explanation_parts = []
        
        explanation_parts.append(f"Persistence diagram contains {len(diagram)} topological features:")
        
        # Dimension breakdown
        dim_counts = analysis['dimension_counts']
        for dim in sorted(dim_counts.keys()):
            count = dim_counts[dim]
            dim_name = {0: "components", 1: "loops", 2: "voids"}.get(dim, f"{dim}-dim features")
            explanation_parts.append(f"  - {count} {dim_name} (H_{dim})")
        
        # Essential features
        n_essential = analysis['n_essential']
        if n_essential > 0:
            explanation_parts.append(f"\n{n_essential} essential features (never die) indicate global topology.")
        
        # Persistence
        if analysis['max_persistence'] > 0:
            explanation_parts.append(
                f"\nMaximum persistence: {analysis['max_persistence']:.4f} "
                f"(mean: {analysis['mean_persistence']:.4f})"
            )
            explanation_parts.append(
                "High persistence indicates robust topological features.")
        
        # Chirality
        chir_dist = analysis['chirality_distribution']
        if len(chir_dist) > 1:
            explanation_parts.append(f"\nChirality distribution: {chir_dist}")
        
        return "\n".join(explanation_parts)

    def solve_barcode(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Analyze persistence barcode.
        
        Args:
            problem: Problem with diagram data
            
        Returns:
            Barcode analysis
        """
        diagram = problem.input_data.get('diagram')
        dimension = problem.input_data.get('dimension', None)
        
        if not isinstance(diagram, PersistenceDiagram):
            return {'error': 'Invalid diagram provided'}
        
        # Create barcode
        barcode = PersistenceBarcode(diagram)
        
        # Get bars
        bars = barcode.get_bars(dimension)
        
        # Analyze barcode
        max_pers = barcode.max_persistence(dimension)
        max_death = barcode.max_death(dimension)
        
        # Sort bars by persistence
        sorted_bars = sorted(bars, key=lambda x: x[2].persistence, reverse=True)
        top_features = sorted_bars[:5]
        
        return {
            'barcode': barcode,
            'n_bars': len(bars),
            'max_persistence': max_pers,
            'max_death': max_death,
            'top_features': [(b, d, p.dimension, p.persistence) for b, d, p in top_features],
            'explanation': self._explain_barcode(barcode, bars, dimension)
        }

    def _explain_barcode(self, barcode: PersistenceBarcode, bars: List, dimension: Optional[int]) -> str:
        """Generate natural language explanation of barcode."""
        explanation_parts = []
        
        dim_str = f"dimension {dimension}" if dimension is not None else "all dimensions"
        explanation_parts.append(f"Barcode for {dim_str} contains {len(bars)} intervals.")
        
        if bars:
            # Longest bars
            sorted_bars = sorted(bars, key=lambda x: x[2].persistence, reverse=True)
            explanation_parts.append(f"\nTop persistent features:")
            for i, (birth, death, pair) in enumerate(sorted_bars[:3]):
                death_str = "∞" if pair.is_essential else f"{death:.4f}"
                explanation_parts.append(
                    f"  {i+1}. [{birth:.4f}, {death_str}): "
                    f"persistence = {pair.persistence:.4f}, dim = {pair.dimension}"
                )
        
        return "\n".join(explanation_parts)

    def solve_bottleneck(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Compute bottleneck distance between diagrams.
        
        Args:
            problem: Problem with two diagrams
            
        Returns:
            Distance and matching analysis
        """
        dgm1 = problem.input_data.get('diagram1')
        dgm2 = problem.input_data.get('diagram2')
        dimension = problem.input_data.get('dimension', None)
        
        if not isinstance(dgm1, PersistenceDiagram) or not isinstance(dgm2, PersistenceDiagram):
            return {'error': 'Invalid diagrams provided'}
        
        # Compute bottleneck distance
        distance = bottleneck_distance(dgm1, dgm2, dimension)
        
        # Also compute Wasserstein distance
        wasserstein = wasserstein_distance_diagrams(dgm1, dgm2, p=2.0, dimension=dimension)
        
        # Analyze similarity
        similarity = self._analyze_diagram_similarity(dgm1, dgm2, dimension)
        
        return {
            'bottleneck_distance': distance,
            'wasserstein_distance': wasserstein,
            'diagram1_size': len(dgm1.filter_by_dimension(dimension) if dimension is not None else dgm1),
            'diagram2_size': len(dgm2.filter_by_dimension(dimension) if dimension is not None else dgm2),
            'similarity_score': similarity['score'],
            'common_features': similarity['common_features'],
            'explanation': self._explain_distance(distance, wasserstein, similarity)
        }

    def _analyze_diagram_similarity(self, dgm1: PersistenceDiagram, dgm2: PersistenceDiagram,
                                   dimension: Optional[int]) -> Dict[str, Any]:
        """Analyze similarity between two diagrams."""
        if dimension is not None:
            dgm1 = dgm1.filter_by_dimension(dimension)
            dgm2 = dgm2.filter_by_dimension(dimension)
        
        # Count common features (rough estimate)
        n1, n2 = len(dgm1), len(dgm2)
        common_features = min(n1, n2)
        
        # Similarity score (inverse of normalized distance)
        max_pers1 = max([p.persistence for p in dgm1.pairs if not p.is_essential] or [1.0])
        max_pers2 = max([p.persistence for p in dgm2.pairs if not p.is_essential] or [1.0])
        normalization = max(max_pers1, max_pers2)
        
        # Rough similarity
        similarity_score = max(0.0, 1.0 - abs(n1 - n2) / (max(n1, n2) + 1))
        
        return {
            'score': similarity_score,
            'common_features': common_features
        }

    def _explain_distance(self, bottleneck: float, wasserstein: float, similarity: Dict) -> str:
        """Explain distance between diagrams."""
        explanation_parts = []
        
        explanation_parts.append(f"Bottleneck distance: {bottleneck:.6f}")
        explanation_parts.append(f"Wasserstein distance: {wasserstein:.6f}")
        
        if bottleneck < 0.01:
            explanation_parts.append("\nDiagrams are very similar (near-identical topology).")
        elif bottleneck < 0.1:
            explanation_parts.append("\nDiagrams are similar (small topological differences).")
        elif bottleneck < 0.5:
            explanation_parts.append("\nDiagrams show moderate topological differences.")
        else:
            explanation_parts.append("\nDiagrams show significant topological differences.")
        
        explanation_parts.append(f"Similarity score: {similarity['score']:.4f}")
        
        return "\n".join(explanation_parts)

    def _compute_persistence_diagram(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Compute persistence diagram from filtration."""
        return self.solve_persistence_diagram(problem)

    def _analyze_persistent_features(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Analyze persistent features in diagram."""
        diagram = problem.input_data.get('diagram')
        min_persistence = problem.input_data.get('min_persistence', 0.0)
        
        if not isinstance(diagram, PersistenceDiagram):
            return {'error': 'Invalid diagram provided'}
        
        # Filter by persistence
        significant_diagram = diagram.filter_by_persistence(min_persistence)
        
        # Analyze by dimension
        features_by_dim = {}
        for dim in range(3):
            dim_features = significant_diagram.filter_by_dimension(dim)
            if len(dim_features) > 0:
                features_by_dim[dim] = {
                    'count': len(dim_features),
                    'max_persistence': max(p.persistence for p in dim_features.pairs),
                    'mean_persistence': np.mean([p.persistence for p in dim_features.pairs])
                }
        
        return {
            'total_features': len(diagram),
            'significant_features': len(significant_diagram),
            'min_persistence_threshold': min_persistence,
            'features_by_dimension': features_by_dim,
            'essential_features': len(diagram.essential_features())
        }

    def _compare_diagrams(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Compare multiple diagrams."""
        return self.solve_bottleneck(problem)

    def _analyze_stability(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Analyze stability of persistence under perturbations."""
        filtration = problem.input_data.get('filtration')
        epsilon = problem.input_data.get('epsilon', 0.01)
        max_dimension = problem.input_data.get('max_dimension', 2)
        
        if not isinstance(filtration, ChiralFiltration):
            return {'error': 'Invalid filtration provided'}
        
        # Compute stability constant
        const = stability_constant(filtration, epsilon, max_dimension)
        
        return {
            'stability_constant': const,
            'epsilon': epsilon,
            'max_dimension': max_dimension,
            'is_stable': const < 10.0,  # Arbitrary threshold
            'explanation': f"Stability constant {const:.4f} with perturbation ε={epsilon:.4f}. "
                         f"{'Stable' if const < 10.0 else 'Potentially unstable'} under small changes."
        }

    def verify_persistence(self, solution: Solution) -> Dict[str, Any]:
        """Verify persistence computation results.
        
        Args:
            solution: Solution to verify
            
        Returns:
            Verification results
        """
        result = solution.result
        
        checks = {
            'has_diagram': 'diagram' in result,
            'valid_pairs': False,
            'birth_death_ordered': False,
            'persistence_nonnegative': False
        }
        
        if 'diagram' in result:
            diagram = result['diagram']
            if isinstance(diagram, PersistenceDiagram):
                checks['valid_pairs'] = True
                
                # Check birth < death for all non-essential pairs
                all_ordered = all(
                    p.is_essential or p.birth < p.death 
                    for p in diagram.pairs
                )
                checks['birth_death_ordered'] = all_ordered
                
                # Check non-negative persistence
                all_positive = all(p.persistence >= 0 for p in diagram.pairs)
                checks['persistence_nonnegative'] = all_positive
        
        all_passed = all(checks.values())
        
        return {
            'valid': all_passed,
            'checks': checks,
            'message': 'Persistence verification passed' if all_passed else 'Persistence verification failed'
        }
