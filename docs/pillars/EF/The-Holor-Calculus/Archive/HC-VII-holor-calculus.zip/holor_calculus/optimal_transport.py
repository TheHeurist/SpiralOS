"""
§8 - Chiral Optimal Transport

Optimal transport theory on chiral spaces:
- Wasserstein distances with chirality constraints
- Optimal couplings respecting chirality
- Barycenters in Wasserstein space
- Displacement interpolation
- Connection to information geometry
"""

from typing import List, Optional, Callable, Tuple
from dataclasses import dataclass
import numpy as np
from scipy.optimize import linear_sum_assignment
from scipy.spatial.distance import cdist

from .chiral_base import ChiralObject, Chirality


@dataclass
class ChiralMeasure:
    """
    Discrete probability measure on chiral space.
    
    Represents a weighted collection of chiral objects:
    μ = Σ w_i δ_{x_i} where w_i are weights and x_i are support points.
    """
    support: List[ChiralObject]  # Support points
    weights: np.ndarray  # Probability weights (sum to 1)
    
    def __post_init__(self):
        """Validate measure properties"""
        if len(self.support) != len(self.weights):
            raise ValueError("Support and weights must have same length")
        
        if not np.isclose(self.weights.sum(), 1.0):
            raise ValueError(f"Weights must sum to 1, got {self.weights.sum()}")
        
        if np.any(self.weights < 0):
            raise ValueError("Weights must be non-negative")
    
    @property
    def n_support(self) -> int:
        """Number of support points"""
        return len(self.support)
    
    def mean_chirality(self) -> Chirality:
        """Compute weighted mean chirality (discrete)"""
        # Count chirality-weighted
        chiral_value = sum(w * obj.chirality.value for w, obj in zip(self.weights, self.support))
        
        if chiral_value < -0.3:
            return Chirality.LEFT
        elif chiral_value > 0.3:
            return Chirality.RIGHT
        else:
            return Chirality.NEUTRAL
    
    def push_forward(self, map_func: Callable[[ChiralObject], ChiralObject]) -> 'ChiralMeasure':
        """
        Push-forward measure through a map: (T_# μ)(A) = μ(T^{-1}(A))
        
        Args:
            map_func: Map T: ChiralSpace → ChiralSpace
            
        Returns:
            Pushed-forward measure
        """
        new_support = [map_func(obj) for obj in self.support]
        return ChiralMeasure(new_support, self.weights.copy())
    
    def barycenter_location(self) -> np.ndarray:
        """Compute Euclidean barycenter of support (ignoring chirality temporarily)"""
        data_matrix = np.array([obj.data for obj in self.support])
        return np.average(data_matrix, axis=0, weights=self.weights)


@dataclass
class ChiralCoupling:
    """
    Transport plan (coupling) between two chiral measures.
    
    A coupling π ∈ Π(μ, ν) is a joint measure with marginals μ and ν.
    """
    source: ChiralMeasure
    target: ChiralMeasure
    plan: np.ndarray  # Coupling matrix π[i,j] = probability of coupling source[i] to target[j]
    
    def __post_init__(self):
        """Validate coupling properties"""
        n_source = self.source.n_support
        n_target = self.target.n_support
        
        if self.plan.shape != (n_source, n_target):
            raise ValueError(f"Plan shape {self.plan.shape} doesn't match source/target sizes ({n_source}, {n_target})")
        
        # Check marginal constraints (up to numerical precision)
        source_marginal = self.plan.sum(axis=1)
        target_marginal = self.plan.sum(axis=0)
        
        if not np.allclose(source_marginal, self.source.weights):
            raise ValueError("Source marginal constraint violated")
        
        if not np.allclose(target_marginal, self.target.weights):
            raise ValueError("Target marginal constraint violated")
        
        if np.any(self.plan < 0):
            raise ValueError("Coupling plan must be non-negative")
    
    def transport_cost(self, cost_matrix: np.ndarray) -> float:
        """
        Compute total transport cost: ∫∫ c(x,y) dπ(x,y)
        
        Args:
            cost_matrix: Cost c(x_i, y_j) for transporting from source[i] to target[j]
            
        Returns:
            Total cost
        """
        return np.sum(self.plan * cost_matrix)
    
    def is_deterministic(self, tol: float = 1e-6) -> bool:
        """
        Check if coupling is deterministic (Monge transport).
        
        A deterministic coupling has at most one non-zero entry per row.
        """
        for i in range(self.plan.shape[0]):
            non_zeros = np.sum(self.plan[i] > tol)
            if non_zeros > 1:
                return False
        return True


class WassersteinDistance:
    """
    Wasserstein distance (optimal transport distance) on chiral spaces.
    
    W_p(μ, ν) = (inf_{π ∈ Π(μ,ν)} ∫∫ d(x,y)^p dπ(x,y))^{1/p}
    """
    
    def __init__(self, p: float = 2.0, chirality_penalty: float = 1.0):
        """
        Initialize Wasserstein distance.
        
        Args:
            p: Order of Wasserstein distance (typically 1 or 2)
            chirality_penalty: Additional cost for chirality mismatch
        """
        self.p = p
        self.chirality_penalty = chirality_penalty
    
    def compute_cost_matrix(self, source: ChiralMeasure, target: ChiralMeasure) -> np.ndarray:
        """
        Compute pairwise cost matrix with chirality penalties.
        
        c(x_i, y_j) = d(x_i, y_j)^p + penalty * I[chirality mismatch]
        
        Args:
            source: Source measure
            target: Target measure
            
        Returns:
            Cost matrix of shape (n_source, n_target)
        """
        n_source = source.n_support
        n_target = target.n_support
        
        cost = np.zeros((n_source, n_target))
        
        for i, obj_i in enumerate(source.support):
            for j, obj_j in enumerate(target.support):
                # Base distance
                base_dist = np.linalg.norm(obj_i.data - obj_j.data)
                
                # Chirality penalty
                chiral_cost = 0.0
                if obj_i.chirality != obj_j.chirality:
                    chiral_cost = self.chirality_penalty
                
                # Total cost raised to power p
                cost[i, j] = base_dist ** self.p + chiral_cost
        
        return cost
    
    def compute_optimal_coupling(self, source: ChiralMeasure, target: ChiralMeasure) -> ChiralCoupling:
        """
        Compute optimal coupling using linear programming.
        
        For discrete measures, this is a linear assignment problem.
        We use scipy's linear_sum_assignment for balanced case.
        
        Args:
            source: Source measure μ
            target: Target measure ν
            
        Returns:
            Optimal coupling π*
        """
        cost_matrix = self.compute_cost_matrix(source, target)
        
        # For equal weights, use Hungarian algorithm
        if source.n_support == target.n_support and np.allclose(source.weights, target.weights):
            row_ind, col_ind = linear_sum_assignment(cost_matrix)
            
            # Create deterministic coupling
            plan = np.zeros((source.n_support, target.n_support))
            for i, j in zip(row_ind, col_ind):
                plan[i, j] = source.weights[i]
            
            return ChiralCoupling(source, target, plan)
        
        else:
            # For unequal weights, use entropic regularization (Sinkhorn algorithm)
            plan = self._sinkhorn_coupling(source, target, cost_matrix)
            return ChiralCoupling(source, target, plan)
    
    def _sinkhorn_coupling(self, source: ChiralMeasure, target: ChiralMeasure, 
                          cost_matrix: np.ndarray, epsilon: float = 0.1, 
                          max_iter: int = 100) -> np.ndarray:
        """
        Compute coupling using Sinkhorn algorithm (entropic regularization).
        
        Solves: min_π <C, π> + ε KL(π | μ ⊗ ν)
        
        Args:
            source: Source measure
            target: Target measure
            cost_matrix: Cost matrix
            epsilon: Regularization parameter
            max_iter: Maximum iterations
            
        Returns:
            Coupling matrix
        """
        # Kernel matrix
        K = np.exp(-cost_matrix / epsilon)
        
        # Initialize
        u = np.ones(source.n_support) / source.n_support
        v = np.ones(target.n_support) / target.n_support
        
        # Sinkhorn iterations
        for _ in range(max_iter):
            u = source.weights / (K @ v)
            v = target.weights / (K.T @ u)
        
        # Compute coupling
        plan = np.diag(u) @ K @ np.diag(v)
        
        return plan
    
    def distance(self, source: ChiralMeasure, target: ChiralMeasure) -> float:
        """
        Compute p-Wasserstein distance.
        
        Args:
            source: Source measure μ
            target: Target measure ν
            
        Returns:
            W_p(μ, ν)
        """
        coupling = self.compute_optimal_coupling(source, target)
        cost_matrix = self.compute_cost_matrix(source, target)
        total_cost = coupling.transport_cost(cost_matrix)
        
        return total_cost ** (1.0 / self.p)
    
    def __call__(self, source: ChiralMeasure, target: ChiralMeasure) -> float:
        """Convenience method for computing distance"""
        return self.distance(source, target)


class ChiralBarycenter:
    """
    Wasserstein barycenter of multiple chiral measures.
    
    The barycenter μ* minimizes: Σ λ_i W_p^p(μ*, μ_i)
    where λ_i are weights.
    """
    
    def __init__(self, measures: List[ChiralMeasure], weights: Optional[np.ndarray] = None,
                 p: float = 2.0):
        """
        Initialize barycenter computation.
        
        Args:
            measures: List of measures μ_1, ..., μ_n
            weights: Barycentric weights λ_i (default: uniform)
            p: Wasserstein distance order
        """
        self.measures = measures
        
        if weights is None:
            self.weights = np.ones(len(measures)) / len(measures)
        else:
            if not np.isclose(weights.sum(), 1.0):
                raise ValueError("Barycentric weights must sum to 1")
            self.weights = weights
        
        self.p = p
        self.wasserstein = WassersteinDistance(p)
    
    def compute_support_barycenter(self, n_support: int) -> List[np.ndarray]:
        """
        Compute barycentric support points (Euclidean approximation).
        
        Args:
            n_support: Number of support points for barycenter
            
        Returns:
            List of support point locations
        """
        # Simple approach: take weighted average of all support points
        all_points = []
        all_weights = []
        
        for measure, lambda_i in zip(self.measures, self.weights):
            for point, weight in zip(measure.support, measure.weights):
                all_points.append(point.data)
                all_weights.append(lambda_i * weight)
        
        all_points = np.array(all_points)
        all_weights = np.array(all_weights)
        all_weights /= all_weights.sum()
        
        # Use k-means-like approach to find n_support representative points
        # For simplicity, use weighted sampling
        rng = np.random.RandomState(42)
        indices = rng.choice(len(all_points), size=n_support, replace=False, p=all_weights)
        
        return [all_points[i] for i in indices]
    
    def compute_barycenter(self, n_support: int, max_iter: int = 50) -> ChiralMeasure:
        """
        Compute Wasserstein barycenter using fixed-point algorithm.
        
        Args:
            n_support: Number of support points for barycenter
            max_iter: Maximum iterations
            
        Returns:
            Barycenter measure μ*
        """
        # Initialize barycenter support
        support_locations = self.compute_support_barycenter(n_support)
        
        # Determine chirality via majority vote
        all_chiralities = []
        for measure, lambda_i in zip(self.measures, self.weights):
            for obj in measure.support:
                all_chiralities.extend([obj.chirality] * int(lambda_i * 100))
        
        from collections import Counter
        majority_chirality = Counter(all_chiralities).most_common(1)[0][0]
        
        # Create initial barycenter
        support = [ChiralObject(loc, majority_chirality) for loc in support_locations]
        barycenter_weights = np.ones(n_support) / n_support
        
        # Fixed-point iteration (simplified)
        for iteration in range(max_iter):
            # For each support point, update based on optimal transports
            # This is a simplified version; full algorithm is more complex
            pass
        
        return ChiralMeasure(support, barycenter_weights)


class DisplacementInterpolation:
    """
    Geodesic interpolation in Wasserstein space.
    
    Given optimal coupling π* between μ and ν, the displacement interpolation is:
    μ_t = ((1-t)X + tY)_# π*
    where (X,Y) ~ π*.
    """
    
    def __init__(self, source: ChiralMeasure, target: ChiralMeasure, 
                 coupling: Optional[ChiralCoupling] = None):
        """
        Initialize displacement interpolation.
        
        Args:
            source: Source measure μ
            target: Target measure ν
            coupling: Optimal coupling (computed if not provided)
        """
        self.source = source
        self.target = target
        
        if coupling is None:
            wasserstein = WassersteinDistance(p=2.0)
            self.coupling = wasserstein.compute_optimal_coupling(source, target)
        else:
            self.coupling = coupling
    
    def interpolate(self, t: float) -> ChiralMeasure:
        """
        Compute interpolated measure at time t ∈ [0, 1].
        
        Args:
            t: Interpolation parameter (0 = source, 1 = target)
            
        Returns:
            Interpolated measure μ_t
        """
        if not 0 <= t <= 1:
            raise ValueError(f"Interpolation parameter must be in [0, 1], got {t}")
        
        # Build interpolated support
        interpolated_support = []
        interpolated_weights = []
        
        for i, obj_source in enumerate(self.source.support):
            for j, obj_target in enumerate(self.target.support):
                coupling_weight = self.coupling.plan[i, j]
                
                if coupling_weight > 1e-10:
                    # Interpolate data
                    interp_data = (1 - t) * obj_source.data + t * obj_target.data
                    
                    # Interpolate chirality (discrete transition)
                    if t < 0.5:
                        interp_chirality = obj_source.chirality
                    else:
                        interp_chirality = obj_target.chirality
                    
                    interpolated_support.append(ChiralObject(interp_data, interp_chirality))
                    interpolated_weights.append(coupling_weight)
        
        interpolated_weights = np.array(interpolated_weights)
        interpolated_weights /= interpolated_weights.sum()
        
        return ChiralMeasure(interpolated_support, interpolated_weights)
    
    def __call__(self, t: float) -> ChiralMeasure:
        """Convenience method"""
        return self.interpolate(t)


class OptimalTransportMap:
    """
    Monge map T: X → Y for optimal transport.
    
    When it exists, the Monge map T minimizes ∫ c(x, T(x)) dμ(x)
    subject to T_# μ = ν.
    """
    
    def __init__(self, coupling: ChiralCoupling):
        """
        Initialize from optimal coupling.
        
        Args:
            coupling: Optimal coupling (should be deterministic for Monge map)
        """
        self.coupling = coupling
        
        if not coupling.is_deterministic():
            raise ValueError("Monge map only exists for deterministic couplings")
        
        # Build map
        self._build_map()
    
    def _build_map(self):
        """Build map from coupling"""
        self.map_indices = {}
        
        for i in range(self.coupling.source.n_support):
            # Find target index
            j = np.argmax(self.coupling.plan[i, :])
            self.map_indices[i] = j
    
    def __call__(self, obj: ChiralObject) -> ChiralObject:
        """
        Apply transport map to object.
        
        Args:
            obj: Source object
            
        Returns:
            Transported object
        """
        # Find closest source support point
        distances = [np.linalg.norm(obj.data - src.data) 
                    for src in self.coupling.source.support]
        i = np.argmin(distances)
        
        # Return corresponding target
        j = self.map_indices[i]
        return self.coupling.target.support[j]


def create_uniform_measure(objects: List[ChiralObject]) -> ChiralMeasure:
    """
    Create uniform measure on given support.
    
    Args:
        objects: Support points
        
    Returns:
        Uniform measure μ = (1/n) Σ δ_{x_i}
    """
    n = len(objects)
    weights = np.ones(n) / n
    return ChiralMeasure(objects, weights)


def create_weighted_measure(objects: List[ChiralObject], weights: np.ndarray) -> ChiralMeasure:
    """
    Create weighted measure on given support.
    
    Args:
        objects: Support points
        weights: Probability weights
        
    Returns:
        Weighted measure
    """
    return ChiralMeasure(objects, weights)


def compute_wasserstein_geodesic(source: ChiralMeasure, target: ChiralMeasure, 
                                 n_points: int = 10) -> List[ChiralMeasure]:
    """
    Compute Wasserstein geodesic between two measures.
    
    Args:
        source: Starting measure
        target: Ending measure
        n_points: Number of interpolation points
        
    Returns:
        List of measures along geodesic
    """
    interpolator = DisplacementInterpolation(source, target)
    
    geodesic = []
    for i in range(n_points):
        t = i / (n_points - 1)
        geodesic.append(interpolator(t))
    
    return geodesic
