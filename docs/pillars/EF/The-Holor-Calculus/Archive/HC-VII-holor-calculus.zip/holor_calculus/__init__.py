"""Holor Calculus VII - Advanced Chiral Mathematics.

Fifth Cycle: §9 Persistent Homology, §10 Spectral Geometry
with SpiralLLM-Math Integration
"""

from .chiral_base import ChiralObject, Chirality
from .homotopy import ChiralPath, ChiralHomotopy, ProofDeformation, FundamentalGroup, compute_winding_number
from .info_geometry import FisherMetric, ChiralDivergence, GeometricStatistics, ChiralExponentialFamily, create_gaussian_exponential_family
from .homology import (
    ChiralSimplex, ChiralChain, ChiralChainComplex, ChiralHomologyGroup,
    ChiralSimplicialComplex, SimplexOrientation,
    create_standard_simplex, create_boundary_of_simplex, compute_reduced_homology
)
from .optimal_transport import (
    ChiralMeasure, ChiralCoupling, WassersteinDistance, ChiralBarycenter,
    DisplacementInterpolation, OptimalTransportMap,
    create_uniform_measure, create_weighted_measure, compute_wasserstein_geodesic
)
from .persistent_homology import (
    PersistencePair, PersistenceDiagram, PersistenceBarcode, ChiralFiltration,
    bottleneck_distance, wasserstein_distance_diagrams, vietoris_rips_filtration, stability_constant
)
from .spectral_geometry import (
    LaplacianSpectrum, ChiralGraphLaplacian, HodgeDecomposition, ChiralDiffusion,
    compute_cheeger_constant, compute_graph_energy, compute_estrada_index, spectral_distance
)

# SpiralLLM-Math Integration
from .spiral_llm_math import SpiralLLMMath, MathematicalProblem, Solution, ReasoningMode, SpiralStage, ReasoningStep
from .spiral_homotopy_reasoner import HomotopyReasoner
from .spiral_info_geometry_reasoner import InfoGeometryReasoner
from .spiral_homology_reasoner import HomologyReasoner
from .spiral_optimal_transport_reasoner import OptimalTransportReasoner
from .spiral_persistent_homology_reasoner import PersistentHomologyReasoner
from .spiral_spectral_geometry_reasoner import SpectralGeometryReasoner
from .spiral_problem_solver import SpiralProblemSolver
from .spiral_verification import SpiralVerifier, QualityAssessor, VerificationResult

__version__ = "0.6.0"
__all__ = [
    # Core chiral mathematics
    "ChiralObject", "Chirality",
    "ChiralPath", "ChiralHomotopy", "ProofDeformation", "FundamentalGroup", "compute_winding_number",
    "FisherMetric", "ChiralDivergence", "GeometricStatistics", "ChiralExponentialFamily", "create_gaussian_exponential_family",
    # §7 Homology
    "ChiralSimplex", "ChiralChain", "ChiralChainComplex", "ChiralHomologyGroup",
    "ChiralSimplicialComplex", "SimplexOrientation",
    "create_standard_simplex", "create_boundary_of_simplex", "compute_reduced_homology",
    # §8 Optimal Transport
    "ChiralMeasure", "ChiralCoupling", "WassersteinDistance", "ChiralBarycenter",
    "DisplacementInterpolation", "OptimalTransportMap",
    "create_uniform_measure", "create_weighted_measure", "compute_wasserstein_geodesic",
    # §9 Persistent Homology
    "PersistencePair", "PersistenceDiagram", "PersistenceBarcode", "ChiralFiltration",
    "bottleneck_distance", "wasserstein_distance_diagrams", "vietoris_rips_filtration", "stability_constant",
    # §10 Spectral Geometry
    "LaplacianSpectrum", "ChiralGraphLaplacian", "HodgeDecomposition", "ChiralDiffusion",
    "compute_cheeger_constant", "compute_graph_energy", "compute_estrada_index", "spectral_distance",
    # SpiralLLM-Math reasoning system
    "SpiralLLMMath", "MathematicalProblem", "Solution", "ReasoningMode", "SpiralStage", "ReasoningStep",
    "HomotopyReasoner", "InfoGeometryReasoner", "HomologyReasoner", "OptimalTransportReasoner",
    "PersistentHomologyReasoner", "SpectralGeometryReasoner",
    "SpiralProblemSolver",
    "SpiralVerifier", "QualityAssessor", "VerificationResult",
]
