"""§5 - Homotopy of Chiral Proofs.

Implements homotopy theory for chiral proof structures:
- Path equivalences in chiral spaces
- Higher homotopies
- Proof deformation theory
"""

import numpy as np
from dataclasses import dataclass, field
from typing import Optional, List, Callable, Tuple, Union
from abc import ABC, abstractmethod
from .chiral_base import ChiralObject, Chirality, ChiralSpace


@dataclass
class ChiralPath:
    """A path in chiral space.
    
    Represents a continuous deformation between chiral objects.
    """
    start: ChiralObject
    end: ChiralObject
    interpolation: Callable[[float], ChiralObject] = field(default=None)
    
    def __post_init__(self):
        if self.interpolation is None:
            self.interpolation = self._linear_interpolation
    
    def _linear_interpolation(self, t: float) -> ChiralObject:
        """Default linear interpolation."""
        t = np.clip(t, 0.0, 1.0)
        data = (1 - t) * self.start.data + t * self.end.data
        # Chirality transitions at midpoint
        if t < 0.5:
            chirality = self.start.chirality
        elif t > 0.5:
            chirality = self.end.chirality
        else:
            chirality = Chirality.NEUTRAL
        return ChiralObject(data, chirality)
    
    def __call__(self, t: float) -> ChiralObject:
        """Evaluate path at parameter t in [0,1]."""
        return self.interpolation(t)
    
    def length(self, n_samples: int = 100) -> float:
        """Approximate path length."""
        ts = np.linspace(0, 1, n_samples)
        total = 0.0
        for i in range(len(ts) - 1):
            p1 = self(ts[i])
            p2 = self(ts[i+1])
            total += p1.distance(p2)
        return total
    
    def reverse(self) -> 'ChiralPath':
        """Return reversed path."""
        return ChiralPath(
            start=self.end,
            end=self.start,
            interpolation=lambda t: self(1 - t)
        )
    
    def compose(self, other: 'ChiralPath') -> 'ChiralPath':
        """Compose with another path (this followed by other)."""
        if self.end.distance(other.start) > 1e-6:
            raise ValueError("Paths not composable: end != start")
        
        def composed_interp(t: float) -> ChiralObject:
            if t < 0.5:
                return self(2 * t)
            else:
                return other(2 * t - 1)
        
        return ChiralPath(self.start, other.end, composed_interp)
    
    def is_loop(self, tolerance: float = 1e-6) -> bool:
        """Check if path is a loop."""
        return self.start.distance(self.end) < tolerance
    
    def chirality_preserved(self) -> bool:
        """Check if chirality is preserved along path."""
        return self.start.chirality == self.end.chirality


@dataclass  
class ChiralHomotopy:
    """Homotopy between chiral paths.
    
    A 2-parameter family H(s,t) where:
    - H(0,t) = path0(t)
    - H(1,t) = path1(t)
    - H(s,0) = common start
    - H(s,1) = common end
    """
    path0: ChiralPath
    path1: ChiralPath
    homotopy_map: Callable[[float, float], ChiralObject] = field(default=None)
    
    def __post_init__(self):
        # Verify endpoints match
        if self.path0.start.distance(self.path1.start) > 1e-6:
            raise ValueError("Paths must have same start point")
        if self.path0.end.distance(self.path1.end) > 1e-6:
            raise ValueError("Paths must have same end point")
        
        if self.homotopy_map is None:
            self.homotopy_map = self._linear_homotopy
    
    def _linear_homotopy(self, s: float, t: float) -> ChiralObject:
        """Linear homotopy (straight-line in path space)."""
        p0 = self.path0(t)
        p1 = self.path1(t)
        data = (1 - s) * p0.data + s * p1.data
        
        # Determine chirality
        if s < 0.5:
            chirality = p0.chirality
        elif s > 0.5:
            chirality = p1.chirality
        else:
            chirality = Chirality.NEUTRAL
        
        return ChiralObject(data, chirality)
    
    def __call__(self, s: float, t: float) -> ChiralObject:
        """Evaluate homotopy at (s,t) in [0,1]x[0,1]."""
        return self.homotopy_map(s, t)
    
    def path_at(self, s: float) -> ChiralPath:
        """Get intermediate path at homotopy parameter s."""
        return ChiralPath(
            start=self(s, 0),
            end=self(s, 1),
            interpolation=lambda t: self(s, t)
        )
    
    def is_identity(self, tolerance: float = 1e-6, n_samples: int = 10) -> bool:
        """Check if this is an identity homotopy (path0 == path1)."""
        for t in np.linspace(0, 1, n_samples):
            if self.path0(t).distance(self.path1(t)) > tolerance:
                return False
        return True
    
    def chirality_class(self) -> str:
        """Classify homotopy by chirality behavior."""
        c0 = self.path0.chirality_preserved()
        c1 = self.path1.chirality_preserved()
        if c0 and c1:
            return "chiral_preserving"
        elif not c0 and not c1:
            return "chiral_mixing"
        else:
            return "chiral_transitional"


@dataclass
class HigherHomotopy:
    """Higher homotopy (homotopy between homotopies).
    
    Represents n-dimensional continuous deformations.
    """
    level: int  # 1 = path, 2 = homotopy, 3 = higher, etc.
    base_space: ChiralSpace
    map_function: Callable[..., ChiralObject]
    
    def __call__(self, *params: float) -> ChiralObject:
        """Evaluate higher homotopy at given parameters."""
        if len(params) != self.level:
            raise ValueError(f"Expected {self.level} parameters, got {len(params)}")
        return self.map_function(*params)
    
    def boundary(self, index: int, value: float) -> 'HigherHomotopy':
        """Get boundary by fixing one parameter."""
        if index < 0 or index >= self.level:
            raise IndexError(f"Index {index} out of range for level {self.level}")
        
        def fixed_map(*params: float) -> ChiralObject:
            full_params = list(params)
            full_params.insert(index, value)
            return self.map_function(*full_params)
        
        return HigherHomotopy(
            level=self.level - 1,
            base_space=self.base_space,
            map_function=fixed_map
        )
    
    @classmethod
    def from_paths(cls, paths: List[ChiralPath], base_space: ChiralSpace) -> 'HigherHomotopy':
        """Create level-1 higher homotopy from paths."""
        def path_map(t: float) -> ChiralObject:
            # Use first path
            return paths[0](t)
        
        return cls(level=1, base_space=base_space, map_function=path_map)


@dataclass
class ProofDeformation:
    """Deformation of chiral proofs.
    
    Models how proofs can be continuously transformed
    while preserving validity.
    """
    initial_proof: List[ChiralObject]  # Sequence of proof steps
    deformation_param: float = 0.0
    
    def step_count(self) -> int:
        """Number of proof steps."""
        return len(self.initial_proof)
    
    def deform(self, param: float) -> List[ChiralObject]:
        """Get deformed proof at parameter value."""
        deformed = []
        for i, step in enumerate(self.initial_proof):
            # Apply position-dependent deformation
            phase = 2 * np.pi * i / max(1, len(self.initial_proof) - 1)
            perturbation = param * np.sin(phase)
            new_data = step.data * (1 + 0.1 * perturbation)
            deformed.append(ChiralObject(new_data, step.chirality))
        return deformed
    
    def path_to(self, target_param: float) -> ChiralPath:
        """Create path from current to target deformation."""
        if len(self.initial_proof) == 0:
            raise ValueError("Cannot create path from empty proof")
        
        # Use aggregate representation
        start_data = np.mean([s.data for s in self.deform(self.deformation_param)], axis=0)
        end_data = np.mean([s.data for s in self.deform(target_param)], axis=0)
        
        return ChiralPath(
            start=ChiralObject(start_data, self.initial_proof[0].chirality),
            end=ChiralObject(end_data, self.initial_proof[0].chirality)
        )
    
    def is_valid(self, validator: Optional[Callable[[List[ChiralObject]], bool]] = None) -> bool:
        """Check if current deformed proof is valid."""
        if validator is None:
            # Default: check chirality consistency
            deformed = self.deform(self.deformation_param)
            if len(deformed) < 2:
                return True
            chiralities = [s.chirality for s in deformed]
            return chiralities.count(chiralities[0]) >= len(chiralities) // 2
        return validator(self.deform(self.deformation_param))
    
    def homotopy_equivalence(self, other: 'ProofDeformation') -> Optional[ChiralHomotopy]:
        """Find homotopy equivalence between two proof deformations if possible."""
        if self.step_count() != other.step_count():
            return None
        
        path0 = self.path_to(1.0)
        path1 = other.path_to(1.0)
        
        # Adjust endpoints for homotopy
        try:
            return ChiralHomotopy(
                path0=ChiralPath(path0.start, path0.end),
                path1=ChiralPath(path0.start, path0.end)  # Same endpoints for valid homotopy
            )
        except ValueError:
            return None


@dataclass
class FundamentalGroup:
    """Fundamental group of a chiral space.
    
    Tracks loop classes up to homotopy equivalence.
    """
    base_point: ChiralObject
    loops: List[ChiralPath] = field(default_factory=list)
    
    def add_loop(self, loop: ChiralPath) -> None:
        """Add a loop based at the base point."""
        if not loop.is_loop():
            raise ValueError("Path is not a loop")
        if loop.start.distance(self.base_point) > 1e-6:
            raise ValueError("Loop must start at base point")
        self.loops.append(loop)
    
    def trivial_loop(self) -> ChiralPath:
        """Return the trivial (constant) loop."""
        return ChiralPath(
            start=self.base_point,
            end=self.base_point,
            interpolation=lambda t: self.base_point
        )
    
    def compose_loops(self, loop1: ChiralPath, loop2: ChiralPath) -> ChiralPath:
        """Compose two loops (group operation)."""
        return loop1.compose(loop2)
    
    def inverse_loop(self, loop: ChiralPath) -> ChiralPath:
        """Get inverse loop."""
        return loop.reverse()
    
    def are_homotopic(self, loop1: ChiralPath, loop2: ChiralPath, 
                      tolerance: float = 1e-4) -> bool:
        """Check if two loops are homotopic."""
        # Simple check: compare path lengths and chirality
        len_diff = abs(loop1.length() - loop2.length())
        same_chirality = loop1.chirality_preserved() == loop2.chirality_preserved()
        return len_diff < tolerance * max(loop1.length(), loop2.length(), 1.0) and same_chirality


def construct_geodesic_homotopy(space: ChiralSpace, p0: ChiralObject, 
                                 p1: ChiralObject) -> ChiralPath:
    """Construct geodesic path in chiral space."""
    return ChiralPath(start=p0, end=p1)  # Linear is geodesic in flat spaces


def compute_winding_number(loop: ChiralPath, n_samples: int = 100) -> int:
    """Compute winding number of a loop (2D projection)."""
    if not loop.is_loop():
        raise ValueError("Must be a closed loop")
    
    total_angle = 0.0
    points = [loop(t) for t in np.linspace(0, 1, n_samples + 1)]
    
    for i in range(n_samples):
        # Use first two dimensions
        p1 = points[i].data[:2] if len(points[i].data) >= 2 else np.pad(points[i].data, (0, 2 - len(points[i].data)))
        p2 = points[i+1].data[:2] if len(points[i+1].data) >= 2 else np.pad(points[i+1].data, (0, 2 - len(points[i+1].data)))
        
        angle1 = np.arctan2(p1[1], p1[0]) if np.linalg.norm(p1) > 1e-10 else 0
        angle2 = np.arctan2(p2[1], p2[0]) if np.linalg.norm(p2) > 1e-10 else 0
        
        diff = angle2 - angle1
        # Handle wraparound
        if diff > np.pi:
            diff -= 2 * np.pi
        elif diff < -np.pi:
            diff += 2 * np.pi
        total_angle += diff
    
    return int(round(total_angle / (2 * np.pi)))
