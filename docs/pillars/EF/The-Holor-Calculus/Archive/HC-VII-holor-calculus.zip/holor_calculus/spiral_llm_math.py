"""SpiralLLM-Math: Core reasoning engine for mathematical problem solving.

Implements the SpiralLLM-Math reasoning framework for Third Cycle (§§5-6):
- Mathematical problem decomposition and analysis
- Step-by-step reasoning with verification
- Integration with homotopy and information geometry
- Spiral Agile methodology for iterative refinement
"""

from typing import List, Dict, Any, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum
import numpy as np


class ReasoningMode(Enum):
    """Reasoning modes for SpiralLLM-Math."""
    ANALYTICAL = "analytical"  # Formal mathematical analysis
    COMPUTATIONAL = "computational"  # Numerical computation
    GEOMETRIC = "geometric"  # Geometric/topological reasoning
    HYBRID = "hybrid"  # Combination of modes


class SpiralStage(Enum):
    """Spiral Agile stages for problem solving."""
    UNDERSTAND = "understand"  # Problem understanding
    PLAN = "plan"  # Solution planning
    EXECUTE = "execute"  # Execution
    VERIFY = "verify"  # Verification
    REFINE = "refine"  # Refinement


@dataclass
class ReasoningStep:
    """A single step in the reasoning chain."""
    stage: SpiralStage
    description: str
    input_data: Dict[str, Any]
    output_data: Dict[str, Any]
    verification: Optional[Dict[str, Any]] = None
    confidence: float = 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def is_verified(self) -> bool:
        """Check if step is verified."""
        if self.verification is None:
            return False
        return self.verification.get('status', False)


@dataclass
class MathematicalProblem:
    """Representation of a mathematical problem."""
    problem_type: str  # e.g., "homotopy", "divergence", "geodesic"
    description: str
    input_data: Dict[str, Any]
    constraints: List[str] = field(default_factory=list)
    expected_properties: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Solution:
    """Solution to a mathematical problem."""
    problem: MathematicalProblem
    reasoning_chain: List[ReasoningStep]
    result: Any
    verification_status: bool
    confidence: float
    metadata: Dict[str, Any] = field(default_factory=dict)

    def get_reasoning_trace(self) -> str:
        """Get human-readable reasoning trace."""
        trace = [f"Problem: {self.problem.description}\n"]
        for i, step in enumerate(self.reasoning_chain, 1):
            trace.append(f"Step {i} [{step.stage.value}]: {step.description}")
            if step.verification:
                status = "✓" if step.is_verified() else "✗"
                trace.append(f"  Verification: {status}")
        trace.append(f"\nResult: {self.result}")
        trace.append(f"Confidence: {self.confidence:.2%}")
        return "\n".join(trace)


class SpiralLLMMath:
    """Core SpiralLLM-Math reasoning engine.
    
    Provides mathematical reasoning capabilities with Spiral Agile methodology:
    - Problem decomposition and understanding
    - Step-by-step reasoning with verification
    - Iterative refinement through spiral cycles
    """

    def __init__(self, mode: ReasoningMode = ReasoningMode.HYBRID):
        """Initialize SpiralLLM-Math engine.
        
        Args:
            mode: Reasoning mode to use
        """
        self.mode = mode
        self.reasoners = {}  # Specialized reasoners
        self.verifiers = {}  # Verification functions
        self.problem_history: List[Solution] = []

    def register_reasoner(self, problem_type: str, reasoner: Callable) -> None:
        """Register a specialized reasoner for a problem type.
        
        Args:
            problem_type: Type of problem (e.g., "homotopy", "divergence")
            reasoner: Reasoner function
        """
        self.reasoners[problem_type] = reasoner

    def register_verifier(self, problem_type: str, verifier: Callable) -> None:
        """Register a verification function for a problem type.
        
        Args:
            problem_type: Type of problem
            verifier: Verification function
        """
        self.verifiers[problem_type] = verifier

    def solve(self, problem: MathematicalProblem, 
             max_iterations: int = 5) -> Solution:
        """Solve a mathematical problem using Spiral Agile methodology.
        
        Args:
            problem: Problem to solve
            max_iterations: Maximum refinement iterations
            
        Returns:
            Solution with reasoning chain and verification
        """
        reasoning_chain = []
        
        # Stage 1: UNDERSTAND
        understand_step = self._understand_problem(problem)
        reasoning_chain.append(understand_step)
        
        # Stage 2: PLAN
        plan_step = self._plan_solution(problem, understand_step)
        reasoning_chain.append(plan_step)
        
        # Stage 3: EXECUTE (with iterative refinement)
        result = None
        confidence = 0.0
        
        for iteration in range(max_iterations):
            # Execute
            execute_step = self._execute_solution(problem, plan_step)
            reasoning_chain.append(execute_step)
            result = execute_step.output_data.get('result')
            
            # Verify
            verify_step = self._verify_solution(problem, execute_step)
            reasoning_chain.append(verify_step)
            confidence = verify_step.confidence
            
            # Check if verified
            if verify_step.is_verified() and confidence > 0.9:
                break
            
            # Refine if needed
            if iteration < max_iterations - 1:
                refine_step = self._refine_solution(problem, verify_step)
                reasoning_chain.append(refine_step)
        
        # Create solution
        solution = Solution(
            problem=problem,
            reasoning_chain=reasoning_chain,
            result=result,
            verification_status=verify_step.is_verified(),
            confidence=confidence
        )
        
        self.problem_history.append(solution)
        return solution

    def _understand_problem(self, problem: MathematicalProblem) -> ReasoningStep:
        """Understand and analyze the problem."""
        analysis = {
            'problem_type': problem.problem_type,
            'input_dimensions': self._analyze_dimensions(problem.input_data),
            'constraints': problem.constraints,
            'properties': problem.expected_properties
        }
        
        return ReasoningStep(
            stage=SpiralStage.UNDERSTAND,
            description=f"Analyzed {problem.problem_type} problem",
            input_data={'problem': problem},
            output_data={'analysis': analysis},
            confidence=1.0
        )

    def _plan_solution(self, problem: MathematicalProblem, 
                      understand_step: ReasoningStep) -> ReasoningStep:
        """Plan the solution approach."""
        analysis = understand_step.output_data['analysis']
        
        # Select reasoner
        reasoner_type = problem.problem_type
        if reasoner_type not in self.reasoners:
            reasoner_type = 'default'
        
        plan = {
            'reasoner': reasoner_type,
            'mode': self.mode.value,
            'steps': self._generate_solution_steps(problem, analysis)
        }
        
        return ReasoningStep(
            stage=SpiralStage.PLAN,
            description=f"Planned solution using {reasoner_type} reasoner",
            input_data={'analysis': analysis},
            output_data={'plan': plan},
            confidence=1.0
        )

    def _execute_solution(self, problem: MathematicalProblem,
                         plan_step: ReasoningStep) -> ReasoningStep:
        """Execute the solution plan."""
        plan = plan_step.output_data['plan']
        reasoner_type = plan['reasoner']
        
        # Get reasoner
        if reasoner_type in self.reasoners:
            reasoner = self.reasoners[reasoner_type]
            result = reasoner(problem)
        else:
            result = self._default_execution(problem)
        
        return ReasoningStep(
            stage=SpiralStage.EXECUTE,
            description=f"Executed solution using {reasoner_type}",
            input_data={'plan': plan},
            output_data={'result': result},
            confidence=0.8
        )

    def _verify_solution(self, problem: MathematicalProblem,
                        execute_step: ReasoningStep) -> ReasoningStep:
        """Verify the solution."""
        result = execute_step.output_data['result']
        
        # Get verifier
        verifier_type = problem.problem_type
        if verifier_type in self.verifiers:
            verifier = self.verifiers[verifier_type]
            verification = verifier(problem, result)
        else:
            verification = {'status': True, 'message': 'No verifier available'}
        
        confidence = 0.9 if verification['status'] else 0.3
        
        return ReasoningStep(
            stage=SpiralStage.VERIFY,
            description="Verified solution",
            input_data={'result': result},
            output_data={'verification_result': verification},
            verification=verification,
            confidence=confidence
        )

    def _refine_solution(self, problem: MathematicalProblem,
                        verify_step: ReasoningStep) -> ReasoningStep:
        """Refine the solution based on verification."""
        verification = verify_step.verification
        refinements = verification.get('refinements', [])
        
        return ReasoningStep(
            stage=SpiralStage.REFINE,
            description=f"Applied {len(refinements)} refinements",
            input_data={'verification': verification},
            output_data={'refinements': refinements},
            confidence=0.7
        )

    def _analyze_dimensions(self, input_data: Dict[str, Any]) -> Dict[str, int]:
        """Analyze dimensions of input data."""
        dims = {}
        for key, value in input_data.items():
            if isinstance(value, np.ndarray):
                dims[key] = value.shape
            elif hasattr(value, 'data') and isinstance(value.data, np.ndarray):
                dims[key] = value.data.shape
        return dims

    def _generate_solution_steps(self, problem: MathematicalProblem,
                                 analysis: Dict[str, Any]) -> List[str]:
        """Generate high-level solution steps."""
        return [
            "Extract input data",
            "Apply mathematical operations",
            "Compute result",
            "Validate constraints"
        ]

    def _default_execution(self, problem: MathematicalProblem) -> Any:
        """Default execution when no specialized reasoner is available."""
        return {"message": "No specialized reasoner available",
                "problem_type": problem.problem_type}

    def get_history(self) -> List[Solution]:
        """Get problem-solving history."""
        return self.problem_history

    def get_statistics(self) -> Dict[str, Any]:
        """Get statistics about solved problems."""
        if not self.problem_history:
            return {}
        
        total = len(self.problem_history)
        verified = sum(1 for s in self.problem_history if s.verification_status)
        avg_confidence = np.mean([s.confidence for s in self.problem_history])
        avg_steps = np.mean([len(s.reasoning_chain) for s in self.problem_history])
        
        return {
            'total_problems': total,
            'verified_solutions': verified,
            'verification_rate': verified / total if total > 0 else 0,
            'average_confidence': float(avg_confidence),
            'average_reasoning_steps': float(avg_steps)
        }
