"""SpiralLLM-Math Homology Reasoner for §7.

Specialized reasoning capabilities for homology theory:
- Chain complex analysis
- Homology group computation
- Betti number calculation
- Euler characteristic reasoning
- Simplicial complex topology
"""

from typing import Any, Dict, List, Optional
import numpy as np

from .spiral_llm_math import MathematicalProblem, SpiralLLMMath, Solution, ReasoningStep
from .homology import (
    ChiralSimplex, ChiralChain, ChiralChainComplex, ChiralHomologyGroup,
    ChiralSimplicialComplex, SimplexOrientation,
    create_standard_simplex, create_boundary_of_simplex, compute_reduced_homology
)
from .chiral_base import ChiralObject, Chirality


class HomologyReasoner:
    """Specialized reasoner for homology theory problems.
    
    Provides reasoning capabilities for:
    - Chain operations and boundaries
    - Homology group computation
    - Topological invariants (Betti numbers, Euler characteristic)
    - Simplicial complex analysis
    """

    def __init__(self, spiral_engine: Optional[SpiralLLMMath] = None):
        """Initialize homology reasoner.
        
        Args:
            spiral_engine: SpiralLLM-Math engine to register with
        """
        self.spiral_engine = spiral_engine
        if spiral_engine:
            spiral_engine.register_reasoner('homology', self.solve_homology)
            spiral_engine.register_reasoner('chain_boundary', self.solve_chain_boundary)
            spiral_engine.register_reasoner('betti_numbers', self.solve_betti_numbers)
            spiral_engine.register_reasoner('euler_characteristic', self.solve_euler_characteristic)
            spiral_engine.register_verifier('homology', self.verify_homology)

    def solve_homology(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Solve a general homology problem.
        
        Args:
            problem: Problem with homology-related data
            
        Returns:
            Solution data
        """
        operation = problem.input_data.get('operation', 'compute')
        
        if operation == 'compute_boundary':
            return self._compute_boundary(problem)
        elif operation == 'verify_boundary_property':
            return self._verify_boundary_squared_zero(problem)
        elif operation == 'compute_homology_groups':
            return self._compute_homology_groups(problem)
        elif operation == 'analyze_complex':
            return self._analyze_simplicial_complex(problem)
        else:
            return {'error': f'Unknown operation: {operation}'}

    def solve_chain_boundary(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Solve chain boundary problem.
        
        Args:
            problem: Problem with chain data
            
        Returns:
            Boundary computation results
        """
        chain = problem.input_data.get('chain')
        
        if not isinstance(chain, ChiralChain):
            return {'error': 'Invalid chain provided'}
        
        # Compute boundary
        boundary = chain.boundary()
        
        # Verify ∂∂ = 0
        boundary2 = boundary.boundary()
        boundary_property_holds = boundary2.is_zero()
        
        # Analyze dimensions
        chain_dim = chain.dimension
        boundary_dim = boundary.dimension if not boundary.is_zero() else None
        
        return {
            'chain': chain,
            'boundary': boundary,
            'chain_dimension': chain_dim,
            'boundary_dimension': boundary_dim,
            'boundary_is_zero': boundary.is_zero(),
            'boundary_property_verified': boundary_property_holds,
            'n_simplices_chain': len(chain.simplices),
            'n_simplices_boundary': len(boundary.simplices),
            'explanation': self._explain_boundary_computation(chain, boundary)
        }

    def solve_betti_numbers(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Solve Betti number computation problem.
        
        Args:
            problem: Problem with simplicial complex
            
        Returns:
            Betti numbers and analysis
        """
        complex_obj = problem.input_data.get('complex')
        
        if not isinstance(complex_obj, ChiralSimplicialComplex):
            return {'error': 'Invalid simplicial complex provided'}
        
        # Compute Betti numbers
        betti_numbers = complex_obj.compute_betti_numbers()
        
        # Compute Euler characteristic
        euler_char = complex_obj.euler_characteristic()
        
        # Verify Euler-Poincaré formula
        euler_from_betti = sum((-1)**i * b for i, b in enumerate(betti_numbers))
        
        # Analyze topology
        topology_type = self._classify_topology(betti_numbers)
        
        return {
            'betti_numbers': betti_numbers,
            'euler_characteristic': euler_char,
            'euler_from_betti': euler_from_betti,
            'dimension': complex_obj.dimension(),
            'f_vector': complex_obj.f_vector(),
            'topology_type': topology_type,
            'n_connected_components': betti_numbers[0] if betti_numbers else 0,
            'n_holes': betti_numbers[1] if len(betti_numbers) > 1 else 0,
            'explanation': self._explain_betti_numbers(betti_numbers, topology_type)
        }

    def solve_euler_characteristic(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Solve Euler characteristic problem.
        
        Args:
            problem: Problem with simplicial complex
            
        Returns:
            Euler characteristic analysis
        """
        complex_obj = problem.input_data.get('complex')
        
        if not isinstance(complex_obj, ChiralSimplicialComplex):
            return {'error': 'Invalid simplicial complex provided'}
        
        # Compute via f-vector
        f_vec = complex_obj.f_vector()
        euler_char = complex_obj.euler_characteristic()
        
        # Compute via Betti numbers
        betti = complex_obj.compute_betti_numbers()
        euler_from_betti = sum((-1)**i * b for i, b in enumerate(betti))
        
        # Analyze chirality distribution
        chiral_dist = complex_obj.chirality_distribution()
        
        return {
            'euler_characteristic': euler_char,
            'f_vector': f_vec,
            'computation_from_f_vector': self._explain_euler_from_f_vector(f_vec, euler_char),
            'betti_numbers': betti,
            'euler_from_betti': euler_from_betti,
            'chirality_distribution': {k.name: v for k, v in chiral_dist.items()},
            'verification': abs(euler_char - euler_from_betti) < 1e-6,
            'explanation': self._explain_euler_characteristic(euler_char, f_vec, betti)
        }

    def _compute_boundary(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Compute boundary of a chain."""
        chain = problem.input_data.get('chain')
        
        if not isinstance(chain, ChiralChain):
            return {'error': 'Invalid chain'}
        
        boundary = chain.boundary()
        
        return {
            'chain': chain,
            'boundary': boundary,
            'dimension_reduced_by_one': (chain.dimension or 0) - (boundary.dimension or -1) == 1,
            'is_cycle': boundary.is_zero(),
        }

    def _verify_boundary_squared_zero(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Verify that ∂∂ = 0 for a chain."""
        chain = problem.input_data.get('chain')
        complex_obj = problem.input_data.get('complex')
        
        if isinstance(chain, ChiralChain):
            boundary1 = chain.boundary()
            boundary2 = boundary1.boundary()
            verified = boundary2.is_zero()
        elif isinstance(complex_obj, ChiralChainComplex):
            verified = complex_obj.verify_boundary_property(chain)
        else:
            return {'error': 'Invalid input'}
        
        return {
            'verified': verified,
            'fundamental_property': '∂∂ = 0',
            'holds': verified,
            'explanation': 'The boundary operator is nilpotent: applying it twice always gives zero.'
        }

    def _compute_homology_groups(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Compute homology groups for a complex."""
        complex_obj = problem.input_data.get('complex')
        
        if not isinstance(complex_obj, ChiralSimplicialComplex):
            return {'error': 'Invalid complex'}
        
        # Get chain complex
        chain_complex = complex_obj.chain_complex
        homology = ChiralHomologyGroup(chain_complex)
        
        # Compute Betti numbers (dimensions of homology groups)
        betti = complex_obj.compute_betti_numbers()
        
        return {
            'homology_dimensions': betti,
            'max_dimension': complex_obj.dimension(),
            'description': 'H_k dimensions (Betti numbers)',
            'interpretation': self._interpret_homology_groups(betti)
        }

    def _analyze_simplicial_complex(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Comprehensive analysis of a simplicial complex."""
        complex_obj = problem.input_data.get('complex')
        
        if not isinstance(complex_obj, ChiralSimplicialComplex):
            return {'error': 'Invalid complex'}
        
        # Collect all invariants
        f_vec = complex_obj.f_vector()
        euler_char = complex_obj.euler_characteristic()
        betti = complex_obj.compute_betti_numbers()
        chiral_dist = complex_obj.chirality_distribution()
        
        return {
            'dimension': complex_obj.dimension(),
            'f_vector': f_vec,
            'euler_characteristic': euler_char,
            'betti_numbers': betti,
            'chirality_distribution': {k.name: v for k, v in chiral_dist.items()},
            'n_vertices': complex_obj.n_vertices,
            'summary': self._summarize_complex(complex_obj, f_vec, euler_char, betti)
        }

    def _explain_boundary_computation(self, chain: ChiralChain, boundary: ChiralChain) -> str:
        """Generate explanation of boundary computation."""
        if chain.is_zero():
            return "The boundary of the zero chain is zero."
        
        if boundary.is_zero():
            return f"This {chain.dimension}-chain is a cycle (has zero boundary)."
        
        return (f"The boundary operator reduced dimension from {chain.dimension} "
                f"to {boundary.dimension}, mapping {len(chain.simplices)} simplices "
                f"to {len(boundary.simplices)} boundary faces.")

    def _explain_betti_numbers(self, betti: List[int], topology_type: str) -> str:
        """Generate explanation of Betti numbers."""
        explanation = f"Topological type: {topology_type}. "
        
        if len(betti) == 0:
            return explanation + "Empty complex."
        
        explanation += f"β_0 = {betti[0]} (connected components). "
        
        if len(betti) > 1:
            explanation += f"β_1 = {betti[1]} (1-dimensional holes/loops). "
        
        if len(betti) > 2:
            explanation += f"β_2 = {betti[2]} (2-dimensional voids). "
        
        return explanation

    def _explain_euler_characteristic(self, euler: int, f_vec: List[int], betti: List[int]) -> str:
        """Generate explanation of Euler characteristic."""
        computation = " - ".join(f"{(-1)**i}*{f}" for i, f in enumerate(f_vec))
        result = f"χ = {computation} = {euler}"
        
        if betti:
            betti_comp = " - ".join(f"{(-1)**i}*{b}" for i, b in enumerate(betti))
            result += f" (also χ = {betti_comp} from Betti numbers)"
        
        return result

    def _explain_euler_from_f_vector(self, f_vec: List[int], euler: int) -> str:
        """Explain Euler characteristic computation from f-vector."""
        terms = [f"{'−' if i % 2 == 1 else '+'}{f_vec[i]}" for i in range(len(f_vec))]
        computation = "".join(terms).lstrip('+')
        return f"χ = {computation} = {euler}"

    def _classify_topology(self, betti: List[int]) -> str:
        """Classify topological type from Betti numbers."""
        if len(betti) == 0:
            return "empty"
        
        if betti[0] == 0:
            return "empty"
        elif betti[0] == 1:
            if len(betti) == 1 or all(b == 0 for b in betti[1:]):
                return "contractible/simply-connected"
            elif len(betti) > 1 and betti[1] == 1:
                return "has_one_loop (circle-like)"
            elif len(betti) > 1 and betti[1] > 1:
                return f"has_{betti[1]}_loops"
        elif betti[0] > 1:
            return f"{betti[0]}_disconnected_components"
        
        return "unknown"

    def _interpret_homology_groups(self, betti: List[int]) -> str:
        """Interpret homology groups in natural language."""
        if not betti:
            return "No homology groups (empty complex)."
        
        interpretations = []
        interpretations.append(f"H_0 has dimension {betti[0]} (number of connected components)")
        
        if len(betti) > 1:
            interpretations.append(f"H_1 has dimension {betti[1]} (number of independent 1-cycles/loops)")
        
        if len(betti) > 2:
            interpretations.append(f"H_2 has dimension {betti[2]} (number of 2-dimensional voids)")
        
        return "; ".join(interpretations) + "."

    def _summarize_complex(self, complex_obj: ChiralSimplicialComplex, 
                          f_vec: List[int], euler: int, betti: List[int]) -> str:
        """Generate comprehensive summary of complex."""
        summary = f"A {complex_obj.dimension()}-dimensional simplicial complex "
        summary += f"with f-vector {f_vec}, "
        summary += f"Euler characteristic χ = {euler}, "
        summary += f"and Betti numbers {betti}. "
        
        if betti:
            summary += f"Has {betti[0]} connected component(s)."
        
        return summary

    def verify_homology(self, problem: MathematicalProblem, 
                       result: Dict[str, Any]) -> Dict[str, Any]:
        """Verify homology computation results.
        
        Args:
            problem: Original problem
            result: Solution result
            
        Returns:
            Verification results
        """
        checks = []
        
        # Check boundary property
        if 'boundary_property_verified' in result:
            checks.append({
                'name': 'boundary_squared_zero',
                'passed': result['boundary_property_verified'],
                'message': '∂∂ = 0 verified' if result['boundary_property_verified'] else '∂∂ = 0 failed'
            })
        
        # Check Euler-Poincaré formula
        if 'euler_characteristic' in result and 'euler_from_betti' in result:
            euler_match = abs(result['euler_characteristic'] - result['euler_from_betti']) < 1e-6
            checks.append({
                'name': 'euler_poincare_formula',
                'passed': euler_match,
                'message': f"χ from f-vector ({result['euler_characteristic']}) matches "
                          f"χ from Betti numbers ({result['euler_from_betti']})" if euler_match
                          else "Euler-Poincaré formula mismatch"
            })
        
        # Check Betti number non-negativity
        if 'betti_numbers' in result:
            betti_valid = all(b >= 0 for b in result['betti_numbers'])
            checks.append({
                'name': 'betti_non_negative',
                'passed': betti_valid,
                'message': 'All Betti numbers are non-negative' if betti_valid 
                          else 'Invalid negative Betti number'
            })
        
        return {
            'checks': checks,
            'all_passed': all(c['passed'] for c in checks),
            'n_checks': len(checks),
            'n_passed': sum(c['passed'] for c in checks)
        }
