"""SpiralLLM-Math Information Geometry Reasoner for §6.

Specialized reasoning capabilities for information geometry:
- Fisher metric analysis
- Divergence computations
- Geometric statistics
- Natural gradient reasoning
- Exponential family analysis
"""

from typing import Any, Dict, List, Optional, Tuple
import numpy as np

from .spiral_llm_math import MathematicalProblem, SpiralLLMMath
from .info_geometry import (
    FisherMetric, ChiralDivergence, GeometricStatistics,
    ChiralExponentialFamily, create_gaussian_exponential_family,
    ChiralDistribution
)
from .chiral_base import ChiralObject, Chirality


class InfoGeometryReasoner:
    """Specialized reasoner for information geometry problems.
    
    Provides reasoning capabilities for:
    - Fisher metric computations
    - Divergence analysis
    - Geometric statistics
    - Exponential family structures
    """

    def __init__(self, spiral_engine: Optional[SpiralLLMMath] = None):
        """Initialize information geometry reasoner.
        
        Args:
            spiral_engine: SpiralLLM-Math engine to register with
        """
        self.spiral_engine = spiral_engine
        if spiral_engine:
            spiral_engine.register_reasoner('fisher_metric', self.solve_fisher_metric)
            spiral_engine.register_reasoner('divergence', self.solve_divergence)
            spiral_engine.register_reasoner('geometric_statistics', self.solve_geometric_statistics)
            spiral_engine.register_reasoner('exponential_family', self.solve_exponential_family)
            spiral_engine.register_verifier('fisher_metric', self.verify_metric)
            spiral_engine.register_verifier('divergence', self.verify_divergence)

    def solve_fisher_metric(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Solve Fisher metric problem.
        
        Args:
            problem: Problem with Fisher metric data
            
        Returns:
            Solution data
        """
        operation = problem.input_data.get('operation', 'compute')
        
        if operation == 'compute':
            return self._compute_fisher_metric(problem)
        elif operation == 'geodesic':
            return self._compute_geodesic(problem)
        elif operation == 'curvature':
            return self._compute_curvature(problem)
        else:
            return {'error': f'Unknown operation: {operation}'}

    def solve_divergence(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Solve divergence problem.
        
        Args:
            problem: Problem with divergence data
            
        Returns:
            Solution data
        """
        divergence_type = problem.input_data.get('type', 'kl')
        obj1 = problem.input_data.get('object1')
        obj2 = problem.input_data.get('object2')
        
        # Convert ChiralObjects to ChiralDistributions if needed
        if isinstance(obj1, ChiralObject):
            dist1 = ChiralDistribution(parameters=obj1.data, chirality=obj1.chirality)
        elif isinstance(obj1, ChiralDistribution):
            dist1 = obj1
        else:
            return {'error': 'Invalid object1 type'}
            
        if isinstance(obj2, ChiralObject):
            dist2 = ChiralDistribution(parameters=obj2.data, chirality=obj2.chirality)
        elif isinstance(obj2, ChiralDistribution):
            dist2 = obj2
        else:
            return {'error': 'Invalid object2 type'}
        
        divergence = ChiralDivergence()
        
        if divergence_type == 'kl':
            value = divergence.kl_divergence(dist1, dist2)
        elif divergence_type == 'alpha':
            alpha = problem.input_data.get('alpha', 1.0)
            value = divergence.alpha_divergence(dist1, dist2, alpha)
        elif divergence_type == 'hellinger':
            value = divergence.hellinger_distance(dist1, dist2)
        elif divergence_type == 'fisher_rao':
            value = divergence.fisher_rao_distance(dist1, dist2)
        else:
            return {'error': f'Unknown divergence type: {divergence_type}'}
        
        return {
            'divergence_type': divergence_type,
            'value': value,
            'object1': obj1,
            'object2': obj2,
            'symmetric': divergence_type in ['hellinger', 'fisher_rao']
        }

    def solve_geometric_statistics(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Solve geometric statistics problem.
        
        Args:
            problem: Problem with statistical data
            
        Returns:
            Solution data
        """
        operation = problem.input_data.get('operation', 'frechet_mean')
        objects = problem.input_data.get('objects', [])
        metric = problem.input_data.get('metric')
        
        # For interpolate operation, we don't need 'objects'
        if operation != 'interpolate' and not objects:
            return {'error': 'No objects provided'}
        
        # Convert ChiralObjects to ChiralDistributions if needed
        distributions = []
        for obj in objects:
            if isinstance(obj, ChiralObject):
                distributions.append(ChiralDistribution(parameters=obj.data, chirality=obj.chirality))
            else:
                distributions.append(obj)
        
        if operation == 'frechet_mean':
            mean_dist = GeometricStatistics.frechet_mean(distributions, metric)
            # Convert back to ChiralObject
            mean_obj = ChiralObject(mean_dist.parameters, mean_dist.chirality)
            return {
                'mean': mean_obj,
                'num_objects': len(objects),
                'operation': 'frechet_mean'
            }
        elif operation == 'variance':
            variance = GeometricStatistics.geometric_variance(distributions, mean=None, metric=metric)
            return {
                'variance': variance,
                'num_objects': len(objects),
                'operation': 'geometric_variance'
            }
        elif operation == 'interpolate':
            obj1 = problem.input_data.get('object1')
            obj2 = problem.input_data.get('object2')
            t = problem.input_data.get('t', 0.5)
            
            # Convert to distributions
            if isinstance(obj1, ChiralObject):
                dist1 = ChiralDistribution(parameters=obj1.data, chirality=obj1.chirality)
            else:
                dist1 = obj1
            if isinstance(obj2, ChiralObject):
                dist2 = ChiralDistribution(parameters=obj2.data, chirality=obj2.chirality)
            else:
                dist2 = obj2
            
            interpolated_dist = GeometricStatistics.geodesic_interpolation(dist1, dist2, t)
            interpolated = ChiralObject(interpolated_dist.parameters, interpolated_dist.chirality)
            return {
                'interpolated': interpolated,
                't': t,
                'operation': 'geodesic_interpolation'
            }
        else:
            return {'error': f'Unknown operation: {operation}'}

    def solve_exponential_family(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Solve exponential family problem.
        
        Args:
            problem: Problem with exponential family data
            
        Returns:
            Solution data
        """
        family_type = problem.input_data.get('family_type', 'gaussian')
        
        if family_type == 'gaussian':
            mean = problem.input_data.get('mean', 0.0)
            variance = problem.input_data.get('variance', 1.0)
            chirality = problem.input_data.get('chirality', Chirality.NEUTRAL)
            
            family = create_gaussian_exponential_family(mean, variance, chirality)
            
            # Compute Fisher metric if parameters provided
            params = problem.input_data.get('params')
            if params is not None:
                metric = family.fisher_metric()
                return {
                    'family': family,
                    'fisher_metric': metric,
                    'params': params,
                    'mean': mean,
                    'variance': variance
                }
            else:
                return {
                    'family': family,
                    'mean': mean,
                    'variance': variance
                }
        else:
            return {'error': f'Unknown family type: {family_type}'}

    def verify_metric(self, problem: MathematicalProblem,
                     result: Dict[str, Any]) -> Dict[str, bool]:
        """Verify Fisher metric solution.
        
        Args:
            problem: Original problem
            result: Solution result
            
        Returns:
            Verification result
        """
        if 'error' in result:
            return {'status': False, 'message': result['error']}
        
        operation = problem.input_data.get('operation', 'compute')
        
        if operation == 'compute' and 'metric' in result:
            # Verify metric is positive definite
            metric = result['metric']
            if isinstance(metric, FisherMetric):
                return {
                    'status': True,
                    'message': 'Fisher metric computed successfully'
                }
        
        return {'status': True, 'message': 'Verification passed'}

    def verify_divergence(self, problem: MathematicalProblem,
                         result: Dict[str, Any]) -> Dict[str, bool]:
        """Verify divergence solution.
        
        Args:
            problem: Original problem
            result: Solution result
            
        Returns:
            Verification result
        """
        if 'error' in result:
            return {'status': False, 'message': result['error']}
        
        if 'value' in result:
            value = result['value']
            # Verify non-negativity for divergences
            if isinstance(value, (int, float)):
                if value >= 0 or np.isclose(value, 0, atol=1e-10):
                    return {
                        'status': True,
                        'message': f'Divergence value {value:.6f} is non-negative'
                    }
                else:
                    return {
                        'status': False,
                        'message': f'Divergence value {value:.6f} is negative!',
                        'refinements': ['Check computation', 'Verify inputs']
                    }
        
        return {'status': True, 'message': 'Verification passed'}

    def _compute_fisher_metric(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Compute Fisher metric."""
        distribution_type = problem.input_data.get('distribution', 'gaussian')
        dim = problem.input_data.get('dim', 2)
        
        if distribution_type == 'gaussian':
            metric = FisherMetric.gaussian(dim)
        else:
            # Custom metric
            metric_fn = problem.input_data.get('metric_fn')
            if metric_fn is None:
                return {'error': 'No metric function provided'}
            metric = FisherMetric(metric_fn)
        
        return {
            'metric': metric,
            'distribution': distribution_type,
            'dim': dim
        }

    def _compute_geodesic(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Compute geodesic distance."""
        metric = problem.input_data.get('metric')
        point1 = problem.input_data.get('point1')
        point2 = problem.input_data.get('point2')
        
        if not isinstance(metric, FisherMetric):
            return {'error': 'Invalid Fisher metric'}
        
        distance = metric.geodesic_distance(point1, point2)
        
        return {
            'distance': distance,
            'point1': point1,
            'point2': point2,
            'metric': metric
        }

    def _compute_curvature(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Compute Riemannian curvature."""
        metric = problem.input_data.get('metric')
        point = problem.input_data.get('point')
        
        if not isinstance(metric, FisherMetric):
            return {'error': 'Invalid Fisher metric'}
        
        curvature = metric.riemann_curvature(point)
        
        return {
            'curvature': curvature,
            'point': point,
            'metric': metric
        }

    def reason_about_manifold(self, metric: FisherMetric,
                             sample_points: List[np.ndarray]) -> Dict[str, Any]:
        """Reason about statistical manifold structure.
        
        Args:
            metric: Fisher metric defining the manifold
            sample_points: Points to analyze
            
        Returns:
            Manifold analysis
        """
        # Compute pairwise distances
        n = len(sample_points)
        distances = np.zeros((n, n))
        for i in range(n):
            for j in range(i+1, n):
                dist = metric.geodesic_distance(sample_points[i], sample_points[j])
                distances[i, j] = dist
                distances[j, i] = dist
        
        # Analyze curvature (global property of metric)
        curvature_tensor = metric.riemann_curvature()
        scalar_curvature = metric.scalar_curvature()
        avg_curvature = scalar_curvature  # Scalar curvature is the main invariant
        
        return {
            'num_points': n,
            'distance_matrix': distances,
            'curvature_tensor': curvature_tensor,
            'scalar_curvature': scalar_curvature,
            'average_curvature': float(avg_curvature),
            'max_distance': float(np.max(distances)),
            'min_distance': float(np.min(distances[distances > 0])) if np.any(distances > 0) else 0.0
        }

    def explain_divergence(self, divergence_result: Dict[str, Any]) -> str:
        """Generate natural language explanation of divergence.
        
        Args:
            divergence_result: Result from solve_divergence
            
        Returns:
            Natural language explanation
        """
        div_type = divergence_result['divergence_type']
        value = divergence_result['value']
        symmetric = divergence_result.get('symmetric', False)
        
        explanation = [
            f"Divergence Analysis ({div_type.upper()}):",
            f"- Divergence value: {value:.6f}",
            f"- Type: {'Symmetric' if symmetric else 'Asymmetric'}"
        ]
        
        if div_type == 'kl':
            explanation.append("- KL divergence measures information loss")
            explanation.append("- Non-symmetric: D(P||Q) ≠ D(Q||P) in general")
        elif div_type == 'hellinger':
            explanation.append("- Hellinger distance is a true metric")
            explanation.append("- Bounded between 0 and √2")
        elif div_type == 'fisher_rao':
            explanation.append("- Fisher-Rao is the natural Riemannian distance")
            explanation.append("- Geodesic distance on the statistical manifold")
        
        if value < 0.01:
            explanation.append("- The objects are very similar")
        elif value > 1.0:
            explanation.append("- The objects are quite different")
        else:
            explanation.append("- The objects have moderate dissimilarity")
        
        return "\n".join(explanation)

    def analyze_chiral_effects(self, obj1: ChiralObject, 
                              obj2: ChiralObject) -> Dict[str, Any]:
        """Analyze how chirality affects information geometry.
        
        Args:
            obj1: First chiral object
            obj2: Second chiral object
            
        Returns:
            Chirality effect analysis
        """
        # Convert to distributions
        dist1 = ChiralDistribution(parameters=obj1.data, chirality=obj1.chirality)
        dist2 = ChiralDistribution(parameters=obj2.data, chirality=obj2.chirality)
        
        divergence = ChiralDivergence()
        
        # Compute various divergences
        kl = divergence.kl_divergence(dist1, dist2)
        hellinger = divergence.hellinger_distance(dist1, dist2)
        fisher_rao = divergence.fisher_rao_distance(dist1, dist2)
        
        # Analyze chirality compatibility
        same_chirality = obj1.chirality == obj2.chirality
        chirality_product = obj1.chirality * obj2.chirality
        
        return {
            'kl_divergence': kl,
            'hellinger_distance': hellinger,
            'fisher_rao_distance': fisher_rao,
            'same_chirality': same_chirality,
            'chirality_product': chirality_product,
            'chirality_penalty': not same_chirality,
            'interpretation': (
                "Chiralities are compatible" if same_chirality 
                else "Chirality mismatch increases divergence"
            )
        }
