"""§6 - Chiral Information Geometry.

Implements information-geometric structures on chiral spaces:
- Fisher metrics for chiral distributions
- Divergences (KL, alpha-divergences) 
- Geometric statistics in chiral context
"""

import numpy as np
from dataclasses import dataclass, field
from typing import Optional, List, Callable, Tuple, Union
from scipy import linalg
from .chiral_base import ChiralObject, Chirality, ChiralSpace


@dataclass
class ChiralDistribution:
    """A probability distribution with chiral structure."""
    parameters: np.ndarray
    chirality: Chirality = Chirality.NEUTRAL
    log_density: Optional[Callable[[np.ndarray], float]] = None
    
    def __post_init__(self):
        if isinstance(self.parameters, list):
            self.parameters = np.array(self.parameters, dtype=np.float64)
        if self.log_density is None:
            # Default: Gaussian-like
            self.log_density = lambda x: -0.5 * np.sum((x - self.parameters[:len(x)])**2)
    
    @property
    def dimension(self) -> int:
        return len(self.parameters)
    
    def density(self, x: np.ndarray) -> float:
        """Evaluate density at x."""
        return np.exp(self.log_density(x))
    
    def sample(self, n: int = 1) -> np.ndarray:
        """Sample from distribution (assuming Gaussian-like)."""
        mean = self.parameters[:self.dimension//2] if self.dimension > 1 else self.parameters
        return np.random.randn(n, len(mean)) + mean


@dataclass
class FisherMetric:
    """Fisher information metric on a chiral statistical manifold.
    
    The Fisher metric is the natural Riemannian metric on
    spaces of probability distributions.
    """
    dimension: int
    chirality: Chirality = Chirality.NEUTRAL
    _metric_matrix: np.ndarray = field(default=None)
    
    def __post_init__(self):
        if self._metric_matrix is None:
            # Default: identity (Euclidean)
            self._metric_matrix = np.eye(self.dimension)
    
    @classmethod
    def from_distribution(cls, dist: ChiralDistribution, 
                          epsilon: float = 1e-5) -> 'FisherMetric':
        """Compute Fisher metric from a distribution via numerical differentiation."""
        dim = dist.dimension
        fisher = np.zeros((dim, dim))
        
        # Numerical estimation of Fisher information
        n_samples = 1000
        samples = dist.sample(n_samples)
        
        for i in range(dim):
            for j in range(i, dim):
                # Score function approximation
                score_i = np.zeros(n_samples)
                score_j = np.zeros(n_samples)
                
                for k, x in enumerate(samples):
                    # Numerical gradient of log density
                    params_plus_i = dist.parameters.copy()
                    params_plus_i[i] += epsilon
                    params_minus_i = dist.parameters.copy()
                    params_minus_i[i] -= epsilon
                    
                    dist_plus = ChiralDistribution(params_plus_i, dist.chirality, dist.log_density)
                    dist_minus = ChiralDistribution(params_minus_i, dist.chirality, dist.log_density)
                    
                    score_i[k] = (dist_plus.log_density(x) - dist_minus.log_density(x)) / (2 * epsilon)
                    
                    if i != j:
                        params_plus_j = dist.parameters.copy()
                        params_plus_j[j] += epsilon
                        params_minus_j = dist.parameters.copy()
                        params_minus_j[j] -= epsilon
                        
                        dist_plus_j = ChiralDistribution(params_plus_j, dist.chirality, dist.log_density)
                        dist_minus_j = ChiralDistribution(params_minus_j, dist.chirality, dist.log_density)
                        
                        score_j[k] = (dist_plus_j.log_density(x) - dist_minus_j.log_density(x)) / (2 * epsilon)
                    else:
                        score_j[k] = score_i[k]
                
                fisher[i, j] = np.mean(score_i * score_j)
                fisher[j, i] = fisher[i, j]
        
        # Ensure positive definiteness
        fisher = (fisher + fisher.T) / 2
        min_eig = np.min(np.linalg.eigvalsh(fisher))
        if min_eig < 1e-10:
            fisher += (1e-10 - min_eig) * np.eye(dim)
        
        metric = cls(dimension=dim, chirality=dist.chirality)
        metric._metric_matrix = fisher
        return metric
    
    @classmethod
    def gaussian(cls, dimension: int, chirality: Chirality = Chirality.NEUTRAL) -> 'FisherMetric':
        """Standard Fisher metric for Gaussian family."""
        # For N(mu, sigma^2): Fisher = diag(1/sigma^2, 2/sigma^4)
        # Simplified: use identity
        metric = cls(dimension=dimension, chirality=chirality)
        metric._metric_matrix = np.eye(dimension)
        return metric
    
    def metric_tensor(self, point: Optional[np.ndarray] = None) -> np.ndarray:
        """Get metric tensor at a point."""
        return self._metric_matrix.copy()
    
    def inner_product(self, v1: np.ndarray, v2: np.ndarray, 
                      point: Optional[np.ndarray] = None) -> float:
        """Compute inner product of tangent vectors."""
        g = self.metric_tensor(point)
        return float(v1 @ g @ v2)
    
    def norm(self, v: np.ndarray, point: Optional[np.ndarray] = None) -> float:
        """Compute norm of tangent vector."""
        return np.sqrt(self.inner_product(v, v, point))
    
    def geodesic_distance(self, p1: np.ndarray, p2: np.ndarray) -> float:
        """Approximate geodesic distance between two points."""
        diff = p2 - p1
        return self.norm(diff, (p1 + p2) / 2)
    
    def christoffel_symbols(self, point: np.ndarray) -> np.ndarray:
        """Compute Christoffel symbols (simplified: assume constant metric)."""
        # For constant metric, Christoffel symbols vanish
        return np.zeros((self.dimension, self.dimension, self.dimension))
    
    def riemann_curvature(self) -> np.ndarray:
        """Compute Riemann curvature tensor (simplified)."""
        # For flat metric, curvature vanishes
        return np.zeros((self.dimension, self.dimension, self.dimension, self.dimension))
    
    def scalar_curvature(self) -> float:
        """Compute scalar curvature."""
        return 0.0  # Flat for constant metric
    
    def volume_element(self) -> float:
        """Compute volume element sqrt(det(g))."""
        return np.sqrt(np.abs(np.linalg.det(self._metric_matrix)))


@dataclass
class ChiralDivergence:
    """Divergence measures between chiral distributions."""
    
    @staticmethod
    def kl_divergence(p: ChiralDistribution, q: ChiralDistribution,
                      n_samples: int = 1000) -> float:
        """Kullback-Leibler divergence D_KL(p || q)."""
        samples = p.sample(n_samples)
        log_p = np.array([p.log_density(x) for x in samples])
        log_q = np.array([q.log_density(x) for x in samples])
        
        kl = np.mean(log_p - log_q)
        
        # Chiral correction
        if p.chirality != q.chirality:
            kl *= 1.5  # Divergence penalty for mismatched chirality
        
        return max(0.0, kl)  # KL is non-negative
    
    @staticmethod
    def symmetric_kl(p: ChiralDistribution, q: ChiralDistribution,
                     n_samples: int = 1000) -> float:
        """Symmetric KL divergence (Jeffreys divergence)."""
        return 0.5 * (ChiralDivergence.kl_divergence(p, q, n_samples) + 
                      ChiralDivergence.kl_divergence(q, p, n_samples))
    
    @staticmethod
    def alpha_divergence(p: ChiralDistribution, q: ChiralDistribution,
                         alpha: float, n_samples: int = 1000) -> float:
        """Alpha-divergence D_alpha(p || q).
        
        Generalizes KL divergence:
        - alpha -> 1: KL(p || q)
        - alpha -> 0: KL(q || p)  
        - alpha = 0.5: Hellinger distance
        """
        if abs(alpha) < 1e-10:
            return ChiralDivergence.kl_divergence(q, p, n_samples)
        if abs(alpha - 1) < 1e-10:
            return ChiralDivergence.kl_divergence(p, q, n_samples)
        
        samples = p.sample(n_samples)
        p_vals = np.array([p.density(x) for x in samples])
        q_vals = np.array([q.density(x) for x in samples])
        
        # Avoid division by zero
        q_vals = np.maximum(q_vals, 1e-10)
        p_vals = np.maximum(p_vals, 1e-10)
        
        ratio = q_vals / p_vals
        integrand = (1 - np.power(ratio, alpha)) / (alpha * (1 - alpha))
        
        result = np.mean(integrand)
        
        # Chiral correction
        if p.chirality != q.chirality:
            result *= 1.0 + 0.5 * abs(alpha)
        
        return max(0.0, result)
    
    @staticmethod
    def hellinger_distance(p: ChiralDistribution, q: ChiralDistribution,
                           n_samples: int = 1000) -> float:
        """Hellinger distance."""
        samples = p.sample(n_samples)
        sqrt_p = np.sqrt([max(0, p.density(x)) for x in samples])
        sqrt_q = np.sqrt([max(0, q.density(x)) for x in samples])
        
        h_sq = 0.5 * np.mean((sqrt_p - sqrt_q)**2)
        
        if p.chirality != q.chirality:
            h_sq *= 1.25
        
        return np.sqrt(max(0, h_sq))
    
    @staticmethod
    def fisher_rao_distance(p: ChiralDistribution, q: ChiralDistribution,
                            metric: Optional[FisherMetric] = None) -> float:
        """Fisher-Rao geodesic distance."""
        if metric is None:
            metric = FisherMetric.gaussian(p.dimension, p.chirality)
        return metric.geodesic_distance(p.parameters, q.parameters)


@dataclass
class GeometricStatistics:
    """Geometric statistics in chiral information geometry."""
    
    @staticmethod
    def frechet_mean(distributions: List[ChiralDistribution], 
                     metric: Optional[FisherMetric] = None,
                     max_iter: int = 100, tol: float = 1e-6) -> ChiralDistribution:
        """Compute Fréchet mean (geometric mean) of distributions."""
        if not distributions:
            raise ValueError("Need at least one distribution")
        
        dim = distributions[0].dimension
        
        if metric is None:
            metric = FisherMetric.gaussian(dim, distributions[0].chirality)
        
        # Initialize with arithmetic mean of parameters
        mean_params = np.mean([d.parameters for d in distributions], axis=0)
        
        # Iterative refinement (gradient descent on sum of squared distances)
        for _ in range(max_iter):
            gradient = np.zeros(dim)
            for d in distributions:
                diff = d.parameters - mean_params
                gradient += metric.metric_tensor() @ diff
            gradient /= len(distributions)
            
            new_params = mean_params + 0.1 * gradient
            
            if np.linalg.norm(new_params - mean_params) < tol:
                break
            mean_params = new_params
        
        # Determine result chirality (majority vote)
        chiralities = [d.chirality for d in distributions]
        result_chirality = max(set(chiralities), key=chiralities.count)
        
        return ChiralDistribution(mean_params, result_chirality)
    
    @staticmethod
    def geometric_variance(distributions: List[ChiralDistribution],
                           mean: Optional[ChiralDistribution] = None,
                           metric: Optional[FisherMetric] = None) -> float:
        """Compute geometric variance around mean."""
        if not distributions:
            return 0.0
        
        if mean is None:
            mean = GeometricStatistics.frechet_mean(distributions, metric)
        
        if metric is None:
            metric = FisherMetric.gaussian(mean.dimension, mean.chirality)
        
        total_var = 0.0
        for d in distributions:
            dist_sq = metric.geodesic_distance(mean.parameters, d.parameters) ** 2
            total_var += dist_sq
        
        return total_var / len(distributions)
    
    @staticmethod
    def geodesic_interpolation(p: ChiralDistribution, q: ChiralDistribution,
                               t: float) -> ChiralDistribution:
        """Geodesic interpolation between distributions."""
        t = np.clip(t, 0.0, 1.0)
        interp_params = (1 - t) * p.parameters + t * q.parameters
        
        # Chirality transition
        if t < 0.5:
            chirality = p.chirality
        elif t > 0.5:
            chirality = q.chirality
        else:
            chirality = Chirality.NEUTRAL
        
        return ChiralDistribution(interp_params, chirality)
    
    @staticmethod
    def parallel_transport(vector: np.ndarray, path_start: np.ndarray,
                           path_end: np.ndarray, 
                           metric: FisherMetric) -> np.ndarray:
        """Parallel transport vector along geodesic.
        
        For flat metrics, parallel transport preserves the vector.
        """
        # For constant (flat) metric, parallel transport is identity
        return vector.copy()
    
    @staticmethod  
    def exponential_map(base: ChiralDistribution, tangent: np.ndarray,
                        metric: Optional[FisherMetric] = None) -> ChiralDistribution:
        """Exponential map from tangent space."""
        # For flat geometry, exp map is just addition
        new_params = base.parameters + tangent
        return ChiralDistribution(new_params, base.chirality)
    
    @staticmethod
    def logarithmic_map(base: ChiralDistribution, point: ChiralDistribution,
                        metric: Optional[FisherMetric] = None) -> np.ndarray:
        """Logarithmic map to tangent space."""
        # For flat geometry, log map is subtraction
        return point.parameters - base.parameters
    
    @staticmethod
    def natural_gradient(distribution: ChiralDistribution,
                         euclidean_gradient: np.ndarray,
                         metric: Optional[FisherMetric] = None) -> np.ndarray:
        """Compute natural gradient from Euclidean gradient.
        
        Natural gradient = G^{-1} @ euclidean_gradient
        where G is the Fisher information matrix.
        """
        if metric is None:
            metric = FisherMetric.gaussian(distribution.dimension, distribution.chirality)
        
        g_inv = np.linalg.inv(metric.metric_tensor())
        return g_inv @ euclidean_gradient


@dataclass
class ChiralExponentialFamily:
    """Exponential family with chiral structure.
    
    p(x|theta) = exp(theta . T(x) - A(theta)) h(x)
    """
    natural_parameters: np.ndarray  # theta
    sufficient_stats: Callable[[np.ndarray], np.ndarray]  # T(x)
    log_partition: Callable[[np.ndarray], float]  # A(theta)
    base_measure: Callable[[np.ndarray], float]  # h(x)
    chirality: Chirality = Chirality.NEUTRAL
    
    def log_density(self, x: np.ndarray) -> float:
        """Log density at x."""
        return (np.dot(self.natural_parameters, self.sufficient_stats(x)) - 
                self.log_partition(self.natural_parameters) + 
                np.log(max(self.base_measure(x), 1e-300)))
    
    def density(self, x: np.ndarray) -> float:
        """Density at x."""
        return np.exp(self.log_density(x))
    
    def expected_sufficient_stats(self, n_samples: int = 1000) -> np.ndarray:
        """E[T(x)] = gradient of log partition."""
        # Numerical gradient
        eps = 1e-5
        dim = len(self.natural_parameters)
        grad = np.zeros(dim)
        
        for i in range(dim):
            theta_plus = self.natural_parameters.copy()
            theta_plus[i] += eps
            theta_minus = self.natural_parameters.copy()
            theta_minus[i] -= eps
            grad[i] = (self.log_partition(theta_plus) - self.log_partition(theta_minus)) / (2 * eps)
        
        return grad
    
    def to_distribution(self) -> ChiralDistribution:
        """Convert to ChiralDistribution."""
        return ChiralDistribution(
            parameters=self.natural_parameters.copy(),
            chirality=self.chirality,
            log_density=self.log_density
        )
    
    def fisher_metric(self) -> FisherMetric:
        """Compute Fisher metric (Hessian of log partition)."""
        eps = 1e-5
        dim = len(self.natural_parameters)
        hessian = np.zeros((dim, dim))
        
        for i in range(dim):
            for j in range(i, dim):
                theta_pp = self.natural_parameters.copy()
                theta_pp[i] += eps
                theta_pp[j] += eps
                
                theta_pm = self.natural_parameters.copy()
                theta_pm[i] += eps
                theta_pm[j] -= eps
                
                theta_mp = self.natural_parameters.copy()
                theta_mp[i] -= eps
                theta_mp[j] += eps
                
                theta_mm = self.natural_parameters.copy()
                theta_mm[i] -= eps
                theta_mm[j] -= eps
                
                hessian[i, j] = (self.log_partition(theta_pp) - 
                                 self.log_partition(theta_pm) - 
                                 self.log_partition(theta_mp) + 
                                 self.log_partition(theta_mm)) / (4 * eps * eps)
                hessian[j, i] = hessian[i, j]
        
        # Ensure positive definiteness
        min_eig = np.min(np.linalg.eigvalsh(hessian))
        if min_eig < 1e-10:
            hessian += (1e-10 - min_eig) * np.eye(dim)
        
        metric = FisherMetric(dimension=dim, chirality=self.chirality)
        metric._metric_matrix = hessian
        return metric


def create_gaussian_exponential_family(mean: float, variance: float,
                                       chirality: Chirality = Chirality.NEUTRAL) -> ChiralExponentialFamily:
    """Create Gaussian as exponential family."""
    # Natural parameters: theta1 = mu/sigma^2, theta2 = -1/(2*sigma^2)
    theta1 = mean / variance
    theta2 = -1 / (2 * variance)
    
    def sufficient_stats(x: np.ndarray) -> np.ndarray:
        return np.array([x[0], x[0]**2]) if len(x) > 0 else np.array([0, 0])
    
    def log_partition(theta: np.ndarray) -> float:
        if theta[1] >= 0:
            return float('inf')
        return -theta[0]**2 / (4 * theta[1]) + 0.5 * np.log(-np.pi / theta[1])
    
    def base_measure(x: np.ndarray) -> float:
        return 1.0
    
    return ChiralExponentialFamily(
        natural_parameters=np.array([theta1, theta2]),
        sufficient_stats=sufficient_stats,
        log_partition=log_partition,
        base_measure=base_measure,
        chirality=chirality
    )
