"""SpiralLLM-Math Optimal Transport Reasoner for §8.

Specialized reasoning capabilities for optimal transport:
- Wasserstein distance computation
- Optimal coupling analysis
- Barycenter computation
- Displacement interpolation
- Transport map verification
"""

from typing import Any, Dict, List, Optional
import numpy as np

from .spiral_llm_math import MathematicalProblem, SpiralLLMMath, Solution, ReasoningStep
from .optimal_transport import (
    ChiralMeasure, ChiralCoupling, WassersteinDistance, ChiralBarycenter,
    DisplacementInterpolation, OptimalTransportMap,
    create_uniform_measure, create_weighted_measure, compute_wasserstein_geodesic
)
from .chiral_base import ChiralObject, Chirality


class OptimalTransportReasoner:
    """Specialized reasoner for optimal transport problems.
    
    Provides reasoning capabilities for:
    - Wasserstein distance computation
    - Optimal coupling construction
    - Barycenter problems
    - Geodesic interpolation
    - Transport map analysis
    """

    def __init__(self, spiral_engine: Optional[SpiralLLMMath] = None):
        """Initialize optimal transport reasoner.
        
        Args:
            spiral_engine: SpiralLLM-Math engine to register with
        """
        self.spiral_engine = spiral_engine
        if spiral_engine:
            spiral_engine.register_reasoner('optimal_transport', self.solve_optimal_transport)
            spiral_engine.register_reasoner('wasserstein', self.solve_wasserstein)
            spiral_engine.register_reasoner('barycenter', self.solve_barycenter)
            spiral_engine.register_reasoner('displacement_interpolation', self.solve_displacement_interpolation)
            spiral_engine.register_verifier('optimal_transport', self.verify_optimal_transport)

    def solve_optimal_transport(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Solve a general optimal transport problem.
        
        Args:
            problem: Problem with optimal transport data
            
        Returns:
            Solution data
        """
        operation = problem.input_data.get('operation', 'compute_distance')
        
        if operation == 'compute_distance':
            return self._compute_wasserstein_distance(problem)
        elif operation == 'compute_coupling':
            return self._compute_optimal_coupling(problem)
        elif operation == 'interpolate':
            return self._interpolate_measures(problem)
        elif operation == 'compute_barycenter':
            return self._compute_barycenter(problem)
        elif operation == 'analyze_coupling':
            return self._analyze_coupling(problem)
        else:
            return {'error': f'Unknown operation: {operation}'}

    def solve_wasserstein(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Solve Wasserstein distance problem.
        
        Args:
            problem: Problem with two measures
            
        Returns:
            Wasserstein distance analysis
        """
        source = problem.input_data.get('source')
        target = problem.input_data.get('target')
        p = problem.input_data.get('p', 2.0)
        chirality_penalty = problem.input_data.get('chirality_penalty', 1.0)
        
        if not isinstance(source, ChiralMeasure) or not isinstance(target, ChiralMeasure):
            return {'error': 'Invalid measures provided'}
        
        # Compute Wasserstein distance
        wasserstein = WassersteinDistance(p=p, chirality_penalty=chirality_penalty)
        distance = wasserstein.distance(source, target)
        
        # Get optimal coupling
        coupling = wasserstein.compute_optimal_coupling(source, target)
        
        # Analyze chirality effects
        chirality_analysis = self._analyze_chirality_effect(source, target, chirality_penalty)
        
        # Cost matrix analysis
        cost_matrix = wasserstein.compute_cost_matrix(source, target)
        
        return {
            'wasserstein_distance': distance,
            'p': p,
            'chirality_penalty': chirality_penalty,
            'coupling': coupling,
            'is_deterministic': coupling.is_deterministic(),
            'transport_cost': coupling.transport_cost(cost_matrix),
            'chirality_analysis': chirality_analysis,
            'source_chirality': source.mean_chirality().name,
            'target_chirality': target.mean_chirality().name,
            'explanation': self._explain_wasserstein_distance(distance, p, source, target)
        }

    def solve_barycenter(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Solve Wasserstein barycenter problem.
        
        Args:
            problem: Problem with multiple measures
            
        Returns:
            Barycenter analysis
        """
        measures = problem.input_data.get('measures')
        weights = problem.input_data.get('weights')
        n_support = problem.input_data.get('n_support', 5)
        p = problem.input_data.get('p', 2.0)
        
        if not isinstance(measures, list) or not all(isinstance(m, ChiralMeasure) for m in measures):
            return {'error': 'Invalid measures provided'}
        
        # Compute barycenter
        barycenter_computer = ChiralBarycenter(measures, weights, p)
        barycenter_measure = barycenter_computer.compute_barycenter(n_support)
        
        # Analyze result
        barycenter_location = barycenter_measure.barycenter_location()
        chirality_dist = self._analyze_barycenter_chirality(measures, weights)
        
        return {
            'barycenter': barycenter_measure,
            'n_support': n_support,
            'barycentric_weights': barycenter_computer.weights.tolist(),
            'barycenter_location': barycenter_location.tolist(),
            'mean_chirality': barycenter_measure.mean_chirality().name,
            'chirality_distribution': chirality_dist,
            'n_input_measures': len(measures),
            'explanation': self._explain_barycenter(barycenter_measure, measures, weights)
        }

    def solve_displacement_interpolation(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Solve displacement interpolation problem.
        
        Args:
            problem: Problem with source/target and interpolation parameter
            
        Returns:
            Interpolation analysis
        """
        source = problem.input_data.get('source')
        target = problem.input_data.get('target')
        t = problem.input_data.get('t', 0.5)
        n_points = problem.input_data.get('n_points', 10)
        
        if not isinstance(source, ChiralMeasure) or not isinstance(target, ChiralMeasure):
            return {'error': 'Invalid measures provided'}
        
        # Create interpolator
        interpolator = DisplacementInterpolation(source, target)
        
        # Compute geodesic
        if n_points > 0:
            geodesic = compute_wasserstein_geodesic(source, target, n_points)
        else:
            geodesic = None
        
        # Interpolate at specific t
        interpolated = interpolator.interpolate(t)
        
        # Analyze path
        path_analysis = self._analyze_geodesic_path(geodesic) if geodesic else {}
        
        return {
            'source': source,
            'target': target,
            't': t,
            'interpolated_measure': interpolated,
            'interpolated_location': interpolated.barycenter_location().tolist(),
            'interpolated_chirality': interpolated.mean_chirality().name,
            'geodesic_points': n_points,
            'geodesic': geodesic,
            'path_analysis': path_analysis,
            'coupling_deterministic': interpolator.coupling.is_deterministic(),
            'explanation': self._explain_displacement_interpolation(t, source, target, interpolated)
        }

    def _compute_wasserstein_distance(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Compute Wasserstein distance between two measures."""
        source = problem.input_data.get('source')
        target = problem.input_data.get('target')
        p = problem.input_data.get('p', 2.0)
        chirality_penalty = problem.input_data.get('chirality_penalty', 1.0)
        
        wasserstein = WassersteinDistance(p=p, chirality_penalty=chirality_penalty)
        distance = wasserstein.distance(source, target)
        
        return {
            'distance': distance,
            'p': p,
            'chirality_penalty': chirality_penalty,
            'source_support_size': source.n_support,
            'target_support_size': target.n_support,
        }

    def _compute_optimal_coupling(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Compute optimal coupling between measures."""
        source = problem.input_data.get('source')
        target = problem.input_data.get('target')
        p = problem.input_data.get('p', 2.0)
        
        wasserstein = WassersteinDistance(p=p)
        coupling = wasserstein.compute_optimal_coupling(source, target)
        
        cost_matrix = wasserstein.compute_cost_matrix(source, target)
        transport_cost = coupling.transport_cost(cost_matrix)
        
        return {
            'coupling': coupling,
            'is_deterministic': coupling.is_deterministic(),
            'transport_cost': transport_cost,
            'plan_shape': coupling.plan.shape,
            'plan_sparsity': np.sum(coupling.plan > 1e-6) / coupling.plan.size,
        }

    def _interpolate_measures(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Interpolate between two measures."""
        source = problem.input_data.get('source')
        target = problem.input_data.get('target')
        t = problem.input_data.get('t', 0.5)
        
        interpolator = DisplacementInterpolation(source, target)
        interpolated = interpolator.interpolate(t)
        
        return {
            't': t,
            'interpolated': interpolated,
            'n_support': interpolated.n_support,
            'mean_chirality': interpolated.mean_chirality().name,
        }

    def _compute_barycenter(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Compute Wasserstein barycenter of multiple measures."""
        measures = problem.input_data.get('measures')
        weights = problem.input_data.get('weights')
        n_support = problem.input_data.get('n_support', 5)
        
        barycenter_computer = ChiralBarycenter(measures, weights)
        result = barycenter_computer.compute_barycenter(n_support)
        
        return {
            'barycenter': result,
            'n_measures': len(measures),
            'n_support': n_support,
        }

    def _analyze_coupling(self, problem: MathematicalProblem) -> Dict[str, Any]:
        """Analyze properties of a coupling."""
        coupling = problem.input_data.get('coupling')
        
        if not isinstance(coupling, ChiralCoupling):
            return {'error': 'Invalid coupling'}
        
        # Verify marginals
        source_marginal = coupling.plan.sum(axis=1)
        target_marginal = coupling.plan.sum(axis=0)
        
        source_valid = np.allclose(source_marginal, coupling.source.weights)
        target_valid = np.allclose(target_marginal, coupling.target.weights)
        
        return {
            'is_deterministic': coupling.is_deterministic(),
            'source_marginal_valid': source_valid,
            'target_marginal_valid': target_valid,
            'plan_sparsity': np.sum(coupling.plan > 1e-6) / coupling.plan.size,
            'max_transport_weight': np.max(coupling.plan),
        }

    def _analyze_chirality_effect(self, source: ChiralMeasure, target: ChiralMeasure, 
                                  penalty: float) -> Dict[str, Any]:
        """Analyze effect of chirality on transport."""
        # Count chirality mismatches
        n_mismatches = 0
        n_total = 0
        
        for obj_s in source.support:
            for obj_t in target.support:
                n_total += 1
                if obj_s.chirality != obj_t.chirality:
                    n_mismatches += 1
        
        mismatch_rate = n_mismatches / n_total if n_total > 0 else 0
        expected_penalty_contribution = mismatch_rate * penalty
        
        return {
            'n_total_pairs': n_total,
            'n_chirality_mismatches': n_mismatches,
            'mismatch_rate': mismatch_rate,
            'chirality_penalty': penalty,
            'expected_penalty_contribution': expected_penalty_contribution,
        }

    def _analyze_barycenter_chirality(self, measures: List[ChiralMeasure], 
                                     weights: Optional[np.ndarray]) -> Dict[str, Any]:
        """Analyze chirality distribution in barycenter computation."""
        if weights is None:
            weights = np.ones(len(measures)) / len(measures)
        
        chirality_weights = {Chirality.LEFT: 0.0, Chirality.NEUTRAL: 0.0, Chirality.RIGHT: 0.0}
        
        for measure, weight in zip(measures, weights):
            for obj in measure.support:
                chirality_weights[obj.chirality] += weight / measure.n_support
        
        return {k.name: v for k, v in chirality_weights.items()}

    def _analyze_geodesic_path(self, geodesic: List[ChiralMeasure]) -> Dict[str, Any]:
        """Analyze properties along geodesic path."""
        if not geodesic:
            return {}
        
        # Track chirality evolution
        chiralities = [m.mean_chirality().name for m in geodesic]
        
        # Track barycenter movement
        locations = [m.barycenter_location() for m in geodesic]
        
        # Compute path length (approximate)
        path_length = 0.0
        for i in range(len(locations) - 1):
            path_length += np.linalg.norm(locations[i+1] - locations[i])
        
        return {
            'n_points': len(geodesic),
            'chirality_evolution': chiralities,
            'approximate_path_length': path_length,
            'start_location': locations[0].tolist(),
            'end_location': locations[-1].tolist(),
        }

    def _explain_wasserstein_distance(self, distance: float, p: float, 
                                     source: ChiralMeasure, target: ChiralMeasure) -> str:
        """Generate explanation of Wasserstein distance."""
        explanation = f"The {p}-Wasserstein distance between the measures is {distance:.4f}. "
        
        explanation += f"This represents the optimal cost of transporting mass from "
        explanation += f"source (with {source.n_support} support points, "
        explanation += f"chirality {source.mean_chirality().name}) "
        explanation += f"to target (with {target.n_support} support points, "
        explanation += f"chirality {target.mean_chirality().name}). "
        
        if source.mean_chirality() != target.mean_chirality():
            explanation += "The chirality mismatch contributes additional penalty to the distance."
        
        return explanation

    def _explain_barycenter(self, barycenter: ChiralMeasure, 
                           measures: List[ChiralMeasure],
                           weights: Optional[np.ndarray]) -> str:
        """Generate explanation of barycenter."""
        if weights is None:
            weights = np.ones(len(measures)) / len(measures)
        
        explanation = f"The Wasserstein barycenter combines {len(measures)} measures "
        explanation += f"with weights {weights.tolist()}. "
        explanation += f"The resulting barycenter has {barycenter.n_support} support points "
        explanation += f"and overall chirality {barycenter.mean_chirality().name}. "
        
        return explanation

    def _explain_displacement_interpolation(self, t: float, source: ChiralMeasure, 
                                           target: ChiralMeasure, 
                                           interpolated: ChiralMeasure) -> str:
        """Generate explanation of displacement interpolation."""
        explanation = f"At interpolation parameter t={t:.2f}, the displacement interpolation "
        explanation += f"between source and target produces a measure with "
        explanation += f"{interpolated.n_support} support points. "
        
        if t < 0.5:
            explanation += f"Since t < 0.5, the interpolated measure is closer to the source "
            explanation += f"(chirality: {source.mean_chirality().name})."
        elif t > 0.5:
            explanation += f"Since t > 0.5, the interpolated measure is closer to the target "
            explanation += f"(chirality: {target.mean_chirality().name})."
        else:
            explanation += "At t = 0.5, the measure is at the midpoint of the Wasserstein geodesic."
        
        return explanation

    def verify_optimal_transport(self, problem: MathematicalProblem, 
                                result: Dict[str, Any]) -> Dict[str, Any]:
        """Verify optimal transport computation results.
        
        Args:
            problem: Original problem
            result: Solution result
            
        Returns:
            Verification results
        """
        checks = []
        
        # Check coupling marginals
        if 'coupling' in result:
            coupling = result['coupling']
            if isinstance(coupling, ChiralCoupling):
                source_marginal = coupling.plan.sum(axis=1)
                target_marginal = coupling.plan.sum(axis=0)
                
                source_valid = np.allclose(source_marginal, coupling.source.weights)
                target_valid = np.allclose(target_marginal, coupling.target.weights)
                
                checks.append({
                    'name': 'coupling_marginals',
                    'passed': source_valid and target_valid,
                    'message': 'Coupling satisfies marginal constraints' if (source_valid and target_valid)
                              else 'Coupling violates marginal constraints'
                })
        
        # Check Wasserstein distance non-negativity
        if 'wasserstein_distance' in result:
            distance = result['wasserstein_distance']
            checks.append({
                'name': 'distance_non_negative',
                'passed': distance >= 0,
                'message': f'Wasserstein distance is non-negative: {distance:.4f}' if distance >= 0
                          else f'Invalid negative distance: {distance:.4f}'
            })
        
        # Check interpolation parameter range
        if 't' in result:
            t = result['t']
            t_valid = 0 <= t <= 1
            checks.append({
                'name': 'interpolation_parameter_valid',
                'passed': t_valid,
                'message': f'Interpolation parameter t={t:.2f} is in [0,1]' if t_valid
                          else f'Invalid interpolation parameter t={t:.2f}'
            })
        
        # Check measure mass conservation
        if 'interpolated_measure' in result:
            measure = result['interpolated_measure']
            if isinstance(measure, ChiralMeasure):
                mass_conserved = np.isclose(measure.weights.sum(), 1.0)
                checks.append({
                    'name': 'mass_conservation',
                    'passed': mass_conserved,
                    'message': 'Total mass is conserved (equals 1)' if mass_conserved
                              else f'Mass not conserved: {measure.weights.sum():.4f}'
                })
        
        return {
            'checks': checks,
            'all_passed': all(c['passed'] for c in checks),
            'n_checks': len(checks),
            'n_passed': sum(c['passed'] for c in checks)
        }
