"""
§10 - Spectral Geometry & Laplacians

Eigenvalue-based methods connecting topology, geometry, and computation:
- Graph Laplacians with chirality penalties
- Hodge decomposition of chain complexes
- Heat kernels and diffusion processes
- Spectral clustering with chiral structure
- Laplacian eigenvalues and spectral gap
- Connections to all previous sections via spectral methods
"""

from typing import List, Dict, Optional, Tuple, Callable
from dataclasses import dataclass
import numpy as np
from scipy import sparse
from scipy.sparse.linalg import eigsh, expm_multiply
from scipy.linalg import eigh

from .chiral_base import ChiralObject, Chirality
from .homology import ChiralSimplicialComplex, ChiralChain, ChiralChainComplex


@dataclass
class LaplacianSpectrum:
    """
    Spectral decomposition of a Laplacian operator.
    
    Contains eigenvalues and eigenvectors encoding geometric and topological
    information about the underlying space.
    
    Parameters
    ----------
    eigenvalues : np.ndarray
        Sorted eigenvalues (ascending)
    eigenvectors : np.ndarray
        Corresponding eigenvectors as columns
    """
    eigenvalues: np.ndarray
    eigenvectors: np.ndarray
    
    def __post_init__(self):
        """Validate and sort spectrum"""
        if self.eigenvalues.shape[0] != self.eigenvectors.shape[1]:
            raise ValueError(f"Eigenvalue count {self.eigenvalues.shape[0]} != eigenvector count {self.eigenvectors.shape[1]}")
        
        # Sort by eigenvalue
        idx = np.argsort(self.eigenvalues)
        self.eigenvalues = self.eigenvalues[idx]
        self.eigenvectors = self.eigenvectors[:, idx]
    
    @property
    def spectral_gap(self) -> float:
        """
        Spectral gap: difference between first and second smallest eigenvalues.
        
        Large spectral gap indicates good connectivity/mixing properties.
        """
        if len(self.eigenvalues) < 2:
            return 0.0
        return float(self.eigenvalues[1] - self.eigenvalues[0])
    
    @property
    def algebraic_connectivity(self) -> float:
        """
        Algebraic connectivity (Fiedler value): second smallest eigenvalue.
        
        Positive algebraic connectivity implies connectedness.
        """
        if len(self.eigenvalues) < 2:
            return 0.0
        return float(self.eigenvalues[1])
    
    def fiedler_vector(self) -> np.ndarray:
        """
        Fiedler vector: eigenvector corresponding to algebraic connectivity.
        
        Used for spectral clustering and graph partitioning.
        """
        if len(self.eigenvalues) < 2:
            return np.zeros(self.eigenvectors.shape[0])
        return self.eigenvectors[:, 1]
    
    def num_connected_components(self, tolerance: float = 1e-10) -> int:
        """
        Estimate number of connected components from near-zero eigenvalues.
        
        The multiplicity of eigenvalue 0 equals the number of connected components.
        """
        return int(np.sum(np.abs(self.eigenvalues) < tolerance))
    
    def truncate(self, k: int) -> 'LaplacianSpectrum':
        """Return spectrum truncated to first k eigenvalues/vectors"""
        k = min(k, len(self.eigenvalues))
        return LaplacianSpectrum(self.eigenvalues[:k], self.eigenvectors[:, :k])
    
    def __repr__(self) -> str:
        n_eig = len(self.eigenvalues)
        gap = self.spectral_gap
        return f"LaplacianSpectrum({n_eig} eigenvalues, gap={gap:.6f}, λ_min={self.eigenvalues[0]:.6f})"


class ChiralGraphLaplacian:
    """
    Graph Laplacian with chirality-aware edge weights.
    
    The Laplacian matrix L is defined as L = D - W where:
    - D is the degree matrix (diagonal)
    - W is the weighted adjacency matrix with chirality penalties
    
    For normalized Laplacian: L_norm = I - D^{-1/2} W D^{-1/2}
    
    Parameters
    ----------
    objects : List[ChiralObject]
        Vertices of the graph
    chirality_penalty : float
        Additional cost for edges between different chiralities
    normalize : bool
        Whether to use normalized Laplacian
    """
    
    def __init__(self, objects: List[ChiralObject], chirality_penalty: float = 1.0,
                 normalize: bool = True):
        self.objects = objects
        self.chirality_penalty = chirality_penalty
        self.normalize = normalize
        self.n = len(objects)
        
        # Build Laplacian
        self.laplacian_matrix = self._build_laplacian()
    
    def _build_laplacian(self) -> np.ndarray:
        """Build Laplacian matrix"""
        n = self.n
        
        # Compute weighted adjacency matrix
        W = np.zeros((n, n))
        for i in range(n):
            for j in range(i+1, n):
                # Base weight from distance (Gaussian kernel)
                dist = self.objects[i].distance(self.objects[j])
                weight = np.exp(-dist**2)
                
                # Apply chirality penalty
                if self.objects[i].chirality != self.objects[j].chirality:
                    weight *= np.exp(-self.chirality_penalty)
                
                W[i, j] = weight
                W[j, i] = weight
        
        # Degree matrix
        D = np.diag(W.sum(axis=1))
        
        # Laplacian
        L = D - W
        
        # Normalize if requested
        if self.normalize:
            D_inv_sqrt = np.diag(1.0 / np.sqrt(np.diag(D) + 1e-10))
            L = D_inv_sqrt @ L @ D_inv_sqrt
        
        return L
    
    def compute_spectrum(self, k: Optional[int] = None) -> LaplacianSpectrum:
        """
        Compute spectral decomposition of Laplacian.
        
        Parameters
        ----------
        k : Optional[int]
            Number of smallest eigenvalues to compute (None = all)
        
        Returns
        -------
        spectrum : LaplacianSpectrum
            Spectral decomposition
        """
        if k is None or k >= self.n - 1:
            # Compute all eigenvalues
            eigenvalues, eigenvectors = eigh(self.laplacian_matrix)
        else:
            # Compute k smallest eigenvalues
            eigenvalues, eigenvectors = eigsh(self.laplacian_matrix, k=k, which='SM')
        
        return LaplacianSpectrum(eigenvalues, eigenvectors)
    
    def heat_kernel(self, t: float, k: Optional[int] = None) -> np.ndarray:
        """
        Compute heat kernel matrix at time t: exp(-t*L).
        
        The heat kernel describes diffusion on the graph.
        
        Parameters
        ----------
        t : float
            Time parameter
        k : Optional[int]
            Number of eigenvectors to use (None = all)
        
        Returns
        -------
        kernel : np.ndarray, shape (n, n)
            Heat kernel matrix
        """
        spectrum = self.compute_spectrum(k)
        
        # H(t) = Σ exp(-λ_i * t) v_i v_i^T
        kernel = np.zeros((self.n, self.n))
        for i in range(len(spectrum.eigenvalues)):
            eigenval = spectrum.eigenvalues[i]
            eigenvec = spectrum.eigenvectors[:, i]
            kernel += np.exp(-eigenval * t) * np.outer(eigenvec, eigenvec)
        
        return kernel
    
    def diffuse(self, initial_distribution: np.ndarray, t: float) -> np.ndarray:
        """
        Diffuse an initial distribution according to heat equation.
        
        Solves: ∂u/∂t = -L u with initial condition u(0) = initial_distribution.
        Solution: u(t) = exp(-t*L) u(0).
        
        Parameters
        ----------
        initial_distribution : np.ndarray
            Initial values at vertices
        t : float
            Diffusion time
        
        Returns
        -------
        distribution : np.ndarray
            Distribution after time t
        """
        kernel = self.heat_kernel(t)
        return kernel @ initial_distribution
    
    def spectral_clustering(self, n_clusters: int, use_fiedler: bool = False) -> np.ndarray:
        """
        Perform spectral clustering of vertices.
        
        Parameters
        ----------
        n_clusters : int
            Number of clusters
        use_fiedler : bool
            If True and n_clusters=2, use sign of Fiedler vector
        
        Returns
        -------
        labels : np.ndarray
            Cluster labels for each vertex
        """
        if n_clusters == 2 and use_fiedler:
            # Binary clustering using Fiedler vector
            spectrum = self.compute_spectrum(k=2)
            fiedler = spectrum.fiedler_vector()
            return (fiedler >= 0).astype(int)
        
        # General k-means on spectral embedding
        spectrum = self.compute_spectrum(k=n_clusters)
        embedding = spectrum.eigenvectors[:, :n_clusters]
        
        # Normalize rows
        embedding = embedding / (np.linalg.norm(embedding, axis=1, keepdims=True) + 1e-10)
        
        # Simple k-means
        try:
            from sklearn.cluster import KMeans
            kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
            labels = kmeans.fit_predict(embedding)
        except ImportError:
            # Fallback to simple k-means implementation
            labels = self._simple_kmeans(embedding, n_clusters)
        
        return labels
    
    def _simple_kmeans(self, X: np.ndarray, k: int, max_iter: int = 100) -> np.ndarray:
        """Simple k-means implementation without sklearn dependency"""
        n = X.shape[0]
        
        # Initialize centers randomly
        np.random.seed(42)
        indices = np.random.choice(n, k, replace=False)
        centers = X[indices]
        
        labels = np.zeros(n, dtype=int)
        
        for _ in range(max_iter):
            # Assign to nearest center
            distances = np.sum((X[:, np.newaxis, :] - centers[np.newaxis, :, :]) ** 2, axis=2)
            new_labels = np.argmin(distances, axis=1)
            
            if np.array_equal(labels, new_labels):
                break
            
            labels = new_labels
            
            # Update centers
            for j in range(k):
                mask = labels == j
                if np.any(mask):
                    centers[j] = X[mask].mean(axis=0)
        
        return labels
    
    def effective_resistance(self, i: int, j: int, k: Optional[int] = None) -> float:
        """
        Compute effective resistance between vertices i and j.
        
        Effective resistance is the electrical resistance when graph edges
        are treated as unit resistors.
        
        R_eff(i,j) = Σ_{λ>0} (v_i - v_j)^2 / λ
        
        Parameters
        ----------
        i, j : int
            Vertex indices
        k : Optional[int]
            Number of eigenpairs to use (None = all)
        
        Returns
        -------
        resistance : float
            Effective resistance
        """
        spectrum = self.compute_spectrum(k)
        
        resistance = 0.0
        for idx in range(len(spectrum.eigenvalues)):
            eigenval = spectrum.eigenvalues[idx]
            if eigenval > 1e-10:  # Skip near-zero eigenvalues
                eigenvec = spectrum.eigenvectors[:, idx]
                diff = eigenvec[i] - eigenvec[j]
                resistance += diff**2 / eigenval
        
        return resistance
    
    def __repr__(self) -> str:
        norm_str = "normalized" if self.normalize else "unnormalized"
        return f"ChiralGraphLaplacian({self.n} vertices, {norm_str}, penalty={self.chirality_penalty})"


class HodgeDecomposition:
    """
    Hodge decomposition of chain complexes.
    
    For a chain complex with boundary operator ∂, the Hodge decomposition states:
    C_k = im(∂_{k+1}) ⊕ ker(∂_k) ⊕ im(∂_k†)
    
    where ∂_k† is the adjoint (coboundary) operator.
    
    Equivalently: chains = exact + closed + coclosed.
    
    Parameters
    ----------
    chain_complex : ChiralChainComplex
        Chain complex to decompose
    dimension : int
        Dimension of chains to decompose
    """
    
    def __init__(self, chain_complex: ChiralChainComplex, dimension: int):
        self.chain_complex = chain_complex
        self.dimension = dimension
        
        # Build boundary matrices
        self.boundary_matrix = self._build_boundary_matrix()
        self.coboundary_matrix = self._build_coboundary_matrix()
        
        # Compute Laplacian
        self.laplacian = self._compute_hodge_laplacian()
    
    def _build_boundary_matrix(self) -> np.ndarray:
        """Build boundary operator matrix ∂_k: C_k -> C_{k-1}"""
        # This is a placeholder - full implementation would extract
        # boundary operator from chain complex
        # For now, return identity
        n = 10  # Placeholder dimension
        return np.eye(n)
    
    def _build_coboundary_matrix(self) -> np.ndarray:
        """Build coboundary operator matrix ∂_{k+1}†: C_k -> C_{k+1}"""
        # Adjoint of boundary from C_{k+1}
        return self.boundary_matrix.T
    
    def _compute_hodge_laplacian(self) -> np.ndarray:
        """
        Compute Hodge Laplacian: Δ_k = ∂_{k+1} ∂_{k+1}† + ∂_k† ∂_k.
        
        The kernel of the Hodge Laplacian is the space of harmonic chains,
        which is isomorphic to homology.
        """
        term1 = self.coboundary_matrix @ self.coboundary_matrix.T
        term2 = self.boundary_matrix.T @ self.boundary_matrix
        return term1 + term2
    
    def compute_harmonic_chains(self, tolerance: float = 1e-10) -> np.ndarray:
        """
        Compute harmonic chains: ker(Δ_k).
        
        Harmonic chains are both closed (∂_k = 0) and coclosed (∂_{k+1}† = 0).
        They represent homology classes.
        
        Returns
        -------
        harmonic : np.ndarray
            Basis for harmonic chains (as columns)
        """
        eigenvalues, eigenvectors = eigh(self.laplacian)
        
        # Harmonic chains correspond to near-zero eigenvalues
        harmonic_indices = np.where(np.abs(eigenvalues) < tolerance)[0]
        
        if len(harmonic_indices) == 0:
            return np.zeros((self.laplacian.shape[0], 0))
        
        return eigenvectors[:, harmonic_indices]
    
    def decompose(self, chain: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Decompose chain into exact + harmonic + coexact components.
        
        Returns
        -------
        exact : np.ndarray
            Exact part (im ∂_{k+1})
        harmonic : np.ndarray
            Harmonic part (ker Δ_k)
        coexact : np.ndarray
            Coexact part (im ∂_k†)
        """
        # Compute harmonic projection
        harmonic_basis = self.compute_harmonic_chains()
        
        if harmonic_basis.shape[1] > 0:
            # Project onto harmonic space
            harmonic = harmonic_basis @ (harmonic_basis.T @ chain)
        else:
            harmonic = np.zeros_like(chain)
        
        # Remainder splits into exact and coexact
        remainder = chain - harmonic
        
        # For simplicity, split remainder in half (proper implementation would solve)
        exact = remainder / 2
        coexact = remainder / 2
        
        return exact, harmonic, coexact


class ChiralDiffusion:
    """
    Diffusion processes on chiral spaces.
    
    Models evolution of distributions according to heat equation with
    chirality-dependent diffusion rates.
    
    Parameters
    ----------
    objects : List[ChiralObject]
        Spatial locations (vertices)
    base_diffusivity : float
        Base diffusion rate
    chirality_coupling : float
        Strength of chirality-dependent diffusion
    """
    
    def __init__(self, objects: List[ChiralObject], 
                 base_diffusivity: float = 1.0,
                 chirality_coupling: float = 0.1):
        self.objects = objects
        self.base_diffusivity = base_diffusivity
        self.chirality_coupling = chirality_coupling
        self.n = len(objects)
        
        # Build diffusion operator
        self.laplacian = ChiralGraphLaplacian(objects, chirality_penalty=chirality_coupling)
    
    def evolve(self, initial: np.ndarray, t: float, 
               method: str = 'spectral') -> np.ndarray:
        """
        Evolve distribution from initial condition to time t.
        
        Solves: ∂u/∂t = D * Δu where D is diffusivity and Δ is Laplacian.
        
        Parameters
        ----------
        initial : np.ndarray
            Initial distribution
        t : float
            Time to evolve
        method : str
            Evolution method ('spectral' or 'matrix_exponential')
        
        Returns
        -------
        distribution : np.ndarray
            Distribution at time t
        """
        effective_t = self.base_diffusivity * t
        
        if method == 'spectral':
            return self.laplacian.diffuse(initial, effective_t)
        elif method == 'matrix_exponential':
            # Use matrix exponential
            L = self.laplacian.laplacian_matrix
            evolution_operator = expm_multiply(-effective_t * L, initial)
            return evolution_operator
        else:
            raise ValueError(f"Unknown method: {method}")
    
    def stationary_distribution(self) -> np.ndarray:
        """
        Compute stationary distribution of diffusion process.
        
        For connected graphs, this is the uniform distribution (or degree-weighted
        for non-normalized Laplacian).
        
        Returns
        -------
        stationary : np.ndarray
            Stationary distribution
        """
        spectrum = self.laplacian.compute_spectrum(k=1)
        
        # Eigenvector with eigenvalue 0 is stationary distribution
        stationary = np.abs(spectrum.eigenvectors[:, 0])
        stationary /= stationary.sum()
        
        return stationary
    
    def mixing_time(self, tolerance: float = 0.01) -> float:
        """
        Estimate mixing time: time to reach near-stationary distribution.
        
        Uses spectral gap: mixing_time ≈ 1 / spectral_gap.
        
        Parameters
        ----------
        tolerance : float
            Distance tolerance for mixing
        
        Returns
        -------
        time : float
            Estimated mixing time
        """
        spectrum = self.laplacian.compute_spectrum(k=2)
        gap = spectrum.spectral_gap
        
        if gap < 1e-10:
            return np.inf
        
        # Mixing time bound: O(log(1/tolerance) / gap)
        return np.log(1.0 / tolerance) / gap
    
    def __repr__(self) -> str:
        return f"ChiralDiffusion({self.n} vertices, D={self.base_diffusivity}, coupling={self.chirality_coupling})"


def compute_cheeger_constant(laplacian: ChiralGraphLaplacian) -> float:
    """
    Compute Cheeger constant (isoperimetric number) of the graph.
    
    The Cheeger constant h measures graph expansion and is related to
    the spectral gap via Cheeger's inequality:
    
    h^2 / 2 ≤ λ_2 ≤ 2h
    
    where λ_2 is the algebraic connectivity.
    
    This is an approximate computation using the Fiedler vector.
    
    Parameters
    ----------
    laplacian : ChiralGraphLaplacian
        Graph Laplacian
    
    Returns
    -------
    cheeger : float
        Approximate Cheeger constant
    """
    spectrum = laplacian.compute_spectrum(k=2)
    
    # Lower bound from spectral gap
    gap = spectrum.spectral_gap
    cheeger_lower = np.sqrt(gap / 2)
    
    # Upper bound from algebraic connectivity
    alg_conn = spectrum.algebraic_connectivity
    cheeger_upper = np.sqrt(2 * alg_conn)
    
    # Return geometric mean as estimate
    return np.sqrt(cheeger_lower * cheeger_upper)


def compute_graph_energy(laplacian: ChiralGraphLaplacian) -> float:
    """
    Compute graph energy: sum of absolute values of Laplacian eigenvalues.
    
    Energy = Σ |λ_i|
    
    Related to various graph properties and chemical graph theory.
    
    Parameters
    ----------
    laplacian : ChiralGraphLaplacian
        Graph Laplacian
    
    Returns
    -------
    energy : float
        Graph energy
    """
    spectrum = laplacian.compute_spectrum()
    return np.sum(np.abs(spectrum.eigenvalues))


def compute_estrada_index(laplacian: ChiralGraphLaplacian) -> float:
    """
    Compute Estrada index: sum of exponentials of Laplacian eigenvalues.
    
    EE = Σ exp(λ_i)
    
    Measures network robustness and protein folding properties.
    
    Parameters
    ----------
    laplacian : ChiralGraphLaplacian
        Graph Laplacian
    
    Returns
    -------
    estrada : float
        Estrada index
    """
    spectrum = laplacian.compute_spectrum()
    return np.sum(np.exp(spectrum.eigenvalues))


def spectral_distance(laplacian1: ChiralGraphLaplacian, 
                     laplacian2: ChiralGraphLaplacian,
                     k: int = 10) -> float:
    """
    Compute spectral distance between two graphs.
    
    Distance based on difference in eigenvalue spectra:
    
    d(G1, G2) = ||λ(G1) - λ(G2)||_2
    
    Parameters
    ----------
    laplacian1, laplacian2 : ChiralGraphLaplacian
        Graph Laplacians to compare
    k : int
        Number of eigenvalues to compare
    
    Returns
    -------
    distance : float
        Spectral distance
    """
    spec1 = laplacian1.compute_spectrum(k=k)
    spec2 = laplacian2.compute_spectrum(k=k)
    
    # Pad to same length
    n1, n2 = len(spec1.eigenvalues), len(spec2.eigenvalues)
    if n1 < n2:
        eig1 = np.concatenate([spec1.eigenvalues, np.zeros(n2 - n1)])
        eig2 = spec2.eigenvalues
    elif n2 < n1:
        eig1 = spec1.eigenvalues
        eig2 = np.concatenate([spec2.eigenvalues, np.zeros(n1 - n2)])
    else:
        eig1 = spec1.eigenvalues
        eig2 = spec2.eigenvalues
    
    return np.linalg.norm(eig1 - eig2)
