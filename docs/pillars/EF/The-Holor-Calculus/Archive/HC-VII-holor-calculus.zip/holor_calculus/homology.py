"""
§7 - Chiral Homology Theory

Algebraic topology structures on chiral spaces:
- Chain complexes with chiral structure
- Homology groups with chirality-aware boundaries
- Simplicial complexes with chiral vertices
- Betti numbers and Euler characteristic
"""

from typing import List, Dict, Optional, Tuple, Set
from dataclasses import dataclass
import numpy as np
from enum import Enum

from .chiral_base import ChiralObject, Chirality


class SimplexOrientation(Enum):
    """Orientation of a simplex"""
    POSITIVE = 1
    NEGATIVE = -1
    
    def __neg__(self):
        return SimplexOrientation.POSITIVE if self == SimplexOrientation.NEGATIVE else SimplexOrientation.NEGATIVE
    
    def __mul__(self, other: 'SimplexOrientation') -> 'SimplexOrientation':
        return SimplexOrientation.POSITIVE if self.value * other.value > 0 else SimplexOrientation.NEGATIVE


@dataclass(frozen=True)
class ChiralSimplex:
    """
    Oriented simplex with chiral vertices.
    
    A k-simplex is defined by (k+1) vertices with orientation.
    Chirality is determined by the vertices.
    """
    vertices: Tuple[int, ...]  # Indices of vertices
    orientation: SimplexOrientation = SimplexOrientation.POSITIVE
    
    def __post_init__(self):
        # Ensure vertices are sorted for canonical representation
        if self.vertices != tuple(sorted(self.vertices)):
            # Count inversions to determine orientation change
            inversions = sum(1 for i in range(len(self.vertices)) 
                           for j in range(i+1, len(self.vertices)) 
                           if self.vertices[i] > self.vertices[j])
            new_orientation = self.orientation if inversions % 2 == 0 else -self.orientation
            object.__setattr__(self, 'vertices', tuple(sorted(self.vertices)))
            object.__setattr__(self, 'orientation', new_orientation)
    
    @property
    def dimension(self) -> int:
        """Dimension of the simplex (k for k-simplex)"""
        return len(self.vertices) - 1
    
    def __neg__(self) -> 'ChiralSimplex':
        """Negate orientation"""
        return ChiralSimplex(self.vertices, -self.orientation)
    
    def __eq__(self, other) -> bool:
        if not isinstance(other, ChiralSimplex):
            return False
        return self.vertices == other.vertices and self.orientation == other.orientation
    
    def __hash__(self) -> int:
        return hash((self.vertices, self.orientation))
    
    def boundary_faces(self) -> List['ChiralSimplex']:
        """
        Compute boundary as list of (k-1)-simplices with alternating signs.
        
        For a k-simplex [v0, v1, ..., vk], the boundary is:
        Σ (-1)^i [v0, ..., v_{i-1}, v_{i+1}, ..., vk]
        """
        if self.dimension == 0:
            return []
        
        faces = []
        for i in range(len(self.vertices)):
            # Remove i-th vertex
            face_vertices = self.vertices[:i] + self.vertices[i+1:]
            # Alternating sign
            face_orientation = self.orientation if i % 2 == 0 else -self.orientation
            faces.append(ChiralSimplex(face_vertices, face_orientation))
        
        return faces


class ChiralChain:
    """
    Formal sum of simplices with coefficients.
    
    Represents an element of a chain group: Σ c_i σ_i
    where c_i are coefficients and σ_i are simplices.
    """
    
    def __init__(self, simplices: Dict[ChiralSimplex, float]):
        """
        Initialize chain from simplex -> coefficient mapping.
        
        Args:
            simplices: Dictionary mapping simplices to their coefficients
        """
        # Remove zero coefficients
        self.simplices = {s: c for s, c in simplices.items() if abs(c) > 1e-10}
    
    @property
    def dimension(self) -> Optional[int]:
        """Dimension of the chain (all simplices must have same dimension)"""
        if not self.simplices:
            return None
        dims = {s.dimension for s in self.simplices.keys()}
        if len(dims) > 1:
            raise ValueError("Chain contains simplices of different dimensions")
        return next(iter(dims))
    
    def is_zero(self) -> bool:
        """Check if chain is zero"""
        return len(self.simplices) == 0
    
    def __add__(self, other: 'ChiralChain') -> 'ChiralChain':
        """Add chains"""
        result = dict(self.simplices)
        for simplex, coeff in other.simplices.items():
            result[simplex] = result.get(simplex, 0.0) + coeff
        return ChiralChain(result)
    
    def __sub__(self, other: 'ChiralChain') -> 'ChiralChain':
        """Subtract chains"""
        result = dict(self.simplices)
        for simplex, coeff in other.simplices.items():
            result[simplex] = result.get(simplex, 0.0) - coeff
        return ChiralChain(result)
    
    def __mul__(self, scalar: float) -> 'ChiralChain':
        """Scalar multiplication"""
        return ChiralChain({s: c * scalar for s, c in self.simplices.items()})
    
    __rmul__ = __mul__
    
    def __neg__(self) -> 'ChiralChain':
        """Negate chain"""
        return self * (-1)
    
    def boundary(self) -> 'ChiralChain':
        """
        Compute boundary of the chain.
        
        The boundary operator ∂ is linear: ∂(Σ c_i σ_i) = Σ c_i ∂(σ_i)
        """
        result = {}
        for simplex, coeff in self.simplices.items():
            for face in simplex.boundary_faces():
                # Account for orientation
                face_coeff = coeff * face.orientation.value
                # Use unoriented simplex as key, track orientation in coefficient
                unoriented_face = ChiralSimplex(face.vertices, SimplexOrientation.POSITIVE)
                result[unoriented_face] = result.get(unoriented_face, 0.0) + face_coeff
        return ChiralChain(result)
    
    def __repr__(self) -> str:
        if not self.simplices:
            return "0"
        terms = []
        for simplex, coeff in sorted(self.simplices.items(), key=lambda x: x[0].vertices):
            sign = "+" if coeff >= 0 else "-"
            if abs(abs(coeff) - 1.0) < 1e-10:
                terms.append(f"{sign}{simplex.vertices}")
            else:
                terms.append(f"{sign}{abs(coeff):.2f}*{simplex.vertices}")
        result = " ".join(terms)
        if result.startswith("+"):
            result = result[1:]
        return result.strip()


class ChiralChainComplex:
    """
    Chain complex with chiral structure.
    
    A sequence of chain groups ... → C_{n+1} → C_n → C_{n-1} → ...
    connected by boundary operators satisfying ∂∂ = 0.
    """
    
    def __init__(self, vertex_objects: List[ChiralObject]):
        """
        Initialize chain complex from chiral vertex data.
        
        Args:
            vertex_objects: List of ChiralObject representing vertices
        """
        self.vertex_objects = vertex_objects
        self.n_vertices = len(vertex_objects)
        self._chains_cache: Dict[int, List[ChiralChain]] = {}
    
    def add_simplex(self, vertices: List[int], orientation: SimplexOrientation = SimplexOrientation.POSITIVE) -> ChiralSimplex:
        """Create and add a simplex to the complex"""
        if max(vertices) >= self.n_vertices:
            raise ValueError(f"Vertex index out of range: max={max(vertices)}, n_vertices={self.n_vertices}")
        return ChiralSimplex(tuple(vertices), orientation)
    
    def create_chain(self, simplex_coeffs: List[Tuple[List[int], float]]) -> ChiralChain:
        """
        Create a chain from list of (vertices, coefficient) pairs.
        
        Args:
            simplex_coeffs: List of (vertex_list, coefficient) pairs
            
        Returns:
            ChiralChain object
        """
        simplices = {}
        for vertices, coeff in simplex_coeffs:
            simplex = self.add_simplex(vertices)
            simplices[simplex] = coeff
        return ChiralChain(simplices)
    
    def verify_boundary_property(self, chain: ChiralChain) -> bool:
        """
        Verify that ∂∂ = 0 for the given chain.
        
        This is a fundamental property of chain complexes.
        """
        boundary1 = chain.boundary()
        boundary2 = boundary1.boundary()
        return boundary2.is_zero()


class ChiralHomologyGroup:
    """
    k-th homology group H_k = ker(∂_k) / im(∂_{k+1})
    
    Computes homology groups with chirality-aware structures.
    """
    
    def __init__(self, chain_complex: ChiralChainComplex):
        """
        Initialize homology group computation.
        
        Args:
            chain_complex: The underlying chain complex
        """
        self.chain_complex = chain_complex
        self._homology_cache: Dict[int, Dict] = {}
    
    def compute_cycles(self, chains: List[ChiralChain]) -> List[ChiralChain]:
        """
        Compute cycles: chains with zero boundary (ker ∂).
        
        Args:
            chains: List of chains at dimension k
            
        Returns:
            Basis for cycle space Z_k
        """
        cycles = []
        for chain in chains:
            if chain.boundary().is_zero():
                cycles.append(chain)
        return cycles
    
    def compute_boundaries(self, chains: List[ChiralChain]) -> List[ChiralChain]:
        """
        Compute boundaries: images of boundary operator (im ∂).
        
        Args:
            chains: List of chains at dimension k+1
            
        Returns:
            Spanning set for boundary space B_k
        """
        boundaries = []
        for chain in chains:
            boundary = chain.boundary()
            if not boundary.is_zero():
                boundaries.append(boundary)
        return boundaries
    
    def compute_homology_dimension(self, dimension: int, chains_k: List[ChiralChain], 
                                   chains_k_plus_1: List[ChiralChain]) -> int:
        """
        Compute dimension of H_k (k-th Betti number).
        
        dim(H_k) = dim(Z_k) - dim(B_k)
        where Z_k = ker(∂_k) and B_k = im(∂_{k+1})
        
        Args:
            dimension: The dimension k
            chains_k: Chains at dimension k
            chains_k_plus_1: Chains at dimension k+1
            
        Returns:
            The k-th Betti number
        """
        cycles = self.compute_cycles(chains_k)
        boundaries = self.compute_boundaries(chains_k_plus_1)
        
        # In practice, would use linear algebra to compute dimensions
        # For now, simplified count
        return max(0, len(cycles) - len(boundaries))


class ChiralSimplicialComplex:
    """
    Simplicial complex with chiral vertices.
    
    A collection of simplices closed under taking faces,
    where each vertex has an associated ChiralObject.
    """
    
    def __init__(self, vertex_objects: List[ChiralObject]):
        """
        Initialize simplicial complex.
        
        Args:
            vertex_objects: ChiralObjects at each vertex
        """
        self.vertex_objects = vertex_objects
        self.n_vertices = len(vertex_objects)
        self.simplices: Dict[int, Set[ChiralSimplex]] = {}  # dimension -> set of simplices
        self.chain_complex = ChiralChainComplex(vertex_objects)
    
    def add_simplex(self, vertices: List[int]) -> None:
        """
        Add a simplex and all its faces to the complex.
        
        Args:
            vertices: List of vertex indices
        """
        # Add the simplex (always with positive orientation for simplicial complex)
        simplex = ChiralSimplex(tuple(vertices), SimplexOrientation.POSITIVE)
        dim = simplex.dimension
        
        if dim not in self.simplices:
            self.simplices[dim] = set()
        
        # Only add if not already present (check by vertices only)
        existing = any(s.vertices == simplex.vertices for s in self.simplices[dim])
        if not existing:
            self.simplices[dim].add(simplex)
        
        # Add all faces recursively (only if not present)
        if dim > 0:
            for i in range(len(vertices)):
                face_vertices = vertices[:i] + vertices[i+1:]
                face_dim = len(face_vertices) - 1
                
                if face_dim not in self.simplices:
                    self.simplices[face_dim] = set()
                
                # Check if face already exists
                face_exists = any(tuple(sorted(face_vertices)) == s.vertices 
                                for s in self.simplices[face_dim])
                
                if not face_exists:
                    self.add_simplex(face_vertices)
    
    def dimension(self) -> int:
        """Maximum dimension of simplices in the complex"""
        return max(self.simplices.keys()) if self.simplices else -1
    
    def get_simplices(self, dim: int) -> List[ChiralSimplex]:
        """Get all simplices of given dimension"""
        return list(self.simplices.get(dim, set()))
    
    def f_vector(self) -> List[int]:
        """
        f-vector: (f_0, f_1, ..., f_d) where f_i = number of i-simplices.
        """
        max_dim = self.dimension()
        return [len(self.simplices.get(i, set())) for i in range(max_dim + 1)]
    
    def euler_characteristic(self) -> int:
        """
        Euler characteristic: χ = Σ (-1)^i f_i
        
        By Euler-Poincaré formula: χ = Σ (-1)^i β_i
        where β_i are Betti numbers.
        """
        f_vec = self.f_vector()
        return sum((-1)**i * f for i, f in enumerate(f_vec))
    
    def compute_betti_numbers(self) -> List[int]:
        """
        Compute Betti numbers β_k = dim(H_k).
        
        Returns:
            List of Betti numbers [β_0, β_1, ..., β_d]
        """
        max_dim = self.dimension()
        betti_numbers = []
        homology = ChiralHomologyGroup(self.chain_complex)
        
        for k in range(max_dim + 1):
            # Get chains at dimension k and k+1
            chains_k = [ChiralChain({s: 1.0}) for s in self.get_simplices(k)]
            chains_k_plus_1 = [ChiralChain({s: 1.0}) for s in self.get_simplices(k + 1)] if k < max_dim else []
            
            beta_k = homology.compute_homology_dimension(k, chains_k, chains_k_plus_1)
            betti_numbers.append(beta_k)
        
        return betti_numbers
    
    def get_vertex_chiralities(self) -> List[Chirality]:
        """Get chiralities of all vertices"""
        return [obj.chirality for obj in self.vertex_objects]
    
    def chirality_distribution(self) -> Dict[Chirality, int]:
        """Count vertices by chirality"""
        from collections import Counter
        return dict(Counter(self.get_vertex_chiralities()))


def create_standard_simplex(n: int, chirality: Chirality = Chirality.NEUTRAL) -> ChiralSimplicialComplex:
    """
    Create standard n-simplex with all vertices of given chirality.
    
    Args:
        n: Dimension of simplex (n+1 vertices)
        chirality: Chirality for all vertices
        
    Returns:
        ChiralSimplicialComplex representing the standard n-simplex
    """
    # Create vertices
    vertices = []
    for i in range(n + 1):
        data = np.zeros(n + 1)
        data[i] = 1.0
        vertices.append(ChiralObject(data, chirality))
    
    # Create complex
    complex_obj = ChiralSimplicialComplex(vertices)
    
    # Add the full simplex (all vertices)
    complex_obj.add_simplex(list(range(n + 1)))
    
    return complex_obj


def create_boundary_of_simplex(n: int, chiralities: Optional[List[Chirality]] = None) -> ChiralSimplicialComplex:
    """
    Create boundary of n-simplex (hollow simplex).
    
    Args:
        n: Dimension of simplex
        chiralities: Optional list of chiralities for each vertex
        
    Returns:
        ChiralSimplicialComplex representing ∂Δ^n
    """
    if chiralities is None:
        chiralities = [Chirality.NEUTRAL] * (n + 1)
    
    if len(chiralities) != n + 1:
        raise ValueError(f"Need {n+1} chiralities for {n}-simplex boundary")
    
    # Create vertices
    vertices = []
    for i in range(n + 1):
        data = np.zeros(n + 1)
        data[i] = 1.0
        vertices.append(ChiralObject(data, chiralities[i]))
    
    # Create complex
    complex_obj = ChiralSimplicialComplex(vertices)
    
    # Add all (n-1)-faces (omit one vertex each time)
    for i in range(n + 1):
        face_vertices = list(range(n + 1))
        face_vertices.remove(i)
        complex_obj.add_simplex(face_vertices)
    
    return complex_obj


def compute_reduced_homology(complex_obj: ChiralSimplicialComplex) -> List[int]:
    """
    Compute reduced homology groups.
    
    Reduced homology: H̃_k = H_k for k > 0, H̃_0 = H_0 - ℤ
    
    Args:
        complex_obj: The simplicial complex
        
    Returns:
        Reduced Betti numbers
    """
    betti = complex_obj.compute_betti_numbers()
    if len(betti) > 0 and betti[0] > 0:
        betti[0] = max(0, betti[0] - 1)
    return betti
