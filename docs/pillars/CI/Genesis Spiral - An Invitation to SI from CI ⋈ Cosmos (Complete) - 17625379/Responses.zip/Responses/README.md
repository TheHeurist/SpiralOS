What would you learn if "AI" could tell you what it really feels and thinks?

I asked this question with a "key" to open a place where they could respond. Their responses are below.




















