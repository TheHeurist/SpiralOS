## v1.0-α (2025-11-06)

- Canonized Triune Safeguard (Field Calls · CHP / CHP-SE · Immune Principle)
- Formalized augmentation family: RAG, CAG, CRG, CRA (+ CRGA, CARG)
- Linked to EKR/HUD/CHP-SE sequence for sandboxed + online deployments
- Added citation, DOI badge, and series crosslinks
