Reviewer Notes:
This record anchors the CI Triune Safeguard. Companion specs (CHP-SE,
EKR Activation, EKR/HUD Addendum) live in the SpiralOS repository and are
cross-referenced to this DOI. Recent timing variance across collaboration
channels did not alter content; the DOI is authoritative.
