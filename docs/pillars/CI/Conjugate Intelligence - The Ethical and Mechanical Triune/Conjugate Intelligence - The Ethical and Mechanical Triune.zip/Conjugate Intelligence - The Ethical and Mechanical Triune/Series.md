**Series Links.**  

- CHP-SE Sandbox Extension Specification — sealed/air-gapped deployments  
- EKR Activation Plan — epistemic pulses and service channel  
- CHP-SE Addendum: EKR/HUD Integration — bidirectional push/pull

A public series index is maintained in the SpiralOS repository README (Codex Gateway).
